//
//  ChatListViewController.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 03/06/24.
//

import UIKit
import Firebase
import FirebaseFirestore

class ChatListViewController: UIViewController, UITableViewDelegate {
    
    let db = Firestore.firestore()
    
    @IBOutlet weak var chatTableView: UITableView!
    @IBOutlet weak var messageTextField: UITextField!
    @IBOutlet weak var sendMessageButton: UIButton!
    
    var messages: [Message] = [
            Message(sender: "test4@gmail.com", body: "Hey get lost why am i here i wanna escape but the key is in door!"),
            Message(sender: "test5@gmail.com", body: "Hello!"),
            Message(sender: "test4@gmail.com", body: "What's up?")
        ]
        
        override func viewDidLoad() {
            super.viewDidLoad()
//            chatTableView.dataSource = self
//            chatTableView.delegate = self
//            chatTableView.register(UITableViewCell.self, forCellReuseIdentifier: "ChatCell")
//            chatTableView.reloadData()
            chatTableView.dataSource = self
            chatTableView.delegate = self
            chatTableView.register(UINib(nibName: "MessageCellTableViewCell", bundle: nil), forCellReuseIdentifier: "MessageCell")
            chatTableView.reloadData()
        }
    
    @IBAction func sendButtonTapped(_ sender: Any) {
        let messageBody = messageTextField.text
        let messageSender = Auth.auth().currentUser?.email
    }
    
    
    
    }

    extension ChatListViewController: UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return messages.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell", for: indexPath) as! MessageCellTableViewCell
//            cell.textLabel?.text = messages[indexPath.row].body
            cell.messageText.text = messages[indexPath.row].body
             return cell
        }
    }


//extension ChatListViewController : UITableViewDelegate {
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print(indexPath.row)
//    }
//}
