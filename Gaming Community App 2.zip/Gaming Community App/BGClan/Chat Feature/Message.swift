//
//  Message.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 03/06/24.
//

import Foundation

struct Message {
    let sender: String
    let body: String
}
