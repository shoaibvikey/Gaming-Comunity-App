import UIKit

class ChatsViewController: UIViewController {
    
    var chats: [ChatsCell] = [
        ChatsCell(SenderFullName: "Vineet Chaudhary", SenderMessage: "Hello, what's up!", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Divyanshu Rai", SenderMessage: "Should I quit gaming?", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Aadarsh Shukla", SenderMessage: "Hi, meet me in the lobby at 3pm!", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Aditya Pratap Singh", SenderMessage: "Tomorrow we are having another BGMI event", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Ankit Bhat", SenderMessage: "When are you free to play?", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Vineet Chaudhary", SenderMessage: "I am unable to level up, bro", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Harsh Bharadwaj", SenderMessage: "My KD is now 30 in the last game!", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Naman Bansal", SenderMessage: "Harsh's KD is not increasing", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Anunay Kumar", SenderMessage: "We need to level up", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Amritanshu", SenderMessage: "Hello", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Khushi Tomar", SenderMessage: "Let's have a match at 6", MessageTime: "2:30 PM"),
        ChatsCell(SenderFullName: "Varsha Sharma", SenderMessage: "Hello, ready for the match?", MessageTime: "2:30 PM")
    ]
    
    var filteredChats: [ChatsCell] = []
    
    @IBOutlet weak var ChatSearchBarUser: UISearchBar!
    @IBOutlet weak var ChatsTableViewOutlet: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        ChatsTableViewOutlet.dataSource = self
        ChatsTableViewOutlet.delegate = self
        ChatsTableViewOutlet.register(UINib(nibName: "ChatsTableViewCell", bundle: nil), forCellReuseIdentifier: "chatscell")
        ChatSearchBarUser.delegate = self
        
        filteredChats = chats

        // Do any additional setup after loading the view.
    }
}

extension ChatsViewController: UITableViewDelegate {
    
}

extension ChatsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredChats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "chatscell", for: indexPath) as! ChatsTableViewCell
        let chat = filteredChats[indexPath.row]
        cell.ChatUserFullNameOutlet?.text = chat.SenderFullName
        cell.senderMessageOutlet?.text = chat.SenderMessage
        cell.ChatTimeOutlet?.text = chat.MessageTime
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "chatSegue", sender: self)
    }
}

extension ChatsViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredChats = chats
        } else {
            filteredChats = chats.filter { chat in
                return chat.SenderFullName.lowercased().contains(searchText.lowercased()) ||
                       chat.SenderMessage.lowercased().contains(searchText.lowercased())
            }
        }
        ChatsTableViewOutlet.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""  // Clear the search text
        searchBar.resignFirstResponder()  // Dismiss the keyboard
        self.view.endEditing(true)  // Dismiss first responder for all elements in the view
        filteredChats = chats  // Restore original chats
        ChatsTableViewOutlet.reloadData()
    }
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true  // Show cancel button when editing begins
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false  // Hide cancel button when editing ends
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()  // Dismiss the keyboard
    }
    
    }

