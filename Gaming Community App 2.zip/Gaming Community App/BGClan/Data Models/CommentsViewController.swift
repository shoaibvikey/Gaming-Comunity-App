//
//  CommentViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 07/06/24.
//

import UIKit

struct Comment {
    var userName: String
    var commentText: String
}

class CommentViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var sendCommentBtn: UIButton!
    @IBOutlet weak var inputCommentTextFeild: UITextField!
    @IBOutlet weak var commentTableVIew: UITableView!
    
    var comments: [Comment] = []
    var activeField: UITextField?
    override func viewDidLoad() {
        super.viewDidLoad()
        commentTableVIew.dataSource = self
        commentTableVIew.delegate = self
        
        commentTableVIew.register(UINib(nibName: "CommentTableViewCell", bundle: nil), forCellReuseIdentifier: "commentCell")
        self.navigationItem.title = "Comments"
        inputCommentTextFeild.delegate = self

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
                NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
            }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
         textField.resignFirstResponder()
         return true
     }


    
    deinit {
            // Remove observers
            NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
            NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        }
    
    @IBAction func sendCommentBtnPressed(_ sender: UIButton) {
            guard let commentText = inputCommentTextFeild.text, !commentText.isEmpty else {
                // Handle case where input is empty
                return
            }
            
            let newComment = Comment(userName: "User", commentText: commentText)
            comments.append(newComment)
            commentTableVIew.reloadData()
            inputCommentTextFeild.text = ""
        }
    
    
    @objc func keyboardWillShow(notification: NSNotification) {
        guard let keyboardFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else {
            return
        }

        let keyboardHeight = keyboardFrame.height

        if let activeField = activeField {
            let textFieldY = activeField.convert(activeField.bounds.origin, to: self.view).y + activeField.bounds.height

            if (self.view.frame.height - textFieldY) < keyboardHeight {
                UIView.animate(withDuration: 0.3) {
                    self.view.frame.origin.y = -keyboardHeight
                }
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        UIView.animate(withDuration: 0.3) {
            self.view.frame.origin.y = 0
        }
    }


func textFieldDidBeginEditing(_ textField: UITextField) {
        activeField = textField
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        activeField = nil
    }
}
extension CommentViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)    }
}

extension CommentViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return comments.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath) as! CommentTableViewCell
        let comment = comments[indexPath.row]
                cell.userNameLbl.text = comment.userName
                cell.commentLbl.text = comment.commentText
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}
