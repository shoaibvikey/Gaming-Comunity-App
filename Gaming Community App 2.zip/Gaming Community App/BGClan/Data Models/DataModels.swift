//
//  NotificationCells.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 21/05/24.
//

import Foundation
import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

import Foundation
import UIKit
class TeamDataController {
    static let shared = TeamDataController()
    
    private init() {}
    
    private var teamStatus: Bool = false // Default value, can be changed

    func getTeamStatus() -> Bool {
        return teamStatus
    }
    
    func changeTeamStatus() {
        teamStatus = !teamStatus
    }
}



struct UserModel{
        let fullName: String
        let email: String
        let phoneNumber: Int
        let userInGameRole: String
        let userName: String
        let teamStatus: Bool
        let age: Int
        let device: String?
        let location: String?
        var profilePictureURL: String?
        var profilePicture: UIImage?
    
    
   
   
}

struct UserData {
    var username: String
    var fullName: String
    var inGameRole: String?
    var device: String?
    var bioLabel: String?
    var profilePictureURL: String?
    var bio: String?
}


struct PostModel{
    var caption : String
    var contentPath : String
    var postingTime : String
    var likesCount : Int
    var commentsCount : Int
    var username: String
    var profilePicture: String?
    var image: UIImage?
    
    init(caption: String, contentPath: String, postingTime: String, likesCount: Int, commentsCount: Int, username: String, profileImageUrl: String?) {
        self.caption = caption
        self.contentPath = contentPath
        self.postingTime = postingTime
        self.likesCount = likesCount
        self.commentsCount = commentsCount
        self.username = username
        self.profilePicture = profileImageUrl
    }
}
struct EventModel{
    var hostedBy : String
    var location : String
    var startDate : Date
    var endDate : Date
    var registrationLink : String
    var description : String
    var eventName:String
}

struct Team{
    var teamName : String
    var teamTag : String
    var currentMembers : Int
    var isTeamComplete : Bool
    var requiredRole : String?
    var numberOfEventsPlayed : Int
    var teamTier : String
    var teamImage : String?
}

struct NotificationCells{
    let notificationText : String
    let  time : String
}

struct ChatsCell{
    let SenderFullName : String
    let SenderMessage : String
    let MessageTime : String
}


class EventsCell {
    var EventName: String
    var StartEventDate: String
    var EventLocation: String
    var EventImpression: String
    var EventImage: UIImage
    var EndEventDate: String
    
//    added by me
    var OrganizedBy: String // Add new property
        var EventLink: String // Add new property
        var Description: String
    

    init(EventName: String, StartEventDate: String, EventLocation: String, EventImpression: String, EventImage: UIImage, EndEventDate: String,
OrganizedBy: String, EventLink: String, Description: String)
    {
        self.EventName = EventName
        self.StartEventDate = StartEventDate
        self.EventLocation = EventLocation
        self.EventImpression = EventImpression
        self.EventImage = EventImage
        self.EndEventDate = EndEventDate
        self.OrganizedBy = OrganizedBy
        self.EventLink = EventLink
        self.Description = Description
    }



}

//class DataController {
//    static let shared = DataController()
//
//  private  var posts: [Post] = []
//
//    func dummyFunctionToContainPostList() {
//        posts = [
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI is life!"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming with friends"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Victory royale!"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Squad goals"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI addiction"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming setup"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI memes"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Pro player"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming community"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI updates"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming news"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI events"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming tournaments"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI esports"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming lifestyle"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI fan art"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming humor"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI cosplay"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming culture"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI merchandise"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming accessories"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI collectibles"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming collectibles"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI rare items"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming rare items"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI legendary items"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming legendary items"),
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI mythic items"),
//            Post(image: UIImage(named: "ach1")!, caption: "Gaming mythic items"),
//        ]
//        print("Dummy function called")
//    }
//
//    func getPostList() -> [UIImage] {
//        return posts.compactMap { $0.image }
//    }
//
//    func addPost(_ post: Post) {
//        posts.append(post)
//    }
//}
//
//struct Post {
//    let image: UIImage
//    let caption: String
//}
//import UIKit
//
//class DataManager {
//    
//    static let shared = DataManager()
//    
//    private init() {} // Prevent external instantiation
//    
//    var fullName: String? {
//        didSet {
//            saveData()
//        }
//    }
//    
//    var teamRole: String? {
//        didSet {
//            saveData()
//        }
//    }
//    
//    var bio: String? {
//        didSet {
//            saveData()
//        }
//    }
//    
//    var deviceName: String? {
//        didSet {
//            saveData()
//        }
//    }
//    
//    var phoneNumber: String? {
//        didSet {
//            saveData()
//        }
//    }
//    
//    var profilePicture: UIImage? {
//        didSet {
//            saveProfilePicture()
//        }
//    }
//    
//    private let fullNameKey = "fullName"
//    private let teamRoleKey = "teamRole"
//    private let bioKey = "bio"
//    private let deviceNameKey = "deviceName"
//    private let phoneNumberKey = "phoneNumber"
//    private let profilePictureKey = "profilePicture"
//    
//    func loadData() {
//        let defaults = UserDefaults.standard
//        fullName = defaults.string(forKey: fullNameKey)
//        teamRole = defaults.string(forKey: teamRoleKey)
//        bio = defaults.string(forKey: bioKey)
//        deviceName = defaults.string(forKey: deviceNameKey)
//        phoneNumber = defaults.string(forKey: phoneNumberKey)
//        if let imageData = defaults.data(forKey: profilePictureKey) {
//            profilePicture = UIImage(data: imageData)
//        }
//    }
//    
//    private func saveData() {
//        let defaults = UserDefaults.standard
//        defaults.set(fullName, forKey: fullNameKey)
//        defaults.set(teamRole, forKey: teamRoleKey)
//        defaults.set(bio, forKey: bioKey)
//        defaults.set(deviceName, forKey: deviceNameKey)
//        defaults.set(phoneNumber, forKey: phoneNumberKey)
//    }
//    
//    private func saveProfilePicture() {
//        let defaults = UserDefaults.standard
//        if let profilePicture = profilePicture {
//            let imageData = profilePicture.pngData()
//            defaults.set(imageData, forKey: profilePictureKey)
//        } else {
//            defaults.removeObject(forKey: profilePictureKey)
//        }
//    }
//}
import UIKit

class DataController {
    static let shared = DataController()

    private init() {
        loadPostList()
    } // Prevent external instantiation

    // Posts data
    private var posts: [Post] = []

    // User data
    private var fullName: String? {
        didSet {
            saveUserData()
        }
    }

    private var teamRole: String? {
        didSet {
            saveUserData()
        }
    }

    private var bio: String? {
        didSet {
            saveUserData()
        }
    }

    private var deviceName: String? {
        didSet {
            saveUserData()
        }
    }

    private var phoneNumber: String? {
        didSet {
            saveUserData()
        }
    }

    private var profilePicture: UIImage? {
        didSet {
            saveProfilePicture()
        }
    }

    // Keys for UserDefaults
    private let fullNameKey = "fullName"
    private let teamRoleKey = "teamRole"
    private let bioKey = "bio"
    private let deviceNameKey = "deviceName"
    private let phoneNumberKey = "phoneNumber"
    private let profilePictureKey = "profilePicture"

    // Load user data from UserDefaults
    func loadUserData() {
        let defaults = UserDefaults.standard
        fullName = defaults.string(forKey: fullNameKey)
        teamRole = defaults.string(forKey: teamRoleKey)
        bio = defaults.string(forKey: bioKey)
        deviceName = defaults.string(forKey: deviceNameKey)
        phoneNumber = defaults.string(forKey: phoneNumberKey)
        if let imageData = defaults.data(forKey: profilePictureKey) {
            profilePicture = UIImage(data: imageData)
        }
    }

    private func saveUserData() {
        let defaults = UserDefaults.standard
        defaults.set(fullName, forKey: fullNameKey)
        defaults.set(teamRole, forKey: teamRoleKey)
        defaults.set(bio, forKey: bioKey)
        defaults.set(deviceName, forKey: deviceNameKey)
        defaults.set(phoneNumber, forKey: phoneNumberKey)
    }

    // Save profile picture to UserDefaults
    private func saveProfilePicture() {
        let defaults = UserDefaults.standard
        if let profilePicture = profilePicture {
            let imageData = profilePicture.pngData()
            defaults.set(imageData, forKey: profilePictureKey)
        } else {
            defaults.removeObject(forKey: profilePictureKey)
        }
    }
    func setFullName(_ fullName: String) {
            self.fullName = fullName
        }

        func setTeamRole(_ teamRole: String) {
            self.teamRole = teamRole
        }

        func setBio(_ bio: String) {
            self.bio = bio
        }

        func setDeviceName(_ deviceName: String) {
            self.deviceName = deviceName
        }

        func setPhoneNumber(_ phoneNumber: String) {
            self.phoneNumber = phoneNumber
        }

        func setProfilePicture(_ profilePicture: UIImage?) {
            self.profilePicture = profilePicture
        }
    // Getter methods for private variables
    func getFullName() -> String? {
        return fullName
    }

    func getTeamRole() -> String? {
        return teamRole
    }

    func getBio() -> String? {
        return bio
    }

    func getDeviceName() -> String? {
        return deviceName
    }

    func getPhoneNumber() -> String? {
        return phoneNumber
    }

    func getProfilePicture() -> UIImage? {
        return profilePicture
    }

//     Dummy function to contain post list
//    func dummyFunctionToContainPostList() {
//        posts = [
//            Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI is life!"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming with friends"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Victory royale!"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Squad goals"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI addiction"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming setup"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI memes"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Pro player"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming community"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI updates"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming news"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI events"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming tournaments"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI esports"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming lifestyle"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI fan art"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming humor"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI cosplay"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming culture"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI merchandise"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming accessories"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI collectibles"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming collectibles"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI rare items"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming rare items"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI legendary items"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "Gaming legendary items"),
//                        Post(image: UIImage(named: "bgmiImages")!, caption: "BGMI mythic items"),
//                        Post(image: UIImage(named: "ach1")!, caption: "Gaming mythic items"),
//        ]
//        print("Dummy function called")
//    }

//    ************************** Vineet ***************************
    // Firebase references

//    let db = Firestore.firestore()
//    let storage = Storage.storage()
//
//    func dummyFunctionToContainPostList(completion: @escaping () -> Void = {}) {
//            guard let currentUser = Auth.auth().currentUser else {
//                completion()
//                return
//            }
//
//            db.collection("posts").whereField("username", isEqualTo: currentUser.displayName ?? "").getDocuments { [weak self] (querySnapshot, error) in
//                guard let self = self else { return }
//
//                if let error = error {
//                    print("Error fetching posts: \(error.localizedDescription)")
//                    completion()
//                    return
//                }
//
//                self.posts = []
//
//                let dispatchGroup = DispatchGroup()
//
//                for document in querySnapshot!.documents {
//                    dispatchGroup.enter()
//
//                    let data = document.data()
//                    guard let imageURL = data["imageURL"] as? String else {
//                        dispatchGroup.leave()
//                        continue
//                    }
//
//                    let storageRef = self.storage.reference().child("posts/\(imageURL).png")
//                    storageRef.getData(maxSize: 50 * 1024 * 1024) { data, error in
//                        if let error = error {
//                            print("Error downloading image: \(error.localizedDescription)")
//                            dispatchGroup.leave()
//                        } else if let imageData = data, let image = UIImage(data: imageData) {
//                            self.posts.append(Post(image: image))
//                            dispatchGroup.leave()
//                        } else {
//                            dispatchGroup.leave()
//                        }
//                    }
//                }
//
//                dispatchGroup.notify(queue: .main) {
//                    completion()
//                }
//            }
//        }

//     Get post list
    func getPostList() -> [UIImage] {
        return posts.compactMap { $0.image }
    }
//    func getPostList() -> [Post] {
//            return posts
//        }
    
    func getPost(at index: Int) -> Post? {
        guard index >= 0 && index < posts.count else {
            return nil
        }
        return posts[index]}
    // Add a post
    func addPost(_ post: Post) {
        posts.append(post)
        
        savePostList() // Save the updated list of posts
    }
    private func savePostList() {
        let postData = posts.map { (post) -> [String: Any] in
            return [
                "image": post.image.pngData() as Any,
                "caption": post.caption
            ]
        }
        UserDefaults.standard.set(postData, forKey: "postList")
    }
//    private func savePostList() {
//        let postData = posts.map { post in
//            [
//                "image": post.image.pngData() as Any,
//                "caption": post.caption
//            ]
//        }}
                private func loadPostList() {
        if let postData = UserDefaults.standard.array(forKey: "postList") as? [[String: Any]] {
            posts = postData.compactMap { (postDict) -> Post? in
                guard let imageData = postDict["image"] as? Data,
                      let image = UIImage(data: imageData),
                      let caption = postDict["caption"] as? String else {
                    return nil
                }
                return Post(image: image, caption: caption)
            }
        }
    }
}

struct Post {
    let image: UIImage
    let caption: String
}

struct team{
    var teamID = UUID()
    var teamName : String?
    var teamLogo : UIImage?
//    var teamNoMember : UIImage?
//    var teamOwner : UIImage?
    var teammember1 : String?
    var teammember2 : String?
    var teammember3: String?
    var teammember4 : String?
    var teammember5 : String?
    var teammember6 : String?
}

struct user{
    var userID = UUID()
    var userFirstName : String
    var userLastName : String?
    var userName : String
    var userRole : String
    var userAge : String
    var userLocation : String
    var userDevice : String
    func getUserDetails() -> String {
            var details = "User Details:\n"
        details += "\(userID)"
            details += "\(userFirstName)"
            if let lastName = userLastName {
                details += "\(lastName)"
            }
            details += "\(userName)"
            details += "\(userRole)"
            details += "\(userAge)"
            details += "\(userLocation)"
            details += "\(userDevice)"
            return details
        }

    
}

struct DatePickerModel {
    var isExpanded: Bool
    var date: Date
}
