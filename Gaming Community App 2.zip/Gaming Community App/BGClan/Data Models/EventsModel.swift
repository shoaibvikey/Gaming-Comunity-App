////
////  EventsModel.swift
////  BGClan
////
////  Created by Shoaib Akhtar on 28/05/24.
////
//
//import Foundation
//var upcomingEvents: [EventsCell] = [
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//    EventsCell(EventName: "BattleGround Mobile India Season 1", EventDate: "2nd May 2024 - 15th July 2024 ", EventLocation: "Mumbai", EventImpression: "6434"),
//
//]
