//
//  MainViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 16/05/24.
//

//import UIKit
//
//class MainViewController: UIViewController {
//    
//    
//    
//    var postsOnHome : [PostModel] = [
//        PostModel(caption: "Ready for Qualifiers?", contentPath: "hasdhdcj", postingTime: "5 minutes ago", likesCount: 76423, commentsCount: 7612),
//        PostModel(caption: "Finally, the wait is over!!!!", contentPath: "hasdhdcj", postingTime: "1 hour ago", likesCount: 76423, commentsCount: 7612),
//        PostModel(caption: "Here we go again......", contentPath: "hasdhdcj", postingTime: "2 hours ago", likesCount: 76423, commentsCount: 7612),
//        PostModel(caption: "Let's come together this time", contentPath: "hasdhdcj", postingTime: "3 hours ago", likesCount: 76423, commentsCount: 7612),
//        PostModel(caption: "We're here for you guys....", contentPath: "hasdhdcj", postingTime: "1 day ago", likesCount: 76423, commentsCount: 7612),
//        PostModel(caption: "Here we go again...", contentPath: "hasdhdcj", postingTime: "5 days ago", likesCount: 76423, commentsCount: 7612),
//    ]
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Home"
//        self.tabBarItem.image = UIImage(systemName: "house")
//    }
//    
//    @IBOutlet weak var PostTableViewOutlet: UITableView!
//    @IBOutlet weak var navigationBarHome: UINavigationItem!
//    
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.navigationItem.hidesBackButton = true
//        PostTableViewOutlet.delegate = self
//        PostTableViewOutlet.dataSource = self
//        PostTableViewOutlet.register(UINib(nibName: "PostLayoutTilesCell", bundle: nil), forCellReuseIdentifier: "postcell")
//    }
//  
//
//   
//}
//extension MainViewController : UITableViewDataSource{
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return postsOnHome.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "postcell", for: indexPath) as!PostLayoutTilesCell
//        
//        cell.PostCaptionOutlet?.text = postsOnHome[indexPath.row].caption
//        cell.PostTimeOutlet?.text = "\(postsOnHome[indexPath.row].postingTime)"
//        cell.UsernameOutlet?.text = "@bgmi"
//        cell.PostLikesCountOutlet?.text = "\(postsOnHome[indexPath.row].likesCount)"
//        
//        
//        return cell
//    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 536
//    }
//    
//    
//}
//extension MainViewController : UITableViewDelegate{
//    
//}


//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class MainViewController: UIViewController {
//    
//    var postsOnHome: [PostModel] = []
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Home"
//        self.tabBarItem.image = UIImage(systemName: "house")
//    }
//    
//    @IBOutlet weak var PostTableViewOutlet: UITableView!
//    @IBOutlet weak var navigationBarHome: UINavigationItem!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.navigationItem.hidesBackButton = true
//        PostTableViewOutlet.delegate = self
//        PostTableViewOutlet.dataSource = self
//        PostTableViewOutlet.register(UINib(nibName: "PostLayoutTilesCell", bundle: nil), forCellReuseIdentifier: "postcell")
//        
//        fetchPosts()
//    }
//    
//    func fetchPosts() {
//        let db = Firestore.firestore()
//        db.collection("posts").getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching posts: \(error.localizedDescription)")
//            } else {
//                self.postsOnHome = snapshot?.documents.compactMap { document in
//                    let data = document.data()
//                    return PostModel(
//                        caption: data["caption"] as? String ?? "",
//                        contentPath: data["imageUrl"] as? String ?? "",
//                        postingTime: data["postingTime"] as? String ?? "",
//                        likesCount: data["likesCount"] as? Int ?? 0,
//                        commentsCount: data["commentsCount"] as? Int ?? 0,
//                        username: data["username"] as? String ?? ""
//                    )
//                } ?? []
//                self.PostTableViewOutlet.reloadData()
//            }
//        }
//    }
//}
//
//extension MainViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return postsOnHome.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "postcell", for: indexPath) as! PostLayoutTilesCell
//        
//        let post = postsOnHome[indexPath.row]
//        cell.PostCaptionOutlet?.text = post.caption
//        cell.PostTimeOutlet?.text = post.postingTime
//        cell.UsernameOutlet?.text = post.username
//        cell.PostLikesCountOutlet?.text = "\(post.likesCount)"
//        
//        // Download image from Firebase Storage
//        let storageRef = Storage.storage().reference(forURL: post.contentPath)
//        storageRef.getData(maxSize: 1 * 1024 * 1024) { data, error in
//            if let error = error {
//                print("Error downloading image: \(error.localizedDescription)")
//            } else {
//                cell.PostImageOutlet?.image = UIImage(data: data!)
//            }
//        }
//        
//        return cell
//    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//            return 536
//        }
//}
//
//extension MainViewController: UITableViewDelegate {}

//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class MainViewController: UIViewController {
//    
//    var postsOnHome: [PostModel] = []
//    
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Home"
//        self.tabBarItem.image = UIImage(systemName: "house")
//    }
//    
//    @IBOutlet weak var PostTableViewOutlet: UITableView!
//    @IBOutlet weak var navigationBarHome: UINavigationItem!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.navigationItem.hidesBackButton = true
//        PostTableViewOutlet.delegate = self
//        PostTableViewOutlet.dataSource = self
//        PostTableViewOutlet.register(UINib(nibName: "PostLayoutTilesCell", bundle: nil), forCellReuseIdentifier: "postcell")
//        
//        fetchPosts()
//    }
//    
//    func fetchPosts() {
//        let db = Firestore.firestore()
//        db.collection("posts").getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching posts: \(error.localizedDescription)")
//            } else {
//                self.postsOnHome = snapshot?.documents.compactMap { document in
//                    let data = document.data()
//                    guard let username = data["username"] as? String,
//                          let caption = data["caption"] as? String,
//                          let imageUrl = data["imageUrl"] as? String else {
//                        return nil
//                    }
//                    
//                    let postingTime = data["postingTime"] as? String
//                    let likesCount = data["likesCount"] as? Int
//                    let commentsCount = data["commentsCount"] as? Int
//                    
//                    return PostModel(
//                        caption: caption,
//                        contentPath: imageUrl,
//                        postingTime: postingTime ?? "",
//                        likesCount: likesCount ?? 0,
//                        commentsCount: commentsCount ?? 0,
//                        username: username
//                    )
//                } ?? []
//                self.PostTableViewOutlet.reloadData()
//            }
//        }
//    }
//}
//
//extension MainViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return postsOnHome.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "postcell", for: indexPath) as! PostLayoutTilesCell
//        
//        let post = postsOnHome[indexPath.row]
//        cell.PostCaptionOutlet?.text = post.caption
//        cell.PostTimeOutlet?.text = post.postingTime
//        cell.UsernameOutlet?.text = post.username
//        cell.PostLikesCountOutlet?.text = "\(post.likesCount)"
//        
//        // Download image from Firebase Storage
//        let storageRef = Storage.storage().reference(forURL: post.contentPath)
//        storageRef.getData(maxSize: 1 * 1024 * 1024) { data, error in
//            if let error = error {
//                print("Error downloading image: \(error.localizedDescription)")
//            } else {
//                cell.PostImageOutlet?.image = UIImage(data: data!)
//            }
//        }
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 536
//    }
//}
//
//extension MainViewController: UITableViewDelegate {}


//***************************LAST WORKING*****************************
//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class MainViewController: UIViewController {
//    
//    var postsOnHome: [PostModel] = []
//    
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Home"
//        self.tabBarItem.image = UIImage(systemName: "house")
//    }
//    
//    @IBOutlet weak var PostTableViewOutlet: UITableView!
//    @IBOutlet weak var navigationBarHome: UINavigationItem!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.navigationItem.hidesBackButton = true
//        PostTableViewOutlet.delegate = self
//        PostTableViewOutlet.dataSource = self
//        PostTableViewOutlet.register(UINib(nibName: "PostLayoutTilesCell", bundle: nil), forCellReuseIdentifier: "postcell")
//        
//        fetchPosts()
//    }
//    
//    func fetchPosts() {
//        let db = Firestore.firestore()
//        db.collection("posts").order(by: "timestamp", descending: true).getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching posts: \(error.localizedDescription)")
//            } else {
//                self.postsOnHome = snapshot?.documents.compactMap { document in
//                    let data = document.data()
//                    guard let username = data["username"] as? String,
//                          let caption = data["caption"] as? String,
//                          let imageUrl = data["imageUrl"] as? String else {
//                        return nil
//                    }
//                    
//                    let postingTime = data["postingTime"] as? String
//                    let likesCount = data["likesCount"] as? Int
//                    let commentsCount = data["commentsCount"] as? Int
//                    
//                    return PostModel(
//                        caption: caption,
//                        contentPath: imageUrl,
//                        postingTime: postingTime ?? "",
//                        likesCount: likesCount ?? 0,
//                        commentsCount: commentsCount ?? 0,
//                        username: username
//                    )
//                } ?? []
//                self.PostTableViewOutlet.reloadData()
//            }
//        }
//    }
//}
//
//extension MainViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return postsOnHome.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "postcell", for: indexPath) as! PostLayoutTilesCell
//        
//        let post = postsOnHome[indexPath.row]
//        cell.PostCaptionOutlet?.text = post.caption
////        cell.PostTimeOutlet?.text = post.postingTime
//        cell.UsernameOutlet?.text = post.username
//        cell.PostLikesCountOutlet?.text = "\(post.likesCount)"
//        
//        // Download image from Firebase Storage
//        let storageRef = Storage.storage().reference(forURL: post.contentPath)
//        storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
//            if let error = error {
//                print("Error downloading image: \(error.localizedDescription)")
//            } else {
//                cell.PostImageOutlet?.image = UIImage(data: data!)
//            }
//        }
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 607
//    }
//}
//
//extension MainViewController: UITableViewDelegate {}


import UIKit
import FirebaseFirestore
import FirebaseStorage

class MainViewController: UIViewController {

    var postsOnHome: [PostModel] = []

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "Home"
        self.tabBarItem.image = UIImage(systemName: "house")
    }

    @IBOutlet weak var PostTableViewOutlet: UITableView!
    @IBOutlet weak var navigationBarHome: UINavigationItem!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        PostTableViewOutlet.delegate = self
        PostTableViewOutlet.dataSource = self
        PostTableViewOutlet.register(UINib(nibName: "PostLayoutTilesCell", bundle: nil), forCellReuseIdentifier: "postcell")

        fetchPosts()
    }

    func fetchPosts() {
        let db = Firestore.firestore()
        db.collection("posts").order(by: "timestamp", descending: true).addSnapshotListener { (snapshot, error) in
            if let error = error {
                print("Error fetching posts: \(error.localizedDescription)")
            } else {
                guard let documents = snapshot?.documents else { return }
                let group = DispatchGroup()
                self.postsOnHome = []

                for document in documents {
                    let data = document.data()
                    guard let username = data["username"] as? String,
                          let caption = data["caption"] as? String,
                          let imageUrl = data["imageUrl"] as? String else {
                        continue
                    }

                    let postingTime = data["postingTime"] as? String
                    let likesCount = data["likesCount"] as? Int
                    let commentsCount = data["commentsCount"] as? Int

                    group.enter()
                    self.fetchProfileImageUrl(for: username) { profileImageUrl in
                        let post = PostModel(
                            caption: caption,
                            contentPath: imageUrl,
                            postingTime: postingTime ?? "",
                            likesCount: likesCount ?? 0,
                            commentsCount: commentsCount ?? 0,
                            username: username,
                            profileImageUrl: profileImageUrl
                        )
                        self.postsOnHome.append(post)
                        group.leave()
                    }
                }

                group.notify(queue: .main) {
                    self.PostTableViewOutlet.reloadData()
                }
            }
        }
    }

    func fetchProfileImageUrl(for username: String, completion: @escaping (String?) -> Void) {
        let db = Firestore.firestore()
        db.collection("users").whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching user profile: \(error.localizedDescription)")
                completion(nil)
            } else {
                guard let documents = snapshot?.documents, !documents.isEmpty else {
                    print("User document for \(username) does not exist.")
                    completion(nil)
                    return
                }

                let document = documents[0]
                print("Document data for \(username): \(document.data())")
                let profileImageUrl = document.data()["profilePictureURL"] as? String
                print("Fetched profileImageUrl for \(username): \(profileImageUrl ?? "nil")")
                completion(profileImageUrl)
            }
        }
    }
}

extension MainViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postsOnHome.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "postcell", for: indexPath) as! PostLayoutTilesCell

        let post = postsOnHome[indexPath.row]
        cell.PostCaptionOutlet?.text = post.caption
        // cell.PostTimeOutlet?.text = post.postingTime
        cell.UsernameOutlet?.text = post.username
        cell.PostLikesCountOutlet?.text = "\(post.likesCount)"

        // Download post image from Firebase Storage
        let postImageRef = Storage.storage().reference(forURL: post.contentPath)
        postImageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
            if let error = error {
                print("Error downloading post image: \(error.localizedDescription)")
            } else {
                cell.PostImageOutlet?.image = UIImage(data: data!)
            }
        }

        // Download profile image from Firebase Storage if available
        if let profileImageUrl = post.profilePicture {
            let profileImageRef = Storage.storage().reference(forURL: profileImageUrl)
            profileImageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
                if let error = error {
                    print("Error downloading profile image: \(error.localizedDescription)")
                } else {
                    cell.ProfilePhotoOutlet?.image = UIImage(data: data!)
                }
            }
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 607
    }
}

extension MainViewController: UITableViewDelegate {}
