////
////  searchUsersViewController.swift
////  BGClan
////
////  Created by Shoaib Akhtar on 03/06/24.
////
//
//import UIKit
//
//class ResultsSearchUsersViewController: UIViewController {
//
//    @IBOutlet weak var userSearchBar: UISearchBar!
//    var searchResults: [UserModel] = []
//    var users: [UserModel] = [
//        UserModel(firstName: "Shoaib", lastName: "Akhtar", email: "shoaib@team5.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "shoaibvikey", teamStatus: true, age: 21, device: "iPhone 14 series", location: "Andhra Pradesh"),
//                UserModel(firstName: "Vineet", lastName: "Singh", email: "vineet@team5.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "vineetchaudary", teamStatus: true, age: 22, device: nil, location: nil),
//                UserModel(firstName: "Divyanshu", lastName: "Rai", email: "divyanshu@team5.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "divyanshurai", teamStatus: false, age: 20, device: nil, location: nil),
//                UserModel(firstName: "Adarsh", lastName: "Shukla", email: "adarsh@team5.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "adarshshukla", teamStatus: false, age: 19, device: nil, location: nil),
//                UserModel(firstName: "Naman", lastName: "Bansal", email: "naman@user.com", phoneNumber: 7448487378, userInGameRole: "IGL", userName: "namanbansal", teamStatus: false, age: 21, device: nil, location: nil),
//                UserModel(firstName: "Anunay", lastName: "Kumar", email: "anunay@user.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "anunaykumar", teamStatus: true, age: 22, device: nil, location: nil),
//                UserModel(firstName: "Amritanshu", lastName: " ", email: "Amritanshu@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "ammytanshu", teamStatus: false, age: 20, device: nil, location: nil),
//                UserModel(firstName: "Harsh", lastName: "Aggarwal", email: "harsh@user.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "harshaggarwal", teamStatus: false, age: 19, device: nil, location: nil),
//                UserModel(firstName: "Varsha", lastName: "Sharma", email: "varsha@user.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "varshasharma", teamStatus: false, age: 21, device: nil, location: nil),
//                UserModel(firstName: "Khushi", lastName: "Tomar", email: "Khushi@user.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "khushitomar", teamStatus: true, age: 22, device: nil, location: nil),
//                UserModel(firstName: "Nand", lastName: "Kishore", email: "kishore@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "nandkishore", teamStatus: false, age: 20, device: nil, location: nil),
//                UserModel(firstName: "Shalu", lastName: "Tiwari", email: "shalu@user.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "shalutiwari", teamStatus: false, age: 19, device: nil, location: nil),
//                UserModel(firstName: "Niharika", lastName: "Sharma", email: "shoaib@team5.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "niharikasharma", teamStatus: false, age: 21, device: nil, location: nil),
//                UserModel(firstName: "Vinod", lastName: "Kumar", email: "vinod@team5.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "vinodkumar", teamStatus: true, age: 22, device: nil, location: nil),
//                UserModel(firstName: "Kanishka", lastName: "Garg", email: "kanishka@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "gargkanishka", teamStatus: false, age: 20, device: nil, location: nil),
//                UserModel(firstName: "Vanshika", lastName: "Singh", email: "adarsh@team5.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "singhvanshika", teamStatus: false, age: 19, device: nil, location: nil)
//    ]
//    
//    @IBOutlet weak var userSearchTV: UITableView!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        userSearchTV.dataSource = self
//        userSearchTV.delegate = self
//        userSearchTV.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
//        
//        userSearchBar.delegate = self  // Set the search bar delegate
//        
//        searchResults = users  // Initialize search results with all users
//    }
//}
//
//extension searchUsersViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return searchResults.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//        cell.SearchUsernameOutlet?.text = searchResults[indexPath.row].userName
//        return cell
//    }
//    
//}
//
//extension searchUsersViewController: UITableViewDelegate {
//    // Implement any delegate methods if needed
//}
//
//extension searchUsersViewController: UISearchBarDelegate {
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        if searchText.isEmpty {
//            searchResults = users
//        } else {
//            searchResults = users.filter { $0.userName.lowercased().contains(searchText.lowercased()) }
//        }
//        userSearchTV.reloadData()
//    }
//    
//    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
//        searchBar.resignFirstResponder()
//    }
//}
