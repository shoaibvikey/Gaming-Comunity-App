//
//  SearchProfileCollectionViewCell.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 13/06/24.
//

import UIKit

class SearchProfileCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var postsImages: UIImageView!
    
}
