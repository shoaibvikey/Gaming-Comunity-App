//
//  SearchProfileCollectionViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 13/06/24.
//

import UIKit
import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage


class SearchProfileCollectionViewController: UICollectionViewController,UICollectionViewDelegateFlowLayout  {

    

    
        var post: [PostModel] = []
        var userData: UserData?
        var profilePicture: UIImage?
        var username: String?

        required init?(coder: NSCoder) {
            super.init(coder: coder)
            self.tabBarItem.title = "Profile"
            self.tabBarItem.image = UIImage(systemName: "person")
        }

        override func viewDidLoad() {
            super.viewDidLoad()
            collectionView.delegate = self
            collectionView.dataSource = self
            fetchCurrentUsername()
        }

        func fetchCurrentUsername() {
//            if let userId = Auth.auth().currentUser?.uid {
//                fetchUsernameForLoggedUser(userId: userId)
//            } else {
//                print("No user is logged in")
//            }
         if let usedId = username {
             fetchUsernameForLoggedUser(userId: username ?? "nil")
        } else {
            print("No username received")
        }
        }

        func fetchUsernameForLoggedUser(userId: String) {
            let db = Firestore.firestore()
            let userRef = db.collection("users").document(userId)
            userRef.getDocument { document, error in
                if let error = error {
                    print("Error fetching user data: \(error.localizedDescription)")
                } else {
                    if let document = document, let userData = document.data(), let fetchedUsername = userData["username"] as? String {
                        self.username = fetchedUsername
                        self.fetchUserDetails() // Fetch user details after getting username
                        self.fetchUserPosts(username: fetchedUsername) // Fetch posts after getting username
                    } else {
                        print("Username not found for userId: \(userId)")
                    }
                }
            }
        }

        func fetchUserDetails() {
            guard let username = username else {
                print("Username not set")
                return
            }

            let db = Firestore.firestore()
            let usersRef = db.collection("users")

            usersRef.whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
                if let error = error {
                    print("Error fetching user details: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents, let document = documents.first else {
                    print("User not found for username: \(username)")
                    return
                }

                let data = document.data()
                print("User data: \(data)")

                // Parse user data into UserData model
                self.userData = UserData(
                    username: data["username"] as? String ?? "",
                    fullName: data["fullName"] as? String ?? "",
                    inGameRole: data["userInGameRole"] as? String ?? "",
                    device: data["device"] as? String ?? "",
                    profilePictureURL: data["profilePictureURL"] as? String ?? ""
                )

                // Fetch profile picture using the URL
                self.fetchProfilePicture(urlString: self.userData?.profilePictureURL)
            }
        }

        func fetchProfilePicture(urlString: String?) {
            guard let urlString = urlString else {
                print("Invalid profile picture URL")
                return
            }

            let storageRef = Storage.storage().reference(forURL: urlString)
            storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
                if let error = error {
                    print("Error fetching profile picture: \(error.localizedDescription)")
                    return
                }

                if let data = data {
                    self.profilePicture = UIImage(data: data)
                    self.collectionView.reloadData() // Reload collection view after fetching profile picture
                }
            }
        }

        func fetchUserPosts(username: String) {
            let db = Firestore.firestore()
            let postsRef = db.collection("posts")

            postsRef.whereField("username", isEqualTo: username).addSnapshotListener { (snapshot, error) in
                if let error = error {
                    print("Error fetching posts: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents else {
                    print("No posts found for username: \(username)")
                    return
                }

                var posts = [PostModel]()

                let dispatchGroup = DispatchGroup()
                
                for document in documents {
                    let data = document.data()
                    let post = PostModel(
                        caption: data["caption"] as? String ?? "",
                        contentPath: data["imageUrl"] as? String ?? "",
                        postingTime: data["postingTime"] as? String ?? "",
                        likesCount: data["likesCount"] as? Int ?? 0,
                        commentsCount: data["commentsCount"] as? Int ?? 0,
                        username: data["username"] as? String ?? "",
                        profileImageUrl: data["profilePicture"] as? String
    //                    image: nil
                    )
                    posts.append(post)
                }

                self.post = posts

                for (index, post) in self.post.enumerated() {
                    guard !post.contentPath.isEmpty else { continue }
                    dispatchGroup.enter()
                    let storageRef = Storage.storage().reference(forURL: post.contentPath)
                    storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
                        if let error = error {
                            print("Error fetching image: \(error.localizedDescription)")
                        } else if let data = data {
                            self.post[index].image = UIImage(data: data)
                        }
                        dispatchGroup.leave()
                    }
                }

                dispatchGroup.notify(queue: .main) {
                    self.collectionView.reloadData()
                }
            }
        }


        // MARK: - UICollectionViewDataSource

        override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return post.count
        }

        override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Searchcell", for: indexPath) as! SearchProfileCollectionViewCell
            
            let postItem = post[indexPath.row]
            if let image = postItem.image {
                cell.postsImages.image = image
            } else {
                cell.postsImages.image = UIImage(named: "placeholderImage") // Use a placeholder image
            }

            return cell
        }

        // MARK: - UICollectionViewDelegateFlowLayout

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let width = collectionView.frame.size.width / 3 - 6 // Adjusted for spacing
            let height = collectionView.frame.size.height / 7 - 3 // Adjusted for spacing
            return CGSize(width: width, height: height)
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 3 // Adjust as needed
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 1 // Adjust as needed
        }

        // MARK: - UICollectionViewDelegate

        override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "Searchheader", for: indexPath) as! SearchProfileCollectionReusableView

            if let userData = userData {
                header.configure(with: userData, profilePicture: profilePicture)
            }

            return header
        }
        
        
    //    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    //            performSegue(withIdentifier: "showPostDetail", sender: indexPath)
    //        }

        override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
                performSegue(withIdentifier: "showDetailForGlobal", sender: indexPath)
            }

            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if segue.identifier == "showDetailForGlobal",
                   let destinationVC = segue.destination as? PostDetailTableViewController,
                   let indexPath = sender as? IndexPath {
                    let selectedPost = post[indexPath.row]
                    destinationVC.post = selectedPost
                    destinationVC.profilePicture = profilePicture
                }
            }

    }
