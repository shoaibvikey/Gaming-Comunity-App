import UIKit
import FirebaseFirestore
import FirebaseStorage

class searchUsersViewController: UIViewController {

    @IBOutlet weak var userSearchBar: UISearchBar!
    var searchResults: [UserModel] = []
    var users: [UserModel] = []
    
    @IBOutlet weak var userSearchTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userSearchTV.dataSource = self
        userSearchTV.delegate = self
        userSearchTV.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
        
        userSearchBar.delegate = self  // Set the search bar delegate
        
        fetchUsers()  // Fetch users from Firestore
    }
    
    func fetchUsers() {
        let db = Firestore.firestore()
        
        db.collection("users").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
            } else {
                self.users = querySnapshot?.documents.compactMap { document -> UserModel? in
                    let data = document.data()
                    let fullName = data["fullName"] as? String ?? ""
                    let email = data["email"] as? String ?? ""
                    let phoneNumber = data["phoneNumber"] as? Int ?? 0
                    let userInGameRole = data["userInGameRole"] as? String ?? ""
                    let userName = data["userName"] as? String ?? ""
                    let teamStatus = data["teamStatus"] as? Bool ?? false
                    let age = data["age"] as? Int ?? 0
                    let device = data["device"] as? String
                    let location = data["location"] as? String
                    let profilePictureURL = data["profilePictureURL"] as? String
                    
                    return UserModel(fullName: fullName, email: email, phoneNumber: phoneNumber, userInGameRole: userInGameRole, userName: userName, teamStatus: teamStatus, age: age, device: device, location: location, profilePictureURL: profilePictureURL)
                } ?? []
                
                self.searchResults = self.users
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "globalSearchSegue",
               let destinationVC = segue.destination as? SearchProfileCollectionViewController,
               let selectedIndex = userSearchTV.indexPathForSelectedRow?.row {
                let selectedUser = searchResults[selectedIndex]
                destinationVC.username = selectedUser.userName
            }
        }
    
}

extension searchUsersViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResults.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
        
        let user = searchResults[indexPath.row]
        cell.SearchUsernameOutlet?.text = user.fullName
        
        if let profilePictureURL = user.profilePictureURL, !profilePictureURL.isEmpty {
            let storageRef = Storage.storage().reference(forURL: profilePictureURL)
            storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
                if let error = error {
                    print("Error downloading profile picture: \(error.localizedDescription)")
                    cell.SearchProfileImageView.image = UIImage(named: "default_profile")  // Placeholder image
                } else {
                    cell.SearchProfileImageView.image = UIImage(data: data!)
                }
            }
        } else {
            cell.SearchProfileImageView.image = UIImage(named: "default_profile")  // Placeholder image
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
}

extension searchUsersViewController: UITableViewDelegate {
   
    // Implement any delegate methods if needed
}

extension searchUsersViewController: UISearchBarDelegate {
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true  // Show cancel button when editing begins
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false  // Hide cancel button when editing ends
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searchResults = users
        } else {
            searchResults = users.filter { $0.fullName.lowercased().contains(searchText.lowercased()) }
        }
        userSearchTV.reloadData()
    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()  // Dismiss the keyboard
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        searchBar.text = ""
        searchResults = users
        userSearchTV.reloadData()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier:"globalSearchSegue", sender: self)
    }
    
}
