////
////  UserData.swift
////  BGClan
////
////  Created by Shoaib Akhtar on 27/05/24.
////
//
//import Foundation
//var users : [UserModel] = [
//    UserModel(firstName: "Shoaib", lastName: "Akhtar", email: "shoaib@team5.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "shoaibvikey", teamStatus: false, age: 21),
//    UserModel(firstName: "Vineet", lastName: "Singh", email: "vineet@team5.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "vineetchaudary", teamStatus: true, age: 22),
//    UserModel(firstName: "Divyanshu", lastName: "Rai", email: "divyanshu@team5.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "divyanshurai", teamStatus: false, age: 20),
//    UserModel(firstName: "Adarsh", lastName: "Shukla", email: "adarsh@team5.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "adarshshukla", teamStatus: false, age: 19),
//    UserModel(firstName: "Naman", lastName: "Bansal", email: "naman@user.com", phoneNumber: 7448487378, userInGameRole: "IGL", userName: "namanbansal", teamStatus: false, age: 21),
//    UserModel(firstName: "Anunay", lastName: "Kumar", email: "anunay@user.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "anunaykumar", teamStatus: true, age: 22),
//    UserModel(firstName: "Amritanshu", lastName: " ", email: "Amritanshu@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "ammytanshu", teamStatus: false, age: 20),
//    UserModel(firstName: "Harsh", lastName: "Aggarwal", email: "harsh@user.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "harshaggarwal", teamStatus: false, age: 19),
//    UserModel(firstName: "Varsha", lastName: "Sharma", email: "varsha@user.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "varshasharma", teamStatus: false, age: 21),
//    UserModel(firstName: "Khushi", lastName: "Tomar", email: "Khushi@user.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "khushitomar", teamStatus: true, age: 22),
//    UserModel(firstName: "Nand", lastName: "Kishore", email: "kishore@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "nandkishore", teamStatus: false, age: 20),
//    UserModel(firstName: "Shalu", lastName: "Tiwari", email: "shalu@user.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "shalutiwari", teamStatus: false, age: 19),
//    UserModel(firstName: "Niharika", lastName: "Sharma", email: "shoaib@team5.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "niharikasharma", teamStatus: false, age: 21),
//    UserModel(firstName: "Vinod", lastName: "Kumar", email: "vinod@team5.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "vinodkumar", teamStatus: true, age: 22),
//    UserModel(firstName: "Kanishka", lastName: "Garg", email: "kanishka@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "gargkanishka", teamStatus: false, age: 20),
//    UserModel(firstName: "Vanshika", lastName: "Singh", email: "adarsh@team5.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "singhvanshika", teamStatus: false, age: 19)
//
//
//
//
//
//
//
//
//
//
//
//
//]
