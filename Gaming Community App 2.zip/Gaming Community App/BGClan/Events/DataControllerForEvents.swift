//import Foundation
//import UIKit
//import Firebase
//import FirebaseFirestore
//import FirebaseStorage
//
//class DataControllerForEvents {
//    static let shared = DataControllerForEvents()
//    private var events: [EventsCell] = []
//    
//    private init() {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "d/MM/yyyy"
//        
////                let eventImage = UIImage(named: "ach1")!
////        
////                events = [
////                    EventsCell(EventName: "BattleGround Mobile India Season 1", StartEventDate: formatter.string(from: Date()), EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: formatter.string(from: Date().addingTimeInterval(60 * 60 * 24))),
////                    EventsCell(EventName: "BattleGround Mobile India Season 2", StartEventDate: formatter.string(from: Date().addingTimeInterval(-60 * 60 * 24 * 2)), EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: formatter.string(from: Date().addingTimeInterval(60 * 60 * 24))),
////                    EventsCell(EventName: "BattleGround Mobile India Season 1", StartEventDate: "5/6/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024"),
////                    EventsCell(EventName: "BattleGround Mobile India Season 2", StartEventDate: "6/6/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024"),
////                    EventsCell(EventName: "BattleGround Mobile India Season 3", StartEventDate: "9/6/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024"),
////                    EventsCell(EventName: "BattleGround Mobile India Season 4", StartEventDate: "5/6/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024"),
////                    EventsCell(EventName: "BattleGround Mobile India Season 5", StartEventDate: "6/6/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024"),
////                    EventsCell(EventName: "BattleGround Mobile India Season 6", StartEventDate: "16/5/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024"),
////                    EventsCell(EventName: "BattleGround Mobile India Season 7", StartEventDate: "16/6/2024", EventLocation: "Mumbai", EventImpression: "6434", EventImage: eventImage, EndEventDate: "16/6/2024")
////                ]
//        
//        let db = Firestore.firestore()
//               var events: [EventsCell] = []
//
//               db.collection("events").getDocuments { (querySnapshot, error) in
//                   if let error = error {
//                       print("Error getting documents: \(error)")
//                   } else {
//                       for document in querySnapshot!.documents {
//                           let eventName = document.get("EventName") as? String
//                           let startEventDate = document.get("StartEventDate") as? String
//                           let eventLocation = document.get("EventLocation") as? String
//                           let eventImpression = document.get("EventImpression") as? String
//                           let endEventDate = document.get("EndEventDate") as? String
//                           let eventImageURL = document.get("EventImage") as? String
//                           
//                           // Fetch image from Firebase Storage
//                           let storageRef = Storage.storage().reference()
//                           let imageRef = storageRef.child("Images/\(eventImageURL!)")
//                           imageRef.downloadURL { (url, error) in
//                               if let error = error {
//                                   print("Error downloading image: \(error)")
//                               } else {
//                                   guard let url = url else { return }
//                                   URLSession.shared.dataTask(with: url) { data, response, error in
//                                       if let error = error {
//                                           print("Error downloading image: \(error)")
//                                       } else {
//                                           guard let data = data else { return }
//                                           let eventImage = UIImage(data: data)!
//                                           let event = EventsCell(EventName: eventName!, StartEventDate: startEventDate!, EventLocation: eventLocation!, EventImpression: eventImpression!, EventImage: eventImage, EndEventDate: endEventDate!)
//                                           events.append(event)
//                                           // You can reload your table view or collection view here
//                                           // tableView.reloadData() or collectionView.reloadData()
//                                       }
//                                   }.resume()
//                               }
//                           }
//                       }
//                   }
//               }
//            }
//        
//    
//        func addEvent(_ event: EventsCell) {
//            let today = Calendar.current.startOfDay(for: Date())
//            let formatter = DateFormatter()
//            formatter.dateFormat = "dd/MM/yy" // Correct date format for input
//            
//            guard let newStartDate = formatter.date(from: event.StartEventDate) else {
//                print("Invalid start date format: \(event.StartEventDate)")
//                return
//            }
//            
//            if event.isUpcoming() {
//                events.append(event)
//            } else if event.isPast() {
//                events.insert(event, at: 0) // Insert at the beginning for past events
//            }
//            
//            
//            
//            sortEvents() // Call sortEvents after adding the event
//            NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
//            print("Event added: \(event.EventName), Start: \(event.StartEventDate), End: \(event.EndEventDate)")
//        }
//        var upcomingEvents: [EventsCell] {
//            let upcoming = events.filter { $0.isUpcoming() }
//            print("Upcoming events: \(upcoming.map { "\($0.EventName): \($0.StartEventDate)" })")
//            return upcoming
//        }
//        
//        var pastEvents: [EventsCell] {
//            let past = events.filter { $0.isPast() }
//            print("Past events: \(past.map { "\($0.EventName): \($0.StartEventDate)" })")
//            return past
//        }
//        
//        
//        func checkAndMoveEvents() {
//            let formatter = DateFormatter()
//            formatter.dateFormat = "d/MM/yyyy"
//            
//            let currentDate = Calendar.current.startOfDay(for: Date())
//            events.forEach { event in
//                guard let startDate = formatter.date(from: event.StartEventDate) else { return }
//                
//                if startDate >= currentDate {
//                    // Event is upcoming
//                    if event.isPast() {
//                        // If event was mistakenly classified as past, move it to upcoming
//                        events.removeAll { $0.EventName == event.EventName }
//                        events.append(event)
//                    }
//                } else {
//                    // Event is in the past
//                    if event.isUpcoming() {
//                        // If event was mistakenly classified as upcoming, move it to past
//                        events.removeAll { $0.EventName == event.EventName }
//                        events.insert(event, at: 0)
//                    }
//                }
//            }
//            
//            sortEvents()
//        }
//        
//        func sortEvents() {
//            let formatter = DateFormatter()
//            formatter.dateFormat = "d/MM/yyyy"
//            
//            events.sort { event1, event2 in
//                if let date1 = formatter.date(from: event1.StartEventDate), let date2 = formatter.date(from: event2.StartEventDate) {
//                    return date1 < date2
//                }
//                return false
//            }
//            
//            print("Events after sorting: \(events.map { "\($0.EventName): \($0.StartEventDate)" })")
//        }
//        
//        func scheduleDailyEventCheck() {
//            let timer = Timer.scheduledTimer(withTimeInterval: 24 * 60 * 60, repeats: true) { _ in
//                self.checkAndMoveEvents()
//            }
//            RunLoop.current.add(timer, forMode: .common)
//        }
//    }

/* vinnet
import Foundation
import UIKit
import FirebaseFirestore
import FirebaseStorage

class DataControllerForEvents {
    static let shared = DataControllerForEvents()
    private var events: [EventsCell] = []
    let db = Firestore.firestore()
    var array:[EventsCell]?
    private init() {
        Task {
            await fetchDataFromFirestore()
        }
    }

    private func fetchDataFromFirestore() async {
        do {
            var querySnapshot = try await db.collection("events").getDocuments()
            
            for document in querySnapshot.documents {
                let eventName = document.get("EventName") as? String
                let startEventDate = document.get("StartEventDate") as? String
                let eventLocation = document.get("EventLocation") as? String
                let endEventDate = document.get("EndEventDate") as? String
                let eventImageURL = document.get("EventImageURL") as? String
                
                // Placeholder image if event image URL is nil
                let placeholderImage = UIImage(named: "placeholder") ?? UIImage(systemName: "photo")!
                var eventImage = UIImage(named: "ach1")!
//
                if let eventImageURL = eventImageURL {
                    // Fetch image from Firebase Storage
                    let storageRef = Storage.storage().reference(withPath: eventImageURL)
                        do {
                            var data = try await storageRef.data(maxSize: 10 * 1024 * 1024)
                            eventImage = UIImage(data: data)!
                        } catch {
                            fatalError("Image not found!")
                        }
//                    storageRef.downloadURL { (url, error) in
//                        if let error = error {
//                            print("Error downloading image: \(error)")
//                            self.createEventCell(eventName: eventName, startEventDate: startEventDate, eventLocation: eventLocation, endEventDate: endEventDate, eventImage: placeholderImage)
//                            return
//                        }
//                        guard let url = url else { return }
//                        URLSession.shared.dataTask(with: url) { data, response, error in
//                            if let error = error {
//                                print("Error downloading image: \(error)")
//                                self.createEventCell(eventName: eventName, startEventDate: startEventDate, eventLocation: eventLocation, endEventDate: endEventDate, eventImage: placeholderImage)
//                                return
//                            }
//                            guard let data = data, let eventImage = UIImage(data: data) else {
//                                print("Error: Unable to create image from data")
//                                self.createEventCell(eventName: eventName, startEventDate: startEventDate, eventLocation: eventLocation, endEventDate: endEventDate, eventImage: placeholderImage)
//                                return
//                            }
                            self.createEventCell(eventName: eventName, startEventDate: startEventDate, eventLocation: eventLocation, endEventDate: endEventDate, eventImage: eventImage)
//                        }.resume()
//                    }
                } else {
                    self.createEventCell(eventName: eventName, startEventDate: startEventDate, eventLocation: eventLocation, endEventDate: endEventDate, eventImage: placeholderImage)
                }
            }
        } catch {
            fatalError("events collection not found")
        }
    }
    
    private func createEventCell(eventName: String?, startEventDate: String?, eventLocation: String?, endEventDate: String?, eventImage: UIImage) {
        guard let eventName = eventName,
              let startEventDate = startEventDate,
              let eventLocation = eventLocation,
              let endEventDate = endEventDate else {
            print("Error: One of the event properties is nil for a document")
            return
        }
        print(eventName)
        print(startEventDate)
        print(eventLocation)
        print(endEventDate)
        print(eventImage)
        
        let event = EventsCell(EventName: eventName, StartEventDate: startEventDate, EventLocation: eventLocation, EventImpression: "", EventImage: eventImage, EndEventDate: endEventDate)
        self.events.append(event)
        self.sortEvents()
        NotificationCenter.default.post(name: NSNotification.Name("EventsFetched"), object: nil)
    }

    func addEvent(_ event: EventsCell) {
        if event.isUpcoming() {
            events.append(event)
            array?.append(event)
            print("help")
            
        } else if event.isPast() {
            events.insert(event, at: 0)
        }
        
        sortEvents()
        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
        print("Event added: \(event.EventName), Start: \(event.StartEventDate), End: \(event.EndEventDate)")
    }

    var upcomingEvents: [EventsCell] {
        return events.filter { $0.isUpcoming() }
    }

    var pastEvents: [EventsCell] {
        return events.filter { $0.isPast() }
    }

    func checkAndMoveEvents() {
        let currentDate = Calendar.current.startOfDay(for: Date())
        events.forEach { event in
            guard let startDate = event.startDate else { return }
            
            if startDate >= currentDate {
                if event.isPast() {
                    events.removeAll { $0.EventName == event.EventName }
                    events.append(event)
                }
            } else {
                if event.isUpcoming() {
                    events.removeAll { $0.EventName == event.EventName }
                    events.insert(event, at: 0)
                }
            }
        }
        
        sortEvents()
    }

    func sortEvents() {
        events.sort { event1, event2 in
            guard let date1 = event1.startDate, let date2 = event2.startDate else { return false }
            return date1 < date2
        }
        print("Events after sorting: \(events.map { "\($0.EventName): \($0.StartEventDate)" })")
    }

    func scheduleDailyEventCheck() {
        let timer = Timer.scheduledTimer(withTimeInterval: 24 * 60 * 60, repeats: true) { _ in
            self.checkAndMoveEvents()
        }
        RunLoop.current.add(timer, forMode: .common)
    }
}

//extension EventsCell {
//    var startDate: Date? {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "d/MM/yyyy"
//        return formatter.date(from: self.StartEventDate)
//    }
//    
//    func isUpcoming() -> Bool {
//        guard let startDate = self.startDate else { return false }
//        return startDate >= Calendar.current.startOfDay(for: Date())
//    }
//    
//    func isPast() -> Bool {
//        guard let startDate = self.startDate else { return false }
//        return startDate < Calendar.current.startOfDay(for: Date())
//    }
//}
extension EventsCell {
    var startDate: Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy" // Adjusted date format
        
        return formatter.date(from: self.StartEventDate)
    }
    
    func isUpcoming() -> Bool {
        guard let startDate = self.startDate else { return false }
        let today = Calendar.current.startOfDay(for: Date())
        return startDate >= today
    }
    
    func isPast() -> Bool {
        guard let startDate = self.startDate else { return false }
        let today = Calendar.current.startOfDay(for: Date())
        return startDate < today
    }
}


//Divyanshu
//import Foundation
//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class DataControllerForEvents {
//    static let shared = DataControllerForEvents()
//    private var events: [EventsCell] = []
//    let db = Firestore.firestore()
//
//    private init() {
//        Task {
//            await fetchDataFromFirestore()
//        }
//    }
//
//    private func fetchDataFromFirestore() async {
//        do {
//            var querySnapshot = try await db.collection("events").getDocuments()
//            
//            for document in querySnapshot.documents {
//                let eventName = document.get("EventName") as? String
//                let startEventDate = document.get("StartEventDate") as? String
//                let eventLocation = document.get("EventLocation") as? String
//                let endEventDate = document.get("EndEventDate") as? String
//                let eventImageURL = document.get("EventImageURL") as? String
//                
//                // Placeholder image if event image URL is nil
//                let placeholderImage = UIImage(named: "placeholder") ?? UIImage(systemName: "photo")!
//                var eventImage = UIImage(named: "ach1")!
//                
//                if let eventImageURL = eventImageURL {
//                    // Fetch image from Firebase Storage
//                    let storageRef = Storage.storage().reference(withPath: eventImageURL)
//                    do {
//                        var data = try await storageRef.data(maxSize: 10 * 1024 * 1024)
//                        eventImage = UIImage(data: data)!
//                    } catch {
//                        fatalError("Image not found!")
//                    }
//                } else {
//                    self.createEventCell(eventName: eventName, startEventDate: startEventDate, eventLocation: eventLocation, endEventDate: endEventDate, eventImage: placeholderImage)
//                }
//            }
//        } catch {
//            fatalError("events collection not found")
//        }
//    }
//    
//    private func createEventCell(eventName: String?, startEventDate: String?, eventLocation: String?, endEventDate: String?, eventImage: UIImage) {
//        guard let eventName = eventName,
//              let startEventDate = startEventDate,
//              let eventLocation = eventLocation,
//              let endEventDate = endEventDate else {
//            print("Error: One of the event properties is nil for a document")
//            return
//        }
//        
//        let formatter = DateFormatter()
//        formatter.dateFormat = "d/MM/yy" // Adjust this to match your Firestore date format
//        
//        guard let formattedStartDate = formatter.date(from: startEventDate) else {
//            print("Error: Unable to format start date from Firestore")
//            return
//        }
//        
//        let formattedStartEventDate = formatter.string(from: formattedStartDate)
//        
//        let event = EventsCell(EventName: eventName, StartEventDate: formattedStartEventDate, EventLocation: eventLocation, EventImpression: "", EventImage: eventImage, EndEventDate: endEventDate)
//        
//        self.events.append(event)
//        self.sortEvents()
//        NotificationCenter.default.post(name: NSNotification.Name("EventsFetched"), object: nil)
//    }
//
//    func addEvent(_ event: EventsCell) {
//        if event.isUpcoming() {
//            events.append(event)
//        } else if event.isPast() {
//            events.insert(event, at: 0)
//        }
//        
//        sortEvents()
//        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
//        print("Event added: \(event.EventName), Start: \(event.StartEventDate), End: \(event.EndEventDate)")
//    }
//
//    var upcomingEvents: [EventsCell] {
//        return events.filter { $0.isUpcoming() }
//    }
//
//    var pastEvents: [EventsCell] {
//        return events.filter { $0.isPast() }
//    }
//
//    func checkAndMoveEvents() {
//        let currentDate = Calendar.current.startOfDay(for: Date())
//        events.forEach { event in
//            guard let startDate = event.startDate else { return }
//            
//            if startDate >= currentDate {
//                if event.isPast() {
//                    events.removeAll { $0.EventName == event.EventName }
//                    events.append(event)
//                }
//            } else {
//                if event.isUpcoming() {
//                    events.removeAll { $0.EventName == event.EventName }
//                    events.insert(event, at: 0)
//                }
//            }
//        }
//        
//        sortEvents()
//    }
//
//    func sortEvents() {
//        events.sort { event1, event2 in
//            guard let date1 = event1.startDate, let date2 = event2.startDate else { return false }
//            return date1 < date2
//        }
//        print("Events after sorting: \(events.map { "\($0.EventName): \($0.StartEventDate)" })")
//    }
//
//    func scheduleDailyEventCheck() {
//        let timer = Timer.scheduledTimer(withTimeInterval: 24 * 60 * 60, repeats: true) { _ in
//            self.checkAndMoveEvents()
//        }
//        RunLoop.current.add(timer, forMode: .common)
//    }
//}
//
//extension EventsCell {
//    var startDate: Date? {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "MM/d/yy" // Adjusted date format
//        
//        return formatter.date(from: self.StartEventDate)
//    }
//    
//    func isUpcoming() -> Bool {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "d/MM/yy"
//        
//        guard let startDate = formatter.date(from: StartEventDate) else { return false }
//        let today = Calendar.current.startOfDay(for: Date())
//        return startDate >= today
//    }
//
//    func isPast() -> Bool {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "d/MM/yy"
//        guard let startDate = formatter.date(from: StartEventDate) else { return false }
//        let today = Calendar.current.startOfDay(for: Date())
//        let isPast = startDate < today
//        return isPast
//    }
//}


/* aadarsh shukla
import Foundation
import UIKit
import FirebaseFirestore
import FirebaseStorage

class DataControllerForEvents {
    static let shared = DataControllerForEvents()
    private var events: [EventsCell] = []
    let db = Firestore.firestore()
    
    private init() {
        fetchDataFromFirestore()
    }
    
    private func fetchDataFromFirestore() {
        db.collection("events").addSnapshotListener { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
            } else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    let eventName = data["EventName"] as? String ?? ""
                    let startEventDate = data["StartEventDate"] as? String ?? ""
                    let endEventDate = data["EndEventDate"] as? String ?? ""
                    let eventLocation = data["EventLocation"] as? String ?? ""
                    let eventImageURL = data["EventImageURL"] as? String ?? ""
                    var eventImage = UIImage(named: "ach1")!
                    Task.init{
                        eventImage = await self.fetchImage(from: eventImageURL)  ?? UIImage(named: "ach1")
                    }
                    
                    
                    let event = EventsCell(
                        EventName: eventName,
                        StartEventDate: startEventDate,
                        EventLocation: eventLocation,
                        EventImpression: "",
                        EventImage: eventImage,
                        EndEventDate: endEventDate
                    )
                    
                    self.events.append(event)
                }
                self.sortEvents()
                self.limitToTwentyEvents()
                NotificationCenter.default.post(name: Notification.Name("EventsFetched"), object: nil)
            }
        }
    }
    
//    private func fetchImage(from url: String) async -> UIImage? {
//        guard let url2 = URL(string: url) else { return nil }
//        
//        print(url2)
//       
////        guard let data = try? await Data(contentsOf: url2) else {
////            print("error in image loading")
////            return nil }
//        
//        Task {
//            let (data,response) = try await URLSession.shared.data(from: url2)
//            
//            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
//                let image = UIImage(data: data)
//                return image
//            }
//            
//            return nil
//        }
//        
//        
//        return nil
//    }
    private func fetchImage(from url: String, completion: @escaping (UIImage?) -> Void) {
        guard let url = URL(string: url) else {
            print("Invalid URL: \(url)")
            completion(nil)
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching image: \(error?.localizedDescription ?? "Unknown error")")
                completion(nil)
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                print("Error: Invalid response")
                completion(nil)
                return
            }
            
            guard let image = UIImage(data: data) else {
                print("Error: Unable to create image from data")
                completion(nil)
                return
            }
            
            completion(image)
        }
        
        task.resume()
    }



//    private func sortEvents() {
//        events.sort {
//            guard let date1 = $0.startDate, let date2 = $1.startDate else { return false }
//            return date1 < date2
//        }
//    }
    private func sortEvents() {
        events.sort {
            guard let date1 = $0.startDate, let date2 = $1.startDate else { return false }
            return date1 > date2 // Sort in descending order by using `>` instead of `<`
        }
    }

    
    private func limitToTwentyEvents() {
        if events.count > 20 {
            events = Array(events.prefix(20))
        }
    }
    
    func addEvent(_ event: EventsCell) {
        events.insert(event, at: 0)
        limitToTwentyEvents()
        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
    }
    

    
    var allEvents: [EventsCell] {
        return events
    }
}

extension EventsCell {
    var startDate: Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter.date(from: self.StartEventDate)
    }
}
 */*/


//import Foundation
//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class DataControllerForEvents {
//    static let shared = DataControllerForEvents()
//    private var events: [EventsCell] = []
//    let db = Firestore.firestore()
//    
//    private init() {
//        fetchDataFromFirestore()
//    }
//    
//    private func fetchDataFromFirestore() {
//        db.collection("events").addSnapshotListener { [weak self] (querySnapshot, error) in
//            guard let self = self else { return }
//            if let error = error {
//                print("Error getting documents: \(error)")
//            } else {
//                var newEvents: [EventsCell] = []
//                
//                let group = DispatchGroup()
//                
//                for document in querySnapshot!.documents {
//                    let data = document.data()
//                    let eventName = data["EventName"] as? String ?? ""
//                    let startEventDate = data["StartEventDate"] as? String ?? ""
//                    let endEventDate = data["EndEventDate"] as? String ?? ""
//                    let eventLocation = data["EventLocation"] as? String ?? ""
//                    let eventImageURL = data["EventImageURL"] as? String ?? ""
//
//                    group.enter()
//                    Task {
//                        let eventImage = await self.fetchImage(from: eventImageURL) ?? UIImage(named: "ach1")!
//                        let event = EventsCell(
//                            EventName: eventName,
//                            StartEventDate: startEventDate,
//                            EventLocation: eventLocation,
//                            EventImpression: "",
//                            EventImage: eventImage,
//                            EndEventDate: endEventDate
//                        )
//                        newEvents.append(event)
//                        group.leave()
//                    }
//                }
//                
//                group.notify(queue: .main) {
//                    print("All images fetched and events created")
//                    self.events = newEvents
//                    self.sortEvents()
//                    self.limitToTwentyEvents()
//                    NotificationCenter.default.post(name: Notification.Name("EventsFetched"), object: nil)
//                }
//            }
//        }
//    }
//    
//    private func fetchImage(from url: String) async -> UIImage? {
//        guard let url = URL(string: url) else {
//            print("Invalid URL: \(url)")
//            return nil
//        }
//        do {
//            let (data, _) = try await URLSession.shared.data(from: url)
//            return UIImage(data: data)
//        } catch {
//            print("Error fetching image: \(error)")
//            return nil
//        }
//    }
//    
//    private func sortEvents() {
//        events.sort {
//            guard let date1 = $0.startDate, let date2 = $1.startDate else { return false }
//            return date1 > date2 // Sort in descending order by using `>` instead of `<`
//        }
//    }
//    
//    private func limitToTwentyEvents() {
//        if events.count > 20 {
//            events = Array(events.prefix(20))
//        }
//    }
//    
//    func addEvent(_ event: EventsCell) {
//        events.insert(event, at: 0)
//        sortEvents()
//        limitToTwentyEvents()
//        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
//    }
//
//    var allEvents: [EventsCell] {
//        return events
//    }
//}
//
//extension EventsCell {
//    var startDate: Date? {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "dd/MM/yyyy"
//        return formatter.date(from: self.StartEventDate)
//    }
//}


//import Foundation
//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class DataControllerForEvents {
//    static let shared = DataControllerForEvents()
//    private var events: [EventsCell] = []
//    let db = Firestore.firestore()
//    let storage = Storage.storage()
//    
//    private init() {
//        fetchDataFromFirestore()
//    }
//    
//    private func fetchDataFromFirestore() {
//        db.collection("events").addSnapshotListener { [weak self] (querySnapshot, error) in
//            guard let self = self else { return }
//            if let error = error {
//                print("Error getting documents: \(error)")
//            } else {
//                var newEvents: [EventsCell] = []
//                let group = DispatchGroup()
//                
//                for document in querySnapshot!.documents {
//                    let data = document.data()
//                    let eventName = data["EventName"] as? String ?? ""
//                    let startEventDate = data["StartEventDate"] as? String ?? ""
//                    let endEventDate = data["EndEventDate"] as? String ?? ""
//                    let eventLocation = data["EventLocation"] as? String ?? ""
//                    let eventImageURL = data["EventImageURL"] as? String ?? ""
//                    
//                    group.enter()
//                    fetchImage(from: eventImageURL) { eventImage in
//                        let event = EventsCell(
//                            EventName: eventName,
//                            StartEventDate: startEventDate,
//                            EventLocation: eventLocation,
//                            EventImpression: "",
//                            EventImage: eventImage ?? UIImage(named: "ach1")!,
//                            EndEventDate: endEventDate
//                        )
//                        newEvents.append(event)
//                        group.leave()
//                    }
//                }
//                
//                group.notify(queue: .main) {
//                    print("All images fetched and events created")
//                    self.events = newEvents
//                    self.sortEvents()
//                    self.limitToTwentyEvents()
//                    NotificationCenter.default.post(name: Notification.Name("EventsFetched"), object: nil)
//                }
//            }
//        }
//    }
//    
//    private func fetchImage(from path: String, completion: @escaping (UIImage?) -> Void) {
//        let storageRef = storage.reference(withPath: path)
//        storageRef.getData(maxSize: Int64.max) { data, error in
//            if let error = error {
//                print("Error fetching image: \(error)")
//                completion(nil)
//            } else if let data = data {
//                completion(UIImage(data: data))
//            } else {
//                completion(nil)
//            }
//        }
//    }
//    
//    private func sortEvents() {
//        events.sort {
//            guard let date1 = $0.startDate, let date2 = $1.startDate else { return false }
//            return date1 >= date2 // Sort in descending order by using `>` instead of `<`
//        }
//    }
//    
//    private func limitToTwentyEvents() {
//        if events.count > 20 {
//            events = Array(events.prefix(20))
//        }
//    }
//    
//    func addEvent(_ event: EventsCell) {
//        events.insert(event, at: 0)
//        sortEvents()
//        limitToTwentyEvents()
//        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
//    }
//
//    var allEvents: [EventsCell] {
//        return events
//    }
//}
//
//extension EventsCell {
//    var startDate: Date? {
//        let formatter = DateFormatter()
//        formatter.dateFormat = "dd/MM/yyyy"
//        return formatter.date(from: self.StartEventDate)
//    }
//}

import Foundation
import UIKit
import FirebaseFirestore

class DataControllerForEvents {
    static let shared = DataControllerForEvents()
    private var events: [EventsCell] = []
    let db = Firestore.firestore()
    
    private init() {
        fetchDataFromFirestore()
    }
    
    private func fetchDataFromFirestore() {
        db.collection("events").addSnapshotListener { [weak self] (querySnapshot, error) in
            guard let self = self else { return }
            if let error = error {
                print("Error getting documents: \(error)")
            } else {
                var newEvents: [EventsCell] = []
                let group = DispatchGroup()
                
                for document in querySnapshot!.documents {
                    let data = document.data()
                    let eventName = data["EventName"] as? String ?? ""
                    let startEventDate = data["StartEventDate"] as? String ?? ""
                    let endEventDate = data["EndEventDate"] as? String ?? ""
                    let eventLocation = data["EventLocation"] as? String ?? ""
                    let eventImageURL = data["EventImageURL"] as? String ?? ""
                    let organizedBy = data["HostedBy"] as? String ?? ""
                    let registrationLink = data["RegistrationLink"] as? String ?? ""
                    let description = data["Description"] as? String ?? ""
                    group.enter()
                    fetchImage(from: eventImageURL) { eventImage in
                        let event = EventsCell(
                            EventName: eventName,
                            StartEventDate: startEventDate,
                            EventLocation: eventLocation,
                            EventImpression: "",
                            EventImage: eventImage ?? UIImage(named: "ach1")!,
                            EndEventDate: endEventDate,
                            OrganizedBy: organizedBy,
                            EventLink: registrationLink,Description: description
                        )
                        newEvents.append(event)
                        group.leave()
                    }
                }
                
                group.notify(queue: .main) {
                    print("All images fetched and events created")
                    self.events = newEvents
                    self.sortEvents()
                    self.limitToTwentyEvents()
                    NotificationCenter.default.post(name: Notification.Name("EventsFetched"), object: nil)
                }
            }
        }
    }
    
    private func fetchImage(from urlString: String, completion: @escaping (UIImage?) -> Void) {
        print("Fetching image from URL: \(urlString)")
        
        guard let url = URL(string: urlString) else {
            print("Invalid URL: \(urlString)")
            completion(nil)
            return
        }

        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error fetching image: \(error)")
                completion(nil)
            } else if let data = data {
                completion(UIImage(data: data))
            } else {
                completion(nil)
            }
        }
        task.resume()
    }
    
    private func sortEvents() {
        events.sort {
            guard let date1 = $0.startDate, let date2 = $1.startDate else { return false }
            return date1 >= date2 // Sort in descending order
        }
    }
    
    private func limitToTwentyEvents() {
        if events.count > 50 {
            events = Array(events.prefix(50))
        }
    }
    
    func addEvent(_ event: EventsCell) {
        events.insert(event, at: 0)
        sortEvents()
        limitToTwentyEvents()
        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
    }

    var allEvents: [EventsCell] {
        return events
    }
}

extension EventsCell {
    var startDate: Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter.date(from: self.StartEventDate)
    }
}
