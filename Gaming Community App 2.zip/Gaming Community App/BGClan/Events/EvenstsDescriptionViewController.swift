//
//  EvenstsDescriptionViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 28/05/24.
//

import UIKit

class EvenstsDescriptionViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate


   {
      
        let tableView = UITableView()

        let flights = [
            ["from": "Kolkata", "to": "Mumbai", "date": "09 DEC 22", "id": "XVH12H"],
            ["from": "New York City", "to": "Paris", "date": "09 DEC 22", "id": "2256HD"],
            ["from": "Lisbon", "to": "Wellington", "date": "09 DEC 22", "id": "MC34HY"]
        ]

        override func viewDidLoad() {
            super.viewDidLoad()
            
            tableView.dataSource = self
            tableView.delegate = self
            tableView.register(EventsDataTableViewCell.self, forCellReuseIdentifier: "descriptionCell")
            
            view.addSubview(tableView)
            tableView.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                tableView.topAnchor.constraint(equalTo: view.topAnchor),
                tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])
        }

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return flights.count
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "descriptionCell", for: indexPath) as! EventsDataTableViewCell
            let flight = flights[indexPath.row]
            
            cell.fromCityLabel.text = flight["from"]
            cell.toCityLabel.text = flight["to"]
            cell.dateLabel.text = flight["date"]
            cell.idLabel.text = flight["id"]
            
            return cell
        }
    }

    

   


