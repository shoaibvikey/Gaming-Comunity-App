//
//  EventViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 16/05/24.
//

import UIKit

class EventViewController: UIViewController {

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "Events"
        self .tabBarItem.image = UIImage(systemName: "calendar")
    }
    
   
    @IBOutlet weak var UpcomingEventView: UIView!
//    @IBOutlet weak var segmentControllerEvents: UISegmentedControl!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.bringSubviewToFront(UpcomingEventView)
        UpcomingEventView.reloadInputViews()

        // Do any additional setup after loading the view.
    }
    
//    @IBAction func segmentControllerEventsIBAction(_ sender: UISegmentedControl) {
//        switch segmentControllerEvents.selectedSegmentIndex{
//        case 0:
//            self.view.bringSubviewToFront(UpcomingEventView)
//            //NavigationOutlet.title = "Create Post"
//        case 1:/Users/vineet/Desktop/Pull from SH on 31 May copy/GU-C1-T05-CasterCom/BGClan/Events/EventViewController.swift
//            print(" ")
//            self.view.bringSubviewToFront(PastEventView)
//            
//        default:
//            break
//        }
//    }
    

  

}
