//
//  UpcomingEventsViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 24/05/24.
/*

import UIKit


class UpcomingEventsViewController: UIViewController {
    var events:[EventsCell]=[]
    
    

    

   

    
    
    
    
    @IBOutlet weak var EventsTableViewController: UITableView!
    
    



    override func viewDidLoad() {
            super.viewDidLoad()
            EventsTableViewController.delegate = self
            EventsTableViewController.dataSource = self
            EventsTableViewController.register(UINib(nibName: "EventsTableViewCell", bundle: nil), forCellReuseIdentifier: "eventcell")
          
            NotificationCenter.default.addObserver(self, selector: #selector(eventsUpdated), name: Notification.Name("EventsFetched"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(eventsUpdated), name: Notification.Name("NewEventAdded"), object: nil)
            
            loadEvents()
        }
        
        @objc func eventsUpdated() {
            loadEvents()
        }
        
        func loadEvents() {
            events = DataControllerForEvents.shared.upcomingEvents
            EventsTableViewController.reloadData()
        }
        
        deinit {
            NotificationCenter.default.removeObserver(self)
        }
    }

    extension UpcomingEventsViewController: UITableViewDelegate, UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return events.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "eventcell", for: indexPath) as! EventsTableViewCell
            let event = events[indexPath.row]
            
            cell.EventNameLabelOutlet.text = event.EventName
            cell.StartingEventDateOutlet.text = event.StartEventDate
            cell.EndingEventDateOutlet.text = event.EndEventDate
            cell.EventLocationOutlet.text = event.EventLocation
            cell.EventImpressionOutlet.text = event.EventImpression
            cell.EventImageViewOutlet.image = event.EventImage
            
            return cell
        }

        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 145
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            performSegue(withIdentifier: "eventSegue", sender: self)
        }
    }
*/

import UIKit

class UpcomingEventsViewController: UIViewController {
    var events: [EventsCell] = []
    
    @IBOutlet weak var eventsTableView: UITableView! // Ensure this matches the storyboard
    override func viewWillAppear(_ animated: Bool) {
     super.viewWillAppear(animated)
        loadEvents()
    }
    
    
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "Events"
        self .tabBarItem.image = UIImage(systemName: "calendar")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        eventsTableView.delegate = self
        eventsTableView.dataSource = self
        eventsTableView.register(UINib(nibName: "EventsTableViewCell", bundle: nil), forCellReuseIdentifier: "eventcell")
        
        NotificationCenter.default.addObserver(self, selector: #selector(eventsUpdated), name: Notification.Name("EventsFetched"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(eventsUpdated), name: Notification.Name("NewEventAdded"), object: nil)
        
        loadEvents()
//        eventsTableView.reloadData()
    }
    
    @objc func eventsUpdated() {
        loadEvents()
    }
    
    func loadEvents() {
        events = DataControllerForEvents.shared.allEvents
        eventsTableView.reloadData()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "EventDetail" {
                if let destinationVC = segue.destination as? EventDetailTableViewController,
                   let selectedIndex = eventsTableView.indexPathForSelectedRow?.row {
                    let selectedEvent = events[selectedIndex]
                    destinationVC.event = selectedEvent
                }
            }
        }
        
}

extension UpcomingEventsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "eventcell", for: indexPath) as! EventsTableViewCell
        let event = events[indexPath.row]
        
        cell.EventNameLabelOutlet.text = event.EventName
        cell.StartingEventDateOutlet.text = event.StartEventDate
        cell.EndingEventDateOutlet.text = event.EndEventDate
        cell.EventLocationOutlet.text = event.EventLocation
        cell.EventImpressionOutlet.text = event.EventImpression
        cell.EventImageViewOutlet.image = event.EventImage
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 145
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "EventDetail", sender: self)
    }
}
