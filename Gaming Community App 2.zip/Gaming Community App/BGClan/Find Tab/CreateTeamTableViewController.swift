//
//  CreateTeamTableViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 01/06/24.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class CreateTeamTableViewController: UITableViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    
    @IBOutlet weak var teamLogoOutlet: UIImageView!
    @IBOutlet weak var teamNameOutlet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
        self.navigationItem.rightBarButtonItem = doneButton
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(teamLogoTapped))
                teamLogoOutlet.isUserInteractionEnabled = true
                teamLogoOutlet.addGestureRecognizer(tapGestureRecognizer)
      
    }
    @objc func doneButtonTapped() {
           // Handle the done button actio
           // You can add your code here to dismiss the view controller or save the data
        guard let teamName = teamNameOutlet.text else { return }

                // Upload team name to Firestore
        let db = Firestore.firestore()
            let teamRef = db.collection("teams").document() // Use a unique document ID for each team
            teamRef.setData(["teamName": teamName]) { error in
                if let error = error {
                    print("Error adding document: \(error)")
                } else {
                    print("Team name added to Firestore")

                    // Upload team image to Firebase Storage
                    if let imageData = self.teamLogoOutlet.image?.jpegData(compressionQuality: 0.5) {
                        let storageRef = Storage.storage().reference().child("team_images").child(UUID().uuidString)
                        let metadata = StorageMetadata()
                        metadata.contentType = "image/jpeg"
                        storageRef.putData(imageData, metadata: metadata) { (metadata, error) in
                            if let error = error {
                                print("Error uploading image to storage: \(error)")
                            } else {
                                print("Image uploaded successfully.")
                                storageRef.downloadURL { (url, error) in
                                    if let imageURL = url {
                                        print("Image URL: \(imageURL)")
                                        
                                        // Update Firestore document with image URL
                                        teamRef.updateData(["imageUrl": imageURL.absoluteString]) { error in
                                            if let error = error {
                                                print("Error updating document with image URL: \(error)")
                                            } else {
                                                print("Image URL added to Firestore")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        print("Error: Image data is nil.")
                    }
                }
            }

            performSegue(withIdentifier: "createdTeamSegue", sender: self)
        }

        
    
    @objc func teamLogoTapped() {
            let alert = UIAlertController(title: "Select Photo", message: "Choose from camera or gallery", preferredStyle: .actionSheet)
            
            alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                self.openCamera()
            }))
            
            alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                self.openGallery()
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
    func openCamera() {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .camera
                imagePicker.allowsEditing = true
                self.present(imagePicker, animated: true, completion: nil)
            } else {
                let alert = UIAlertController(title: "Error", message: "Camera not available", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    func openGallery() {
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary
                imagePicker.allowsEditing = true
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let editedImage = info[.editedImage] as? UIImage {
                teamLogoOutlet.image = editedImage
            } else if let originalImage = info[.originalImage] as? UIImage {
                teamLogoOutlet.image = originalImage
            }
            picker.dismiss(animated: true, completion: nil)
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "createdTeamSegue" {
                if let destinationVC = segue.destination as? TeamDashboardTableViewController {
                    destinationVC.teamName = teamNameOutlet.text
                    destinationVC.teamLogo = teamLogoOutlet.image
                }
            }
        }

}
