//
//  FilterTeammateViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 02/06/24.
//

import UIKit

class FilterTeammateViewController: UIViewController {
    
    @IBOutlet weak var selectRoleTextLabelOutlet: UITextField!
    @IBOutlet weak var selectAgeTextLabelOutlet: UITextField!
    @IBOutlet weak var selectLocationTextLabelOutlet: UITextField!
    @IBOutlet weak var selectDeviceTextLabelOutlet: UITextField!
    
    let roles = ["Entry Fragger","Assaulter","Support","Medic","Scout","Sniper","In-Game Leader"]
    let age = ["Below 16","Between 16 to 20","Between 20 to 23","23 & above"]
    let device = ["iPhone 15 series","iPhone 15 pro series","iPhone 14 series","iPhone 14 pro series","iPhone 13 series","iPhone 13 pro series","ipad Mini","Other iPads","Other iPhones"]
    let location = ["Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"]
    
    var rolePickerView = UIPickerView()
    var agePickerView = UIPickerView()
    var devicePickerView = UIPickerView()
    var locationPickerView = UIPickerView()
    
    var selectedRole: String?
    var selectedAge: String?
    var selectedDevice: String?
    var selectedLocation: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        selectRoleTextLabelOutlet.inputView = rolePickerView
        selectAgeTextLabelOutlet.inputView = agePickerView
        selectLocationTextLabelOutlet.inputView = locationPickerView
        selectDeviceTextLabelOutlet.inputView = devicePickerView
        
        selectRoleTextLabelOutlet.placeholder = "Select Role"
        selectAgeTextLabelOutlet.placeholder = "Select Age Range"
        selectLocationTextLabelOutlet.placeholder = "Select Location"
        selectDeviceTextLabelOutlet.placeholder = "Select Device"
        
        selectRoleTextLabelOutlet.textAlignment = .center
        selectAgeTextLabelOutlet.textAlignment = .center
        selectLocationTextLabelOutlet.textAlignment = .center
        selectDeviceTextLabelOutlet.textAlignment = .center
        
        rolePickerView.delegate = self
        rolePickerView.dataSource = self
        agePickerView.delegate = self
        agePickerView.dataSource = self
        devicePickerView.delegate = self
        devicePickerView.dataSource = self
        locationPickerView.delegate = self
        locationPickerView.dataSource = self
        
        rolePickerView.tag = 1
        agePickerView.tag = 2
        devicePickerView.tag = 3
        locationPickerView.tag = 4

    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "showFilteredResults" {
                if let destinationVC = segue.destination as? ResultsSearchTeammateViewController {
                    destinationVC.selectedRole = selectedRole
                    destinationVC.selectedAge = selectedAge
                    destinationVC.selectedDevice = selectedDevice
                    destinationVC.selectedLocation = selectedLocation
                }
            }
        }



}
extension FilterTeammateViewController : UIPickerViewDataSource,UIPickerViewDelegate{
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch pickerView.tag{
        case 1:
            return roles.count
        case 2:
            return age.count
        case 3:
            return device.count
        case 4:
            return location.count
        default:
            return 1
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch pickerView.tag{
        case 1:
            return roles[row]
        case 2:
            return age[row]
        case 3:
            return device[row]
        case 4:
            return location[row]
        default:
            return "Data not Found"
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch pickerView.tag{
        case 1:
            selectRoleTextLabelOutlet.text = roles[row]
            selectedRole = roles[row]
            selectRoleTextLabelOutlet.resignFirstResponder()
        case 2:
            selectAgeTextLabelOutlet.text = age[row]
            selectedAge = age[row]
            selectAgeTextLabelOutlet.resignFirstResponder()
        case 3:
            selectDeviceTextLabelOutlet.text = device[row]
            selectedDevice = device[row]
            selectDeviceTextLabelOutlet.resignFirstResponder()
        case 4:
            selectLocationTextLabelOutlet.text = location[row]
            selectedLocation = location[row]
            selectLocationTextLabelOutlet.resignFirstResponder()
        default:
            return
        }
    }
    
}
