//
//  JoinTeamViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 30/05/24.
//

import UIKit

class JoinTeamViewController: UIViewController {

    @IBOutlet weak var TeamsSerchResultTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}

