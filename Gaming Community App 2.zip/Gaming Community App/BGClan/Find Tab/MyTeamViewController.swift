//
//  MyTeamViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 28/05/24.
//

import UIKit

class MyTeamViewController: UIViewController {

    
    @IBOutlet weak var TeamNotJoinContainerOutlet: UIView!
    @IBOutlet weak var TeamDashboardCointainerOutlet: UIView!
    
    var teamStatus = false
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "My Team"
        self .tabBarItem.image = UIImage(systemName: "person.3")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if teamStatus == false {
            self.view.bringSubviewToFront(TeamNotJoinContainerOutlet)
        }else{
            self.view.bringSubviewToFront(TeamDashboardCointainerOutlet)
        }
      
    }
    func showAlert(){
        let alert = UIAlertController(title: "Team not found", message: "Currently you are not a member of team.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Create a Team", style: .default, handler: {action in self.performSegue(withIdentifier: "CreateTeamsSegue", sender: self)}))
        alert.addAction(UIAlertAction(title: "Join a Team", style: .default, handler: {action in self.performSegue(withIdentifier: "JoinTeamSegue", sender: self)}))
        
        
        present(alert,animated: true,completion: nil)
        
    }

}
