//
//  PlayerProfileViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 05/06/24.
//

import UIKit

class PlayerProfileViewController: UIViewController {
    
    @IBOutlet weak var joinPlayerButtonOutlet: UIButton!
    @IBOutlet weak var playerNameLabelOutlet: UILabel!
    var user: UserModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let user = user {
                    print("View loaded with user: \(user.fullName)")
                    playerNameLabelOutlet.text = user.fullName
                }
        
    }
    
    @IBAction func joinPlayerButtonTapped(_ sender: UIButton) {
        print("Join button tapped")
        performSegue(withIdentifier: "unwindToTeamDashboard", sender: self)
        }

}
