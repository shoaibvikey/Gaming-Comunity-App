import UIKit
import Firebase
import FirebaseStorage
import FirebaseFirestore
import FirebaseAuth

class ResultsSearchTeamViewController: UIViewController {
    
    @IBOutlet weak var teamSearchBar: UISearchBar!
    @IBOutlet weak var TeamSearchResultTableviewController: UITableView!
    
    var searchResults: [Team] = []
    var teams : [Team]=[]
    //    var teams: [Team] = [
    //        Team(teamName: "Team Soul", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Godlike Esports", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Carnival Gaming", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Healthpower Esports", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Global Esports", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Reckoning Esports", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Team Tamilas", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Revenant Esports", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Team Insane", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Team Xspark", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Hydrabad Hydras", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3"),
    //        Team(teamName: "Team Entity", teamTag: "fdshhdf", currentMembers: 3, isTeamComplete: false, numberOfEventsPlayed: 15, teamTier: "3")
    //    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        teamSearchBar.delegate = self
        
        TeamSearchResultTableviewController.dataSource = self
        TeamSearchResultTableviewController.delegate = self
        TeamSearchResultTableviewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
        
        //        searchResults = teams
        fetchTeams()
    }
    func fetchTeams() {
        let db = Firestore.firestore()
        db.collection("teams").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error)")
            } else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    if let teamName = data["teamName"] as? String, let pictureUrl = data["imageUrl"] as? String {
                        let team = Team(teamName: teamName, teamTag: "", currentMembers: 0, isTeamComplete: false, numberOfEventsPlayed: 0, teamTier: "", teamImage: pictureUrl)
                        self.teams.append(team)
                    }
                }
                self.searchResults = self.teams
                self.TeamSearchResultTableviewController.reloadData()
            }
        }
    }
    
    func fetchImage(url: String, completion: @escaping (UIImage?) -> Void) {
        let storage = Storage.storage()
        let storageRef = storage.reference(forURL: url)
        storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
            if let error = error {
                print("Error fetching image: \(error)")
                completion(nil)
            } else if let data = data {
                let image = UIImage(data: data)
                print("Image fetch")
                completion(image)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "teamDashboardSegue" {
            if let destinationVC = segue.destination as? TeamDashboardForAllTableViewController,
               let selectedIndex = TeamSearchResultTableviewController.indexPathForSelectedRow?.row {
                destinationVC.teamName = searchResults[selectedIndex].teamName
                
            }
        }
    }
}

extension ResultsSearchTeamViewController: UITableViewDelegate {
   
}

extension ResultsSearchTeamViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResults.count
    }
    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//        cell.SearchUsernameOutlet?.text = searchResults[indexPath.row].teamName
////        cell.SearchProfileImageView?.image = searchResults[indexPath.row].teamImage
//        return cell
//    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
            let team = searchResults[indexPath.row]
            cell.SearchUsernameOutlet?.text = team.teamName

            // Use a placeholder image initially
            cell.SearchProfileImageView?.image = UIImage(named: "placeholder")
            
            if let pictureUrl = team.teamImage {
                fetchImage(url: pictureUrl) { image in
                    DispatchQueue.main.async {
                        if let image = image {
                            cell.SearchProfileImageView?.image = image
                        } else {
                            cell.SearchProfileImageView?.image = UIImage(named: "placeholder") // Use a placeholder image
                        }
                    }
                }
            } else {
                cell.SearchProfileImageView?.image = UIImage(named: "placeholder") // Use a placeholder image
            }

            return cell
        }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
  
}

extension ResultsSearchTeamViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searchResults = teams
        } else {
            searchResults = teams.filter { $0.teamName.lowercased().contains(searchText.lowercased()) }
        }
        TeamSearchResultTableviewController.reloadData()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "teamDashboardSegue", sender: self)
    }
    
}
//?by divyanshu
//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
//
//class ResultsSearchTeamViewController: UIViewController {
//    
//    @IBOutlet weak var teamSearchBar: UISearchBar!
//    @IBOutlet weak var teamSearchResultTableViewController: UITableView!
//    
//    var searchResults: [String] = []
//    var teams: [String] = []
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        teamSearchBar.delegate = self
//        
//        teamSearchResultTableViewController.dataSource = self
//        teamSearchResultTableViewController.delegate = self
//        teamSearchResultTableViewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
//        
//        fetchTeams()  // Fetch teams from Firestore
//    }
//    
//    func fetchTeams() {
//        let db = Firestore.firestore()
//        
//        db.collection("teams").getDocuments { (querySnapshot, error) in
//            if let error = error {
//                print("Error getting documents: \(error)")
//                return
//            }
//            
//            self.teams = querySnapshot?.documents.compactMap { document in
//                let data = document.data()
//                guard let teamName = data["teamname"] as? String,
//                      let profilePictureURL = data["profilePictureURL"] as? String else {
//                    return ""
//                    
//                }
//                //              by d     return TeamModel(teamName: teamName, profilePictureURL: profilePictureURL)
//            } ?? [] as! [String]
//            
//            self.searchResults = self.teams
//            //             by d  self.teamSearchResultTableView.reloadData()
//        }
//    }
//    
//    //       override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//    //           if segue.identifier == "teamDashboardSegue" {
//    //               if let destinationVC = segue.destination as? TeamDashboardForAllTableViewController,
//    //                  let selectedIndex = teamSearchResultTableView.indexPathForSelectedRow?.row {
//    //                   destinationVC.teamName = searchResults[selectedIndex].teamName
//    //               }
//    //           }
//    //       }
//    //   }by d
//}
//   extension ResultsSearchTeamViewController: UITableViewDelegate {}
//
//   extension ResultsSearchTeamViewController: UITableViewDataSource {
//       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//           return searchResults.count
//       }
//       
//       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//           let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//           let team = searchResults[indexPath.row]
//           cell.SearchUsernameOutlet?.text = team.teamName
//           
//           if let profilePictureURL = team.profilePictureURL, !profilePictureURL.isEmpty {
//               fetchProfilePicture(url: profilePictureURL) { image in
//                   DispatchQueue.main.async {
//                       cell.SearchProfileImageView.image = image ?? UIImage(named: "default_profile")  // Placeholder image
//                   }
//               }
//           } else {
//               cell.SearchProfileImageView.image = UIImage(named: "default_profile")  // Placeholder image
//           }
//           
//           return cell
//       }
//       
//       func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//           return 56
//       }
//   }
//
//   extension ResultsSearchTeamViewController: UISearchBarDelegate {
//       func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//           if searchText.isEmpty {
//               searchResults = teams
//           } else {
//               searchResults = teams.filter { $0.teamName.lowercased().contains(searchText.lowercased()) }
//           }
//           ResultsSearchTableViewCell.reloadData()
//       }
//       
//       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//           performSegue(withIdentifier: "teamDashboardSegue", sender: self)
//       }
//   }
//
//   extension ResultsSearchTeamViewController {
//       func fetchProfilePicture(url: String, completion: @escaping (UIImage?) -> Void) {
//           let storageRef = Storage.storage().reference(forURL: url)
//           storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
//               if let error = error {
//                   print("Error downloading profile picture: \(error.localizedDescription)")
//                   completion(nil)
//               } else {
//                   if let data = data {
//                       completion(UIImage(data: data))
//                   } else {
//                       completion(nil)
//                   }
//               }
//           }
//       }
//   }
//
//   struct TeamModel {
//       var teamName: String
//       var profilePictureURL: String?
//   }
