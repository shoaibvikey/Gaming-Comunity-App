//
//  ResultsSearchTeammateViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 26/05/24.


//import UIKit
//
//class ResultsSearchTeammateViewController: UIViewController, UITableViewDelegate {
//
//    var searchResults : [UserModel] = []
//
//    var users : [UserModel] = [
//        UserModel(fullName: "Shoaib", email: "shoaib@team5.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "shoaibvikey", teamStatus: true, age: 21, device: "iPhone 14 series", location: "Andhra Pradesh", profilePictureURL: ""),
//        UserModel(fullName: "Vineet", email: "vineet@team5.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "vineetchaudary", teamStatus: true, age: 22, device:"iPhone 15 series" , location: "Uttar Pradesh", profilePictureURL: ""),
//        UserModel(fullName: "Divyanshu", email: "divyanshu@team5.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "divyanshurai", teamStatus: false, age: 20, device: "iPhone 15 pro series", location: nil, profilePictureURL: ""),
//        UserModel(fullName: "Adarsh", email: "adarsh@team5.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "adarshshukla", teamStatus: false, age: 19, device:"iPhone 14 series", location: nil, profilePictureURL: ""),
//        UserModel(fullName: "Naman", email: "naman@user.com", phoneNumber: 7448487378, userInGameRole: "IGL", userName: "namanbansal", teamStatus: false, age: 21, device: "iPhone 14 pro series", location: nil, profilePictureURL: ""),
//        UserModel(fullName: "Anunay", email: "anunay@user.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "anunaykumar", teamStatus: true, age: 22, device:"iPhone 13 series", location: nil, profilePictureURL: ""),
//        UserModel(fullName: "Amritanshu", email: "Amritanshu@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "ammytanshu", teamStatus: false, age: 20, device: "Other iPhones", location: nil, profilePictureURL: ""),
//    //                UserModel(fullName: "Harsh", lastName: "Aggarwal", email: "harsh@user.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "harshaggarwal", teamStatus: false, age: 19, device: "ipad Mini", location: nil),
//    //                UserModel(fullName: "Varsha", lastName: "Sharma", email: "varsha@user.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "varshasharma", teamStatus: false, age: 21, device: "Other iPhones", location: nil),
//    //                UserModel(fullName: "Khushi", lastName: "Tomar", email: "Khushi@user.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "khushitomar", teamStatus: true, age: 22, device: "iPhone 15 series", location: nil),
//    //                UserModel(fullName: "Nand", lastName: "Kishore", email: "kishore@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "nandkishore", teamStatus: false, age: 20, device: "iPhone 14 series", location: nil),
//    //                UserModel(fullName: "Shalu", lastName: "Tiwari", email: "shalu@user.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "shalutiwari", teamStatus: false, age: 19, device: "iPhone 14 series", location: nil),
//    //                UserModel(fullName: "Niharika", lastName: "Sharma", email: "shoaib@team5.com", phoneNumber: 7448497378, userInGameRole: "IGL", userName: "niharikasharma", teamStatus: false, age: 21, device: "iPhone 15 series", location: nil),
//    //                UserModel(fullName: "Vinod", lastName: "Kumar", email: "vinod@team5.com", phoneNumber: 9772336823, userInGameRole: "Support", userName: "vinodkumar", teamStatus: true, age: 22, device: "iPhone 14 series", location: nil),
//    //                UserModel(fullName: "Kanishka", lastName: "Garg", email: "kanishka@user.com", phoneNumber: 7888932831, userInGameRole: "Assaulter", userName: "gargkanishka", teamStatus: false, age: 20, device: "iPhone 14 series", location: nil),
//    //                UserModel(fullName: "Vanshika", email: "adarsh@team5.com", phoneNumber: 8967468684, userInGameRole: "Entry Fragger", userName: "singhvanshika", teamStatus: false, age: 19, device:"iPhone 14 series", location: nil)
//    ]
//    
//    var selectedRole: String?
//    var selectedAge: String?
//    var selectedDevice: String?
//    var selectedLocation: String?
//    var selectedUser: UserModel?
//    
//    @IBOutlet weak var TeammateSearchResultTableviewController: UITableView!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        TeammateSearchResultTableviewController.dataSource=self
//        TeammateSearchResultTableviewController.delegate=self
//        TeammateSearchResultTableviewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
//        filterResults()
//    }
//    
//    func filterResults() {
//            searchResults = users.filter { !$0.teamStatus }
//            
//            if let role = selectedRole, !role.isEmpty {
//                searchResults = searchResults.filter { $0.userInGameRole == role }
//            }
//            
//            if let ageRange = selectedAge, !ageRange.isEmpty {
//                switch ageRange {
//                case "Below 16":
//                    searchResults = searchResults.filter { $0.age < 16 }
//                case "Between 16 to 20":
//                    searchResults = searchResults.filter { $0.age >= 16 && $0.age <= 20 }
//                case "Between 20 to 23":
//                    searchResults = searchResults.filter { $0.age >= 20 && $0.age <= 23 }
//                case "23 & above":
//                    searchResults = searchResults.filter { $0.age > 23 }
//                default:
//                    break
//                }
//            }
//            
//            if let device = selectedDevice, !device.isEmpty {
//                searchResults = searchResults.filter { $0.device == device }
//            }
//            
//            if let location = selectedLocation, !location.isEmpty {
//                searchResults = searchResults.filter { $0.location == location }
//            }
//            
//            TeammateSearchResultTableviewController.reloadData()
//        }
//    }
//
//extension ResultsSearchTeammateViewController : UITableViewDataSource{
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return searchResults.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//        
//        cell.SearchUsernameOutlet?.text = searchResults[indexPath.row].userName
//  
//        return cell
//    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        selectedUser = searchResults[indexPath.row]
//        performSegue(withIdentifier: "playerProfileSegue", sender: self)
//    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "playerProfileSegue" {
//            if let destinationVC = segue.destination as? PlayerProfileViewController {
//                destinationVC.user = selectedUser
//            }
//        }
//    }
//    
//    
//    
//  
//}
//
//
//
//  ResultsSearchTeammateViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 26/05/24.
//
//
//import UIKit
//import FirebaseFirestore
//import FirebaseStorage
////import SDWebImage
//
//class ResultsSearchTeammateViewController: UIViewController, UITableViewDelegate {
//
//    var searchResults : [UserModel] = []
//    var users : [UserModel] = []
//    
//    var selectedRole: String?
//    var selectedAge: String?
//    var selectedDevice: String?
//    var selectedLocation: String?
//    var selectedUser: UserModel?
//    
//    @IBOutlet weak var TeammateSearchResultTableviewController: UITableView!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        TeammateSearchResultTableviewController.dataSource = self
//        TeammateSearchResultTableviewController.delegate = self
//        TeammateSearchResultTableviewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
//        
//        fetchUsers()
//    }
//    
//    func fetchUsers() {
//        let db = Firestore.firestore()
//        
//        db.collection("users").getDocuments { (querySnapshot, error) in
//            if let error = error {
//                print("Error getting documents: \(error)")
//            } else {
//                self.users = querySnapshot?.documents.compactMap { document -> UserModel? in
//                    let data = document.data()
//                    let fullName = data["fullName"] as? String ?? ""
//                    let email = data["email"] as? String ?? ""
//                    let phoneNumber = data["phoneNumber"] as? Int ?? 0
//                    let userInGameRole = data["userInGameRole"] as? String ?? ""
//                    let userName = data["userName"] as? String ?? ""
//                    let teamStatus = data["teamStatus"] as? Bool ?? false
//                    let age = data["age"] as? Int ?? 0
//                    let device = data["device"] as? String
//                    let location = data["location"] as? String
//                    let profilePictureURL = data["profilePictureURL"] as? String
//                    
//                    return UserModel(fullName: fullName, email: email, phoneNumber: phoneNumber, userInGameRole: userInGameRole, userName: userName, teamStatus: teamStatus, age: age, device: device, location: location, profilePictureURL: profilePictureURL)
//                } ?? []
//                
//                self.searchResults = self.users
//                self.TeammateSearchResultTableviewController.reloadData()
//            }
//        }
//    }
//    
//    func filterResults() {
//        searchResults = users.filter { !$0.teamStatus }
//        
//        if let role = selectedRole, !role.isEmpty {
//            searchResults = searchResults.filter { $0.userInGameRole == role }
//        }
//        
//        if let ageRange = selectedAge, !ageRange.isEmpty {
//            switch ageRange {
//            case "Below 16":
//                searchResults = searchResults.filter { $0.age < 16 }
//            case "Between 16 to 20":
//                searchResults = searchResults.filter { $0.age >= 16 && $0.age <= 20 }
//            case "Between 20 to 23":
//                searchResults = searchResults.filter { $0.age >= 20 && $0.age <= 23 }
//            case "23 & above":
//                searchResults = searchResults.filter { $0.age > 23 }
//            default:
//                break
//            }
//        }
//        
//        if let device = selectedDevice, !device.isEmpty {
//            searchResults = searchResults.filter { $0.device == device }
//        }
//        
//        if let location = selectedLocation, !location.isEmpty {
//            searchResults = searchResults.filter { $0.location == location }
//        }
//        
//        TeammateSearchResultTableviewController.reloadData()
//    }
//}
//
//extension ResultsSearchTeammateViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return searchResults.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//        
//        let user = searchResults[indexPath.row]
//        cell.SearchUsernameOutlet.text = user.userName
////        cell.inGameRoleLabel.text = user.userInGameRole
//        cell.SearchProfileImageView.image = user.profilePictureURL
////        cell.userNameLabel.text = user.userName
//        
//        if let profilePictureURL = user.profilePictureURL {
//            cell.profileImageView.sd_setImage(with: URL(string: profilePictureURL), placeholderImage: UIImage(named: "placeholder.png"))
//        } else {
//            cell.profileImageView.image = UIImage(named: "placeholder.png")
//        }
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        selectedUser = searchResults[indexPath.row]
//        performSegue(withIdentifier: "playerProfileSegue", sender: self)
//    }
//    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "playerProfileSegue" {
//            if let destinationVC = segue.destination as? PlayerProfileViewController {
//                destinationVC.user = selectedUser
//            }
//        }
//    }
//}
//
//extension ResultsSearchTeammateViewController: UISearchBarDelegate {
//    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        if searchText.isEmpty {
//            searchResults = users
//        } else {
//            searchResults = users.filter { $0.userName.lowercased().contains(searchText.lowercased()) }
//        }
//        TeammateSearchResultTableviewController.reloadData()
//    }
//    
//    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
//        searchBar.resignFirstResponder()
//    }
//}



//import Firebase
//import FirebaseStorage
//import FirebaseFirestore
//
//class ResultsSearchTeammateViewController: UIViewController {
//
//    var searchResults: [UserModel] = []
//    var users: [UserModel] = []
//    var selectedRole: String?
//    var selectedAge: String?
//    var selectedDevice: String?
//    var selectedLocation: String?
//    var selectedUser: UserModel?
//    
//    @IBOutlet weak var TeammateSearchResultTableviewController: UITableView!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        TeammateSearchResultTableviewController.dataSource = self
//        TeammateSearchResultTableviewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
//        fetchUsers()
//    }
//    
//    func fetchUsers() {
//        let db = Firestore.firestore()
//        
//        db.collection("users").getDocuments { (querySnapshot, error) in
//            if let error = error {
//                print("Error getting documents: \(error)")
//            } else {
//                self.users = querySnapshot?.documents.compactMap { document -> UserModel? in
//                    let data = document.data()
//                    let fullName = data["fullName"] as? String ?? ""
//                    let email = data["email"] as? String ?? ""
//                    let phoneNumber = data["phoneNumber"] as? Int ?? 0
//                    let userInGameRole = data["userInGameRole"] as? String ?? ""
//                    let userName = data["userName"] as? String ?? ""
//                    let teamStatus = data["teamStatus"] as? Bool ?? false
//                    let age = data["age"] as? Int ?? 0
//                    let device = data["device"] as? String
//                    let location = data["location"] as? String
//                    let profilePictureURL = data["profilePictureURL"] as? String
//                    
//                    return UserModel(fullName: fullName, email: email, phoneNumber: phoneNumber, userInGameRole: userInGameRole, userName: userName, teamStatus: teamStatus, age: age, device: device, location: location, profilePictureURL: profilePictureURL)
//                } ?? []
//                
//                self.searchResults = self.users
//                self.TeammateSearchResultTableviewController.reloadData()
//            }
//        }
//    }
//}
//
//extension ResultsSearchTeammateViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return searchResults.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//        
//        let user = searchResults[indexPath.row]
//        cell.SearchUsernameOutlet.text = user.fullName
//        
//        if let profilePictureURL = user.profilePictureURL {
//            // Load profile picture from Firebase Storage
//            let storageRef = Storage.storage().reference(forURL: profilePictureURL)
//            storageRef.getData(maxSize: 1 * 1024 * 1024) { data, error in
//                if let error = error {
//                    print("Error downloading image: \(error)")
//                    cell.SearchProfileImageView.image = UIImage(named: "placeholder.png")
//                } else {
//                    if let data = data, let image = UIImage(data: data) {
//                        cell.SearchProfileImageView.image = image
//                    } else {
//                        cell.SearchProfileImageView.image = UIImage(named: "placeholder.png")
//                    }
//                }
//            }
//        } else {
//            // Use a placeholder image if no profile picture URL is provided
//            cell.SearchProfileImageView.image = UIImage(named: "placeholder.png")
//        }
//        
//        return cell
//    }
//}


//Latest Working
//import Firebase
//import FirebaseStorage
//import FirebaseFirestore
//
//class ResultsSearchTeammateViewController: UIViewController ,UITableViewDelegate{
//
//    var searchResults: [UserModel] = []
//    var users: [UserModel] = []
//    var selectedRole: String?
//    var selectedAge: String?
//    var selectedDevice: String?
//    var selectedLocation: String?
//    var selectedUser: UserModel?
//    
//    @IBOutlet weak var TeammateSearchResultTableviewController: UITableView!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        TeammateSearchResultTableviewController.delegate=self
//        TeammateSearchResultTableviewController.dataSource = self
//        TeammateSearchResultTableviewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
//        fetchUsers()
//    }
//    
//    func fetchUsers() {
//        let db = Firestore.firestore()
//        
//        db.collection("users").getDocuments { (querySnapshot, error) in
//            if let error = error {
//                print("Error getting documents: \(error)")
//            } else {
//                self.users = querySnapshot?.documents.compactMap { document -> UserModel? in
//                    let data = document.data()
//                    let fullName = data["fullName"] as? String ?? ""
//                    let email = data["email"] as? String ?? ""
//                    let phoneNumber = data["phoneNumber"] as? Int ?? 0
//                    let userInGameRole = data["userInGameRole"] as? String ?? ""
//                    let userName = data["userName"] as? String ?? ""
//                    let teamStatus = data["teamStatus"] as? Bool ?? false
//                    let age = data["age"] as? Int ?? 0
//                    let device = data["device"] as? String
//                    let location = data["location"] as? String
//                    let profilePictureURL = data["profilePictureURL"] as? String
//                    
//                    return UserModel(fullName: fullName, email: email, phoneNumber: phoneNumber, userInGameRole: userInGameRole, userName: userName, teamStatus: teamStatus, age: age, device: device, location: location, profilePictureURL: profilePictureURL)
//                } ?? []
//                
//                self.searchResults = self.users
//                self.filterResults() // Filter results after fetching
//            }
//        }
//    }
//    
//    func filterResults() {
//        var filteredResults = users // Start with all users
////        var filteredResults = users.filter{
////            !$0.teamStatus }
////        } // Start with all users
////        var filtered
//        if let role = selectedRole, !role.isEmpty {
//            filteredResults = filteredResults.filter { $0.userInGameRole == role }
//        }
//        
//        if let ageRange = selectedAge, !ageRange.isEmpty {
//            switch ageRange {
//            case "Below 16":
//                filteredResults = filteredResults.filter { $0.age < 16 }
//            case "Between 16 to 20":
//                filteredResults = filteredResults.filter { $0.age >= 16 && $0.age <= 20 }
//            case "Between 20 to 23":
//                filteredResults = filteredResults.filter { $0.age >= 20 && $0.age <= 23 }
//            case "23 & above":
//                filteredResults = filteredResults.filter { $0.age > 23 }
//            default:
//                break
//            }
//        }
//        
//        if let device = selectedDevice, !device.isEmpty {
//            filteredResults = filteredResults.filter { $0.device == device }
//        }
//        
//        if let location = selectedLocation, !location.isEmpty {
//            filteredResults = filteredResults.filter { $0.location == location }
//        }
//        
////        searchResults = filteredResults  //*
//        TeammateSearchResultTableviewController.reloadData()
//    }
//}
//
//extension ResultsSearchTeammateViewController: UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return searchResults.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
//        
//        let user = searchResults[indexPath.row]
//        cell.SearchUsernameOutlet.text = user.fullName
//        
//        if let profilePictureURL = user.profilePictureURL {
//            // Load profile picture from Firebase Storage
//            let storageRef = Storage.storage().reference(forURL: profilePictureURL)
//            storageRef.getData(maxSize: 10 * 1024 * 1024) { data, error in
//                if let error = error {
//                    print("Error downloading image: \(error)")
//                    cell.SearchProfileImageView.image = UIImage(named: "person")
//                } else {
//                    if let data = data, let image = UIImage(data: data) {
//                        cell.SearchProfileImageView.image = image
//                    } else {
//                        cell.SearchProfileImageView.image = UIImage(named: "person")
//                    }
//                }
//            }
//        } else {
//            // Use a placeholder image if no profile picture URL is provided
//            cell.SearchProfileImageView.image = UIImage(named: "placeholder.png")
//        }
//        
//        return cell
//    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//            selectedUser = searchResults[indexPath.row]
//            performSegue(withIdentifier: "playerProfileSegue", sender: self)
//        print("row is selected")
//        }
//        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//            if segue.identifier == "playerProfileSegue" {
//                if let destinationVC = segue.destination as? PlayerProfileViewController {
//                    destinationVC.user = selectedUser
//                }
//            }
//        }
//}

import UIKit
import FirebaseFirestore
import FirebaseStorage

class ResultsSearchTeammateViewController: UIViewController, UITableViewDelegate {

    
        var searchResults: [UserModel] = []
        var users: [UserModel] = []
        var selectedRole: String?
        var selectedAge: String?
        var selectedDevice: String?
        var selectedLocation: String?
        var selectedUser: UserModel?
    
    @IBOutlet weak var TeammateSearchResultTableviewController: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TeammateSearchResultTableviewController.dataSource=self
        TeammateSearchResultTableviewController.delegate=self
        TeammateSearchResultTableviewController.register(UINib(nibName: "ResultsSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "teamsearchresult")
        fetchUsersFromFirestore()
        filterResults()
    }
    
    func fetchUsersFromFirestore() {
            let db = Firestore.firestore()
            db.collection("users").getDocuments { (querySnapshot, error) in
                if let error = error {
                    print("Error getting documents: \(error)")
                } else {
                    for document in querySnapshot!.documents {
                        let data = document.data()
                        let user = UserModel(
                            fullName: data["fullName"] as? String ?? "",
                            email: data["email"] as? String ?? "",
                            phoneNumber: data["phoneNumber"] as? Int ?? 0,
                            userInGameRole: data["userInGameRole"] as? String ?? "",
                            userName: data["userName"] as? String ?? "",
                            teamStatus: data["teamStatus"] as? Bool ?? false,
                            age: data["age"] as? Int ?? 0,
                            device: data["device"] as? String ?? "",
                            location: data["location"] as? String ?? "",
                            profilePictureURL: data["profilePictureURL"] as? String ?? ""
                        )
                        self.users.append(user)
                    }
                    self.filterResults()
                }
            }
        }
    
    func filterResults() {
            searchResults = users.filter { !$0.teamStatus }
            
            if let role = selectedRole, !role.isEmpty {
                searchResults = searchResults.filter { $0.userInGameRole == role }
            }
            
            if let ageRange = selectedAge, !ageRange.isEmpty {
                switch ageRange {
                case "Below 16":
                    searchResults = searchResults.filter { $0.age < 16 }
                case "Between 16 to 20":
                    searchResults = searchResults.filter { $0.age >= 16 && $0.age <= 20 }
                case "Between 20 to 23":
                    searchResults = searchResults.filter { $0.age >= 20 && $0.age <= 23 }
                case "23 & above":
                    searchResults = searchResults.filter { $0.age > 23 }
                default:
                    break
                }
            }
            
            if let device = selectedDevice, !device.isEmpty {
                searchResults = searchResults.filter { $0.device == device }
            }
            
            if let location = selectedLocation, !location.isEmpty {
                searchResults = searchResults.filter { $0.location == location }
            }
            
            TeammateSearchResultTableviewController.reloadData()
        }
    }

extension ResultsSearchTeammateViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResults.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "teamsearchresult", for: indexPath) as! ResultsSearchTableViewCell
        
        cell.SearchUsernameOutlet?.text = searchResults[indexPath.row].fullName
  
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedUser = searchResults[indexPath.row]
        performSegue(withIdentifier: "playerProfileSegue", sender: self)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "playerProfileSegue" {
            if let destinationVC = segue.destination as? PlayerProfileViewController {
                destinationVC.user = selectedUser
            }
        }
    }
    
    
    
  
}
