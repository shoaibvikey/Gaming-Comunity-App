//
//  TeamDashboardTableViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 01/06/24.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class TeamDashboardTableViewController: UITableViewController {
    
    var teamName: String?
    var teamLogo: UIImage?
    
    var teamMember1: String?
    var teamMember2: String?
    var teamMember3: String?
    var teamMember4: String?
    var teamMember5: String?
    var teamMember6: String?
    
    
    @IBOutlet weak var teamNameLabel : UILabel!
    @IBOutlet weak var teamLogoImageView: UIImageView!
    @IBOutlet weak var teamMember1usernameOutlet: UILabel!
    @IBOutlet weak var teamMember2usernameOutlet: UILabel!
    @IBOutlet weak var teamMember3usernameOutlet: UILabel!
    @IBOutlet weak var teamMember4usernameOutlet: UILabel!
    @IBOutlet weak var teamMember5usernameOutlet: UILabel!
    @IBOutlet weak var teamMember6usernameOutlet: UILabel!
    
    @IBOutlet weak var teamMember1Button: UIButton!
    @IBOutlet weak var teamMember2Button: UIButton!
    @IBOutlet weak var teamMember3Button: UIButton!
    @IBOutlet weak var teamMember4Button: UIButton!
    @IBOutlet weak var teamMember5Button: UIButton!
    @IBOutlet weak var teamMember6Button: UIButton!
    
    @IBOutlet weak var addMemberBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        self.navigationItem.title = "My Team"
//        teamMember1 = "Not available"
//        teamMember2 = "Not available"
//        teamMember3 = "Not available"
//        teamMember4 = "Not available"
//        teamMember5 = "Not available"
//        teamMember6 = "Not available"
        
        teamMember1usernameOutlet.text = teamMember1
        teamMember2usernameOutlet.text = teamMember2
        teamMember3usernameOutlet.text = teamMember3
        teamMember4usernameOutlet.text = teamMember4
        teamMember5usernameOutlet.text = teamMember5
        teamMember6usernameOutlet.text = teamMember6
        
        
        teamNameLabel.text = teamName
        teamLogoImageView.image = teamLogo
        updateTeamMemberLabels()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    func updateButtonVisibility() {
        teamMember1Button.isHidden = (teamMember1 == "Not available")
        teamMember2Button.isHidden = (teamMember2 == "Not available")
        teamMember3Button.isHidden = (teamMember3 == "Not available")
        teamMember4Button.isHidden = (teamMember4 == "Not available")
        teamMember5Button.isHidden = (teamMember5 == "Not available")
        teamMember6Button.isHidden = (teamMember6 == "Not available")
        addMemberBtn.isHidden = teamMember1 != "Not available" &&
                                 teamMember2 != "Not available" &&
                                 teamMember3 != "Not available" &&
                                 teamMember4 != "Not available" &&
                                 teamMember5 != "Not available" &&
                                 teamMember6 != "Not available"
    }
    @IBAction func leaveTeamButton(_ sender: Any) {
        let alertController = UIAlertController(title: "Leave Team", message: "Are you sure you want to leave the team?", preferredStyle: .alert)
        let noAction = UIAlertAction(title: "No", style: .cancel) { (_) in
            print("User chose to stay in the team")
        }
        let leaveAction = UIAlertAction(title: "Leave", style: .destructive) { (_) in
            print("User chose to leave the team")
            self.changeTeamStatus()
            self.performSegue(withIdentifier: "teamLeavedSegue", sender: self)
            
            
        }
        alertController.addAction(noAction)
        alertController.addAction(leaveAction)
        self.present(alertController, animated: true, completion: nil)
    }
    func changeTeamStatus(){
        var teamStatus = true
        if teamStatus == true {
            teamStatus = false
        }
    }
    
    @IBAction func teamMember1ButtonPressed(_ sender: Any) {
        removeTeamMemberFromFirestore(memberNumber: 1)
        teamMember1 = "Not available"
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    
    @IBAction func teamMember2ButtonPressed(_ sender: Any) {
        removeTeamMemberFromFirestore(memberNumber: 2)
        teamMember2 = "Not available"
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    
    @IBAction func teamMember3ButtonPressed(_ sender: Any) {
        removeTeamMemberFromFirestore(memberNumber: 3)
        teamMember3 = "Not available"
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    
    @IBAction func teamMember4ButtonPressed(_ sender: Any) {
        removeTeamMemberFromFirestore(memberNumber: 4)
        teamMember4 = "Not available"
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    
    @IBAction func teamMember5ButtonPressed(_ sender: Any) {
        removeTeamMemberFromFirestore(memberNumber: 5)
        teamMember5 = "Not available"
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    
    @IBAction func teamMember6ButtonPressed(_ sender: Any) {
        removeTeamMemberFromFirestore(memberNumber: 6)
        teamMember6 = "Not available"
        updateTeamMemberLabels()
        updateButtonVisibility()
    }
    
    @IBAction func unwindToTeamDashboard(segue: UIStoryboardSegue) {
        if let sourceVC = segue.source as? PlayerProfileViewController, let fullName = sourceVC.user?.fullName {
               print("Unwinding with user: \(fullName)")
               addMemberToTeamInFirestore(fullName: fullName)
//            if teamMember1 == "Not available" {
//                teamMember1 = fullName
//                print("Assigned to teamMember1")
//            } else if teamMember2 == "Not available" {
//                teamMember2 = fullName
//                print("Assigned to teamMember2")
//            } else if teamMember3 == "Not available" {
//                teamMember3 = fullName
//                print("Assigned to teamMember3")
//            } else if teamMember4 == "Not available" {
//                teamMember4 = fullName
//                print("Assigned to teamMember4")
//            } else if teamMember5 == "Not available" {
//                teamMember5 = fullName
//                print("Assigned to teamMember5")
//            } else if teamMember6 == "Not available" {
//                teamMember6 = fullName
//                print("Assigned to teamMember6")
//            }
            
            
            if isViewLoaded {
                updateTeamMemberLabels()
            }
        }
    }
    
    func updateTeamMemberLabels() {
        print("Updating labels")
        teamMember1usernameOutlet.text = teamMember1
        teamMember2usernameOutlet.text = teamMember2
        teamMember3usernameOutlet.text = teamMember3
        teamMember4usernameOutlet.text = teamMember4
        teamMember5usernameOutlet.text = teamMember5
        teamMember6usernameOutlet.text = teamMember6
    }
   
    
    func removeTeamMemberFromFirestore(memberNumber: Int) {
        guard let teamName = teamName else { return }
        let db = Firestore.firestore()
        
        // Query the teams collection to find the document with the matching teamName
        db.collection("teams").whereField("teamName", isEqualTo: teamName).getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching team document: \(error)")
                return
            }
            
            // Check if there's any document returned
            guard let document = querySnapshot?.documents.first else {
                print("No document found for team: \(teamName)")
                return
            }
            
            // Get the document ID or name
            let documentID = document.documentID
            
            // Construct the document reference for the team member to update
            let documentRef = db.collection("teams").document(documentID)
            
            // Update the corresponding team member field in Firestore to an empty string
            documentRef.updateData([
                "teamMember\(memberNumber)": ""
            ]) { error in
                if let error = error {
                    print("Error updating document: \(error)")
                } else {
                    print("Document successfully updated")
                    // After updating in Firestore, update the UI
                    switch memberNumber {
                    case 1:
                        self.teamMember1 = "Not available"
                    case 2:
                        self.teamMember2 = "Not available"
                    case 3:
                        self.teamMember3 = "Not available"
                    case 4:
                        self.teamMember4 = "Not available"
                    case 5:
                        self.teamMember5 = "Not available"
                    case 6:
                        self.teamMember6 = "Not available"
                    default:
                        break
                    }
                    self.updateTeamMemberLabels()
                    self.updateButtonVisibility()
                }
            }
        }
    }
    
    
    func addMemberToTeamInFirestore(fullName: String) {
            guard let teamName = teamName else { return }
            let db = Firestore.firestore()
            
            // Query the teams collection to find the document with the matching teamName
            db.collection("teams").whereField("teamName", isEqualTo: teamName).getDocuments { (querySnapshot, error) in
                if let error = error {
                    print("Error fetching team document: \(error)")
                    return
                }
                
                // Check if there's any document returned
                guard let document = querySnapshot?.documents.first else {
                    print("No document found for team: \(teamName)")
                    return
                }
                
                // Get the document reference for the team
                let documentRef = document.reference
                
                // Check which team member is not available and update it with the fullName
                var updatedTeamMemberField: String?
                if self.teamMember1 == "Not available" {
                    updatedTeamMemberField = "teamMember1"
                } else if self.teamMember2 == "Not available" {
                    updatedTeamMemberField = "teamMember2"
                } else if self.teamMember3 == "Not available" {
                    updatedTeamMemberField = "teamMember3"
                } else if self.teamMember4 == "Not available" {
                    updatedTeamMemberField = "teamMember4"
                } else if self.teamMember5 == "Not available" {
                    updatedTeamMemberField = "teamMember5"
                } else if self.teamMember6 == "Not available" {
                    updatedTeamMemberField = "teamMember6"
                }
                
                // If an available team member slot was found, update Firestore
                if let fieldToUpdate = updatedTeamMemberField {
                    documentRef.updateData([
                        fieldToUpdate: fullName
                    ]) { error in
                        if let error = error {
                            print("Error updating document: \(error)")
                        } else {
                            print("Document successfully updated with new team member")
                            // Update the corresponding team member variable in the view controller
                            switch fieldToUpdate {
                            case "teamMember1":
                                self.teamMember1 = fullName
                            case "teamMember2":
                                self.teamMember2 = fullName
                            case "teamMember3":
                                self.teamMember3 = fullName
                            case "teamMember4":
                                self.teamMember4 = fullName
                            case "teamMember5":
                                self.teamMember5 = fullName
                            case "teamMember6":
                                self.teamMember6 = fullName
                            default:
                                break
                            }
                            // Update UI
                            self.updateTeamMemberLabels()
                            self.updateButtonVisibility()
                        }
                    }
                } else {
                    print("No available team member slot found.")
                    // Handle the case where all team member slots are already filled
                }
            }
        }
    
    }
    
    
    
    
    
    

