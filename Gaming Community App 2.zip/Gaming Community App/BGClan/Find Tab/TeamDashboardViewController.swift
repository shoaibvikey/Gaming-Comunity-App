//
//  TeamDashboardViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 01/06/24.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class TeamDashboardForAllTableViewController: UITableViewController {
    
    var teamName: String?
//    var teamImage: UIImage?
        var teamMember1: String?
        var teamMember2: String?
        var teamMember3: String?
        var teamMember4: String?
        var teamMember5: String?
        var teamMember6: String?
    var teamImageLogo:UIImage?
    @IBOutlet weak var teamImage: UIImageView!
    
    @IBOutlet weak var teamNameLabelOutlet: UILabel!
    
    @IBOutlet weak var teamMember1usernameOutlet: UILabel!
    @IBOutlet weak var teamMember2usernameOutlet: UILabel!
    
    @IBOutlet weak var teamMember3usernameOutlet: UILabel!
    
    @IBOutlet weak var teamMember4usernameOutlet: UILabel!
    @IBOutlet weak var teamMember5usernameOutlet: UILabel!
    @IBOutlet weak var teamMember6usernameOutlet: UILabel!

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        teamNameLabelOutlet.text = teamName
//        teamImage.image = SearchProfileImageView
        teamImage.image=teamImageLogo
        let new3Status = TeamDataController.shared.getTeamStatus()
        print("New Team Status after joining: \(new3Status)")
        fetchTeamData()
    }
    
    @IBAction func joinTeamButton(_ sender: Any) {
        
                        let alertController = UIAlertController(title: "Join Team", message: "Are you sure you want to join this team?", preferredStyle: .alert)
        
                        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                        let joinAction = UIAlertAction(title: "Join", style: .default) { _ in
                            // Handle the join action
                            self.performSegue(withIdentifier: "joinTeamSegue", sender: self)
                            
                            self.joinTeam()
                        }
        
                        alertController.addAction(cancelAction)
                        alertController.addAction(joinAction)
        
                        self.present(alertController, animated: true, completion: nil)
                    }
                func joinTeam() {
                        print("Joined the team")
                    
                    let new2Status = TeamDataController.shared.getTeamStatus()
                    print("New Team Status after joining: \(new2Status)")
                    TeamDataController.shared.changeTeamStatus()
                        
        
                    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "joinTeamSegue" {
                if let destinationVC = segue.destination as? TeamDashboardTableViewController {
                    destinationVC.teamName = self.teamName
                    destinationVC.teamMember1 = self.teamMember1
                    destinationVC.teamMember2 = self.teamMember2
                    destinationVC.teamMember3 = self.teamMember3
                    destinationVC.teamMember4 = self.teamMember4
                    destinationVC.teamMember5 = self.teamMember5
                    destinationVC.teamMember6 = self.teamMember6
                    destinationVC.teamLogo = self.teamImage.image

                }
            }
        }

    
    func fetchTeamData() {
        guard let teamName = teamName else { return }
        
        let db = Firestore.firestore()
        let storage = Storage.storage()
        
        // Query the teams collection to find the document with the matching teamName
        db.collection("teams").whereField("teamName", isEqualTo: teamName).getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching team document: \(error)")
                return
            }
            
            // Check if there's any document returned
            guard let document = querySnapshot?.documents.first else {
                print("No document found for team: \(teamName)")
                return
            }
            
            let data = document.data()
            
            // Retrieve team members and update UI
            self.teamMember1 = data["teamMember1"] as? String
            self.teamMember2 = data["teamMember2"] as? String
            self.teamMember3 = data["teamMember3"] as? String
            self.teamMember4 = data["teamMember4"] as? String
            self.teamMember5 = data["teamMember5"] as? String
            self.teamMember6 = data["teamMember6"] as? String
            
            self.updateUI()
            
            // Fetch team image from storage if teamImageURL field exists
            if let imageURL = data["imageUrl"] as? String {
                let imageRef = storage.reference(forURL: imageURL)
                imageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
                    if let error = error {
                        print("Error fetching image: \(error)")
                    } else {
                        if let data = data {
                            self.teamImageLogo = UIImage(data: data)
                            self.teamImage.image = self.teamImageLogo // Update teamImage outlet
                        }
                    }
                }
            }
        }
    }
        
        func updateUI() {
            teamMember1usernameOutlet.text = teamMember1
            teamMember2usernameOutlet.text = teamMember2
            teamMember3usernameOutlet.text = teamMember3
            teamMember4usernameOutlet.text = teamMember4
            teamMember5usernameOutlet.text = teamMember5
            teamMember6usernameOutlet.text = teamMember6
            
            
            
    
        }
    

    
    }

   
