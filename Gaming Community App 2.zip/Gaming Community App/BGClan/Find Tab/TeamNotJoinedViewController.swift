//
//  TeamNotJoinedViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 01/06/24.
//

import UIKit



class TeamNotJoinedViewController: UIViewController, UINavigationControllerDelegate ,UITableViewDelegate{

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        self.navigationController?.delegate = self
    }
    func navigationController(_ navigationController: UINavigationController, gestureRecognizerShouldBegin gestureRecognizer: UIGestureRecognizer) -> Bool {
            return false
        }


}
