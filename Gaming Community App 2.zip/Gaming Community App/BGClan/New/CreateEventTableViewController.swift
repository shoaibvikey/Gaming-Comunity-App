/*import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class CreateEventTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var eventNameTextField: UITextField!
    @IBOutlet weak var hostedByTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var registrationLinkTextField: UITextField!
    @IBOutlet weak var startingDateLabel: UILabel!
    @IBOutlet weak var endingDateLabel: UILabel!
    @IBOutlet weak var startingDatePicker: UIDatePicker!
    @IBOutlet weak var endingDatePicker: UIDatePicker!
    @IBOutlet weak var addMediaImageView: UIImageView!
    @IBOutlet weak var descriptionTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
        addMediaImageView.isUserInteractionEnabled = true
        addMediaImageView.addGestureRecognizer(tapGestureRecognizer)
        
        setupDatePickers()
        tableView.reloadData()
    }

    private func setupDatePickers() {
        startingDatePicker.datePickerMode = .date
        endingDatePicker.datePickerMode = .date
        
        startingDatePicker.addTarget(self, action: #selector(startingDateChanged), for: .valueChanged)
        endingDatePicker.addTarget(self, action: #selector(endingDateChanged), for: .valueChanged)
    }

    @objc func startingDateChanged() {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        let dateString = formatter.string(from: startingDatePicker.date)
        startingDateLabel.text = dateString
    }

    @objc func endingDateChanged() {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        let dateString = formatter.string(from: endingDatePicker.date)
        endingDateLabel.text = dateString
    }

    @objc func imageViewTapped() {
        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
            self.openPhotoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
    }

    func openPhotoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            addMediaImageView.image = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    @IBAction func createEventButton(_ sender: Any) {
        guard let name = eventNameTextField.text, !name.isEmpty,
              let description = descriptionTextField.text, !description.isEmpty,
              let hostedBy = hostedByTextField.text, !hostedBy.isEmpty,
              let location = locationTextField.text, !location.isEmpty,
              let registrationLink = registrationLinkTextField.text, !registrationLink.isEmpty,
              let startingDateText = startingDateLabel.text, !startingDateText.isEmpty,
              let endingDateText = endingDateLabel.text, !endingDateText.isEmpty else {
            let alert = UIAlertController(title: "Error", message: "Please fill all the fields.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "MM/dd/yy"

        guard let startDate = formatter.date(from: startingDateText),
              let endDate = formatter.date(from: endingDateText) else {
            let alert = UIAlertController(title: "Error", message: "Invalid date format.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }

        let newEvent: [String: Any] = [
            "EventName": name,
            "Description": description,
            "HostedBy": hostedBy,
            "EventLocation": location,
            "RegistrationLink": registrationLink,
            "StartEventDate": formatter.string(from: startDate),
            "EndEventDate": formatter.string(from: endDate)
        ]

        if let image = addMediaImageView.image {
            let storageRef = Storage.storage().reference()
            let imageData = image.pngData()!
            let imageRef = storageRef.child("images/\(UUID().uuidString).png")

            _ = imageRef.putData(imageData, metadata: nil) { metadata, error in
                if let error = error {
                    print("Error uploading image: \(error)")
                    return
                }

                imageRef.downloadURL { url, error in
                    if let error = error {
                        print("Error getting download URL: \(error)")
                        return
                    }

                    guard let downloadURL = url else {
                        print("Error getting download URL")
                        return
                    }

                    var eventWithImage = newEvent
                    eventWithImage["EventImageURL"] = downloadURL.absoluteString

                    self.saveEventToFirestore(eventData: eventWithImage)
                }
            }
        } else {
            self.saveEventToFirestore(eventData: newEvent)
        }
    }

    private func saveEventToFirestore(eventData: [String: Any]) {
        let db = Firestore.firestore()
        db.collection("events").addDocument(data: eventData) { error in
            if let error = error {
                print("Error adding document: \(error)")
            } else {
                print("Document added successfully")
                NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}
*/
import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class CreateEventTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextFieldDelegate, UITextViewDelegate {
    
    @IBOutlet weak var eventNameTextField: UITextField!
    @IBOutlet weak var hostedByTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var registrationLinkTextField: UITextField!
    @IBOutlet weak var startingDateLabel: UILabel!
    @IBOutlet weak var endingDateLabel: UILabel!
    @IBOutlet weak var startingDatePicker: UIDatePicker!
    @IBOutlet weak var endingDatePicker: UIDatePicker!
    @IBOutlet weak var addMediaImageView: UIImageView!
    //@IBOutlet weak var descriptionTextField: UITextField!
    //    by d
    @IBOutlet weak var descriptionTextView: UITextView!
    
    
    
    
    var checkInDateLabelIndexPath = IndexPath(row: 0, section: 2)
    var checkInDatePickerIndexPath = IndexPath(row: 1, section: 2)
    var checkOutDateLabelIndexPath = IndexPath(row: 2, section: 2)
    var checkOutDatePickerIndexPath = IndexPath(row: 3, section: 2)
    var descriptionIndexPath=IndexPath(row: 2, section: 3)
    override func viewDidLoad() {
        super.viewDidLoad()
        let midnightToday = Calendar.current.startOfDay(for: Date())
        startingDatePicker.minimumDate=midnightToday
        startingDatePicker.date=midnightToday
        endingDatePicker.minimumDate=midnightToday
        endingDatePicker.date=midnightToday
        
        
        tableView.dataSource = self
        tableView.delegate = self
        
        eventNameTextField.delegate = self
        hostedByTextField.delegate = self
        locationTextField.delegate = self
        registrationLinkTextField.delegate = self
        descriptionTextView.delegate = self
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
        addMediaImageView.isUserInteractionEnabled = true
        addMediaImageView.addGestureRecognizer(tapGestureRecognizer)
        
        setupDatePickers()
        descriptionTextView.layer.borderColor = UIColor.lightGray.cgColor
        descriptionTextView.layer.borderWidth = 0.2
        descriptionTextView.layer.cornerRadius = 5.0
        //        tableView.reloadData()
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    private func setupDatePickers() {
        startingDatePicker.datePickerMode = .date
        endingDatePicker.datePickerMode = .date
        
        startingDatePicker.addTarget(self, action: #selector(startingDateChanged), for: .valueChanged)
        endingDatePicker.addTarget(self, action: #selector(endingDateChanged), for: .valueChanged)
        
    }
    
    @objc func startingDateChanged() {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        let dateString = formatter.string(from: startingDatePicker.date)
        startingDateLabel.text = dateString
    }
    
    @objc func endingDateChanged() {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        let dateString = formatter.string(from: endingDatePicker.date)
        endingDateLabel.text = dateString
    }
    
    @objc func imageViewTapped() {
        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
            self.openPhotoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    func openPhotoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            addMediaImageView.image = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func createEventButton(_ sender: Any) {
//        guard let name = eventNameTextField.text, !name.isEmpty,
//              let description = descriptionTextView.text, !description.isEmpty,
//              let hostedBy = hostedByTextField.text, !hostedBy.isEmpty,
//              let location = locationTextField.text, !location.isEmpty,
//              let registrationLink = registrationLinkTextField.text, !registrationLink.isEmpty,
//              let startingDateText = startingDateLabel.text, !startingDateText.isEmpty,
//              let endingDateText = endingDateLabel.text, !endingDateText.isEmpty else {
//            let alert = UIAlertController(title: "Error", message: "Please fill all the fields.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//            return
//        }
//        
//        let formatter = DateFormatter()
//        formatter.dateFormat = "dd/MM/yy"
//        
//        if let startDate = formatter.date(from: startingDateText),
//           let endDate = formatter.date(from: endingDateText) {
//            
//            let db = Firestore.firestore()
//            var newEvent: [String: Any] = [
//                "EventName": name,
//                "Description": description,
//                "HostedBy": hostedBy,
//                "EventLocation": location,
//                "RegistrationLink": registrationLink,
//                "StartEventDate": formatter.string(from: startDate),
//                "EndEventDate": formatter.string(from: endDate)
//            ]
//            
//            if let image = addMediaImageView.image {
//                let storageRef = Storage.storage().reference()
//                let imageData = image.pngData()!
//                let imageRef = storageRef.child("images/\(UUID().uuidString).png")
//                print("hii")
//                _ = imageRef.putData(imageData, metadata: nil) { metadata, error in
//                    if let error = error {
//                        print("Error uploading image: \(error)")
//                        return
//                    }
//                    
//                    imageRef.downloadURL { url, error in
//                        if let error = error {
//                            print("Error getting download URL: \(error)")
//                            return
//                        }
//                        
//                        guard let downloadURL = url else {
//                            print("Error getting download URL")
//                            return
//                        }
//                        
//                        newEvent["EventImageURL"] = downloadURL.absoluteString
//                        
//                        db.collection("events").addDocument(data: newEvent) { error in
//                            if let error = error {
//                                print("Error adding document: \(error)")
//                            } else {
//                                print("Document added successfully")
//                                NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
//                                self.navigationController?.popViewController(animated: true)
//                            }
//                        }
//                    }
//                }
//            } else {
//                db.collection("events").addDocument(data: newEvent) { error in
//                    if let error = error {
//                        print("Error adding document: \(error)")
//                    } else {
//                        print("Document added successfully")
//                        //
//                        self.showEventAddedAlert()
//                        // Clear all input fields
//                        self.clearInputFields()
//                        //
//                        
//                        // Show an alert to indicate that the post has been added
//                        
//                        NotificationCenter.default.post(name: Notification.Name("NewEventAdded"), object: nil)
//                        self.navigationController?.popViewController(animated: true)
//                        
//                    }
//                }
//            }
//        } else {
//            let alert = UIAlertController(title: "Error", message: "Invalid date format.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//        }
//        
//        //
//    }
//    //added by me
//    private func showEventAddedAlert() {
//        let alert = UIAlertController(title: "Success", message: "Event has been added.", preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//        self.present(alert, animated: true, completion: nil)
//    }
//    
//    private func clearInputFields() {
//        eventNameTextField.text = ""
//        hostedByTextField.text = ""
//        locationTextField.text = ""
//        registrationLinkTextField.text = ""
//        startingDateLabel.text = ""
//        endingDateLabel.text = ""
//        descriptionTextView.text = ""
//        addMediaImageView.image = nil
//    }
//    
//    //    
//    //    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//    //        switch indexPath {
//    //        case checkInDatePickerIndexPath:
//    //            if isCheckInDatePickerVisible {
//    //                return 217
//    //            } else {
//    //                return 0
//    //            }
//    //        case checkOutDatePickerIndexPath:
//    //            if isCheckOutDatePickerVisible {
//    //                return 217
//    //            } else {
//    //                return 0
//    //            }
//    ////        case descriptionIndexPath:
//    ////            return .
//    //        
//    //        default:
//    //            return UITableView
//    //        }
//    //    }
        guard let name = eventNameTextField.text, !name.isEmpty,
                              let description = descriptionTextView.text, !description.isEmpty,
                              let hostedBy = hostedByTextField.text, !hostedBy.isEmpty,
                              let location = locationTextField.text, !location.isEmpty,
                              let registrationLink = registrationLinkTextField.text, !registrationLink.isEmpty,
                              let startingDateText = startingDateLabel.text, !startingDateText.isEmpty,
                              let endingDateText = endingDateLabel.text, !endingDateText.isEmpty else {
                            showAlert(title: "Error", message: "Please fill all the fields.")
                            return
                        }

                        let formatter = DateFormatter()
                        formatter.dateFormat = "dd/MM/yy"

                        guard let startDate = formatter.date(from: startingDateText),
                              let endDate = formatter.date(from: endingDateText) else {
                            showAlert(title: "Error", message: "Invalid date format.")
                            return
                        }

                        let db = Firestore.firestore()
                        var newEvent: [String: Any] = [
                            "EventName": name,
                            "Description": description,
                            "HostedBy": hostedBy,
                            "EventLocation": location,
                            "RegistrationLink": registrationLink,
                            "StartEventDate": formatter.string(from: startDate),
                            "EndEventDate": formatter.string(from: endDate)
                        ]

                        if let image = addMediaImageView.image {
                            let storageRef = Storage.storage().reference()
                            guard let imageData = image.pngData() else {
                                showAlert(title: "Error", message: "Unable to process image data.")
                                return
                            }
                            let imageRef = storageRef.child("images/\(UUID().uuidString).png")

                            _ = imageRef.putData(imageData, metadata: nil) { metadata, error in
                                if let error = error {
                                    print("Error uploading image: \(error)")
                                    self.showAlert(title: "Error", message: "Error uploading image.")
                                    return
                                }

                                imageRef.downloadURL { url, error in
                                    if let error = error {
                                        print("Error getting download URL: \(error)")
                                        self.showAlert(title: "Error", message: "Error getting download URL.")
                                        return
                                    }

                                    guard let downloadURL = url else {
                                        print("Error getting download URL")
                                        self.showAlert(title: "Error", message: "Error getting download URL.")
                                        return
                                    }

                                    newEvent["EventImageURL"] = downloadURL.absoluteString

                                    self.saveEventToFirestore(db: db, event: newEvent)
                                }
                            }
                        } else {
                            saveEventToFirestore(db: db, event: newEvent)
                        }
                    }

                    private func saveEventToFirestore(db: Firestore, event: [String: Any]) {
                        db.collection("events").addDocument(data: event) { error in
                            if let error = error {
                                print("Error adding document: \(error)")
                                self.showAlert(title: "Error", message: "Error adding event to Firestore.")
                            } else {
                                print("Document added successfully")
                                self.showAlert(title: "Success", message: "Event has been added successfully.", completion: {
                                    self.clearInputFields()
                                })
                            }
                        }
                    }

                    private func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
                        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            completion?()
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }

                    private func clearInputFields() {
                        eventNameTextField.text = ""
                        hostedByTextField.text = ""
                        locationTextField.text = ""
                        registrationLinkTextField.text = ""
                        startingDateLabel.text = ""
                        endingDateLabel.text = ""
                        descriptionTextView.text = ""
                        addMediaImageView.image = nil
                    }
                }

    
    
    
    
    
    
    
    
    







   
