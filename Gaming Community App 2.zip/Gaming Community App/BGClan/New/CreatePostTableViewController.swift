//import Foundation
//import UIKit
//
//class CreatePostTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//    @IBOutlet weak var postImage: UIImageView!
//    @IBOutlet weak var captionTextField: UITextField!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        tableView.dataSource = self
//        tableView.delegate = self
//        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
//        postImage.isUserInteractionEnabled = true
//        postImage.addGestureRecognizer(tapGestureRecognizer)
//    }
//
//    @objc func imageViewTapped() {
//        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)
//
//        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
//            self.openPhotoLibrary()
//        }))
//
//        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//
//        self.present(actionSheet, animated: true, completion: nil)
//    }
//
//    func openPhotoLibrary() {
//        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = .photoLibrary
//            self.present(imagePicker, animated: true, completion: nil)
//        }
//    }
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
//        if let selectedImage = info[.originalImage] as? UIImage {
//            postImage.image = selectedImage
//        }
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    @IBAction func postButtonTapped(_ sender: Any) {
//        print("hello")
//        guard let image = postImage.image, let caption = captionTextField.text else { return }
//
//        let newPost = Post(image: image, caption: caption)
//        DataController.shared.addPost(newPost)
//       
//        // Post a notification to notify the PostsCollectionViewController
//        NotificationCenter.default.post(name: Notification.Name("newPostCreated"), object: nil)
//
//        // Dismiss the CreatePostTableViewController
//        self.dismiss(animated: true, completion: nil)
//        captionTextField.text = nil
//
//            // Reset the post image to a system photo
//            postImage.image = UIImage(systemName: "photo")
//
//            // Show an alert to indicate that the post has been added
//        let alertController = UIAlertController(title: "Post Added", message: "Your post has been added successfully.", preferredStyle: .alert)
//            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alertController, animated: true, completion: nil)
//            // Reset the post image to a system photo
//    }
//   
//}

//import UIKit
//import Firebase
//import FirebaseFirestore
//import FirebaseStorage
//
//class CreatePostTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//    @IBOutlet weak var postImage: UIImageView!
//    @IBOutlet weak var captionTextField: UITextField!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        tableView.dataSource = self
//        tableView.delegate = self
//        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
//        postImage.isUserInteractionEnabled = true
//        postImage.addGestureRecognizer(tapGestureRecognizer)
//    }
//
//    @objc func imageViewTapped() {
//        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)
//
//        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
//            self.openPhotoLibrary()
//        }))
//
//        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//
//        self.present(actionSheet, animated: true, completion: nil)
//    }
//
//    func openPhotoLibrary() {
//        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = .photoLibrary
//            self.present(imagePicker, animated: true, completion: nil)
//        }
//    }
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
//        if let selectedImage = info[.originalImage] as? UIImage {
//            postImage.image = selectedImage
//        }
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    @IBAction func postButtonTapped(_ sender: Any) {
//        guard let image = postImage.image, let caption = captionTextField.text else { return }
//
//        // Upload the image to Firebase Storage
//        uploadImage(image) { imageUrl in
//            if let imageUrl = imageUrl {
//                // Save the post data, including the image URL, to Firebase Firestore
//                self.savePostData(imageUrl: imageUrl, caption: caption)
//            } else {
//                // Handle error while uploading image
//                print("Error uploading image")
//            }
//        }
//    }
//
//    // Function to upload image to Firebase Storage
//    func uploadImage(_ image: UIImage, completion: @escaping (String?) -> Void) {
//        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
//            completion(nil)
//            return
//        }
//        let imageName = UUID().uuidString
//        let storageRef = Storage.storage().reference().child("postsImages/\(imageName).jpg")
//        storageRef.putData(imageData, metadata: nil) { (_, error) in
//            if let error = error {
//                print("Error uploading image: \(error.localizedDescription)")
//                completion(nil)
//            } else {
//                storageRef.downloadURL { (url, error) in
//                    guard let downloadURL = url else {
//                        print("Error getting download URL")
//                        completion(nil)
//                        return
//                    }
//                    completion(downloadURL.absoluteString)
//                }
//            }
//        }
//    }
//
//    // Function to save post data to Firestore
//    func savePostData(imageUrl: String, caption: String) {
//        let db = Firestore.firestore()
//        let postRef = db.collection("posts").document()
//        let postData: [String: Any] = [
//            "imageUrl": imageUrl,
//            "caption": caption
//        ]
//        postRef.setData(postData) { error in
//            if let error = error {
//                print("Error saving post data: \(error.localizedDescription)")
//            } else {
//                // Post data saved successfully
//                NotificationCenter.default.post(name: Notification.Name("newPostCreated"), object: nil)
//                self.dismiss(animated: true, completion: nil)
//                self.captionTextField.text = nil
//                self.postImage.image = UIImage(systemName: "photo")
//                // Show an alert to indicate that the post has been added
//                let alertController = UIAlertController(title: "Post Added", message: "Your post has been added successfully.", preferredStyle: .alert)
//                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                self.present(alertController, animated: true, completion: nil)
//            }
//        }
//    }
//}

//import UIKit
//import Firebase
//import FirebaseFirestore
//import FirebaseStorage
//
//class CreatePostTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//    @IBOutlet weak var postImage: UIImageView!
//    @IBOutlet weak var captionTextField: UITextField!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        tableView.dataSource = self
//        tableView.delegate = self
//        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
//        postImage.isUserInteractionEnabled = true
//        postImage.addGestureRecognizer(tapGestureRecognizer)
//    }
//
//    @objc func imageViewTapped() {
//        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)
//
//        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
//            self.openPhotoLibrary()
//        }))
//
//        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//
//        self.present(actionSheet, animated: true, completion: nil)
//    }
//
//    func openPhotoLibrary() {
//        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = .photoLibrary
//            self.present(imagePicker, animated: true, completion: nil)
//        }
//    }
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
//        if let selectedImage = info[.originalImage] as? UIImage {
//            postImage.image = selectedImage
//        }
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    @IBAction func postButtonTapped(_ sender: Any) {
//        guard let image = postImage.image, let caption = captionTextField.text else { return }
//
//        // Upload the image to Firebase Storage
//        uploadImage(image) { imageUrl in
//            if let imageUrl = imageUrl {
//                // Save the post data, including the image URL and username, to Firebase Firestore
//                self.savePostData(imageUrl: imageUrl, caption: caption)
//            } else {
//                // Handle error while uploading image
//                print("Error uploading image")
//            }
//        }
//    }
//
//    // Function to upload image to Firebase Storage
//    func uploadImage(_ image: UIImage, completion: @escaping (String?) -> Void) {
//        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
//            completion(nil)
//            return
//        }
//        let imageName = UUID().uuidString
//        let storageRef = Storage.storage().reference().child("postsImages/\(imageName).jpg")
//        storageRef.putData(imageData, metadata: nil) { (_, error) in
//            if let error = error {
//                print("Error uploading image: \(error.localizedDescription)")
//                completion(nil)
//            } else {
//                storageRef.downloadURL { (url, error) in
//                    guard let downloadURL = url else {
//                        print("Error getting download URL")
//                        completion(nil)
//                        return
//                    }
//                    completion(downloadURL.absoluteString)
//                }
//            }
//        }
//    }
//
//    // Function to save post data to Firestore
//    func savePostData(imageUrl: String, caption: String) {
//        // Fetch the current username from Firebase Auth
//        guard let user = Auth.auth().currentUser else {
//            print("User not logged in")
//            return
//        }
//
//        let db = Firestore.firestore()
//        let usersRef = db.collection("users").document(user.uid)
//        
//        // Fetch the username
//        usersRef.getDocument { (document, error) in
//            if let document = document, document.exists {
//                if let username = document.data()?["username"] as? String {
//                    let postRef = db.collection("posts").document()
//                    let postData: [String: Any] = [
//                        "imageUrl": imageUrl,
//                        "caption": caption,
//                        "username": username,
//                        "timestamp": FieldValue.serverTimestamp()
//                    ]
//                    postRef.setData(postData) { error in
//                        if let error = error {
//                            print("Error saving post data: \(error.localizedDescription)")
//                        } else {
//                            // Post data saved successfully
//                            NotificationCenter.default.post(name: Notification.Name("newPostCreated"), object: nil)
//                            self.dismiss(animated: true, completion: nil)
//                            self.captionTextField.text = nil
//                            self.postImage.image = UIImage(systemName: "photo")
//                            // Show an alert to indicate that the post has been added
//                            let alertController = UIAlertController(title: "Post Added", message: "Your post has been added successfully.", preferredStyle: .alert)
//                            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                            self.present(alertController, animated: true, completion: nil)
//                            print("Post successfully Created")
//                            print(username)
//                            
//                        }
//                    }
//                } else {
//                    print("Username field is missing in user document")
//                }
//            } else {
//                print("User document does not exist")
//            }
//        }
//    }
//}

//import UIKit
//import Firebase
//import FirebaseFirestore
//import FirebaseStorage
//
//class CreatePostTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//    @IBOutlet weak var postImage: UIImageView!
//    @IBOutlet weak var captionTextField: UITextField!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        tableView.dataSource = self
//        tableView.delegate = self
//        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
//        postImage.isUserInteractionEnabled = true
//        postImage.addGestureRecognizer(tapGestureRecognizer)
//    }
//
//    @objc func imageViewTapped() {
//        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)
//
//        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
//            self.openPhotoLibrary()
//        }))
//
//        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//
//        self.present(actionSheet, animated: true, completion: nil)
//    }
//
//    func openPhotoLibrary() {
//        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = .photoLibrary
//            self.present(imagePicker, animated: true, completion: nil)
//        }
//    }
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
//        if let selectedImage = info[.originalImage] as? UIImage {
//            postImage.image = selectedImage
//        }
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        picker.dismiss(animated: true, completion: nil)
//    }
//
//    @IBAction func postButtonTapped(_ sender: Any) {
//        guard let image = postImage.image, let caption = captionTextField.text else { return }
//
//        // Upload the image to Firebase Storage
//        uploadImage(image) { imageUrl in
//            if let imageUrl = imageUrl {
//                // Save the post data, including the image URL and username, to Firebase Firestore
//                self.savePostData(imageUrl: imageUrl, caption: caption)
//            } else {
//                // Handle error while uploading image
//                print("Error uploading image")
//            }
//        }
//    }
//
//    // Function to upload image to Firebase Storage
//    func uploadImage(_ image: UIImage, completion: @escaping (String?) -> Void) {
//        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
//            completion(nil)
//            return
//        }
//        let imageName = UUID().uuidString
//        let storageRef = Storage.storage().reference().child("postsImages/\(imageName).jpg")
//        storageRef.putData(imageData, metadata: nil) { (_, error) in
//            if let error = error {
//                print("Error uploading image: \(error.localizedDescription)")
//                completion(nil)
//            } else {
//                storageRef.downloadURL { (url, error) in
//                    guard let downloadURL = url else {
//                        print("Error getting download URL")
//                        completion(nil)
//                        return
//                    }
//                    completion(downloadURL.absoluteString)
//                }
//            }
//        }
//    }
//
//    // Function to save post data to Firestore
//    func savePostData(imageUrl: String, caption: String) {
//        // Fetch the current username from UserDefaults
//        if let username = UserDefaults.standard.string(forKey: "username") {
//            let db = Firestore.firestore()
//            let postRef = db.collection("posts").document()
//            let postData: [String: Any] = [
//                "imageUrl": imageUrl,
//                "caption": caption,
//                "username": username,
//                "timestamp": FieldValue.serverTimestamp()
//            ]
//            postRef.setData(postData) { error in
//                if let error = error {
//                    print("Error saving post data: \(error.localizedDescription)")
//                } else {
//                    NotificationCenter.default.post(name: Notification.Name("newPostCreated"), object: nil)
//                    self.dismiss(animated: true, completion: nil)
//                    self.captionTextField.text = nil
//                    self.postImage.image = UIImage(systemName: "photo")
//                    let alertController = UIAlertController(title: "Post Added", message: "Your post has been added successfully.", preferredStyle: .alert)
//                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                    self.present(alertController, animated: true, completion: nil)
//                    print("Post successfully created")
//                    print(username)
//                }
//            }
//        } else {
//            print("Username not found in UserDefaults")
//        }
//    }
//}
//

import Foundation
import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth

class CreatePostTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextFieldDelegate {

    @IBOutlet weak var postImage: UIImageView!
    @IBOutlet weak var captionTextField: UITextField!

    var username: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        captionTextField.delegate = self

        tableView.dataSource = self
        tableView.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageViewTapped))
        postImage.isUserInteractionEnabled = true
        postImage.addGestureRecognizer(tapGestureRecognizer)

        if let userId = Auth.auth().currentUser?.uid {
            fetchUsernameForLoggedUser(userId: userId)
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // Dismiss the keyboard
        return true
    }

    @objc func imageViewTapped() {
        let actionSheet = UIAlertController(title: "Add Media", message: "Choose a source", preferredStyle: .actionSheet)

        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { action in
            self.openPhotoLibrary()
        }))

        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))

        self.present(actionSheet, animated: true, completion: nil)
    }

    func openPhotoLibrary() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            self.present(imagePicker, animated: true, completion: nil)
        }
    }

    func fetchUsernameForLoggedUser(userId: String) {
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(userId)

        userRef.getDocument { document, error in
            if let error = error {
                print("Error fetching user data: \(error.localizedDescription)")
            } else {
                if let document = document, let userData = document.data(), let fetchedUsername = userData["username"] as? String {
                    self.username = fetchedUsername
                }
            }
        }
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            postImage.image = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    @IBAction func postButtonTapped(_ sender: Any) {
        guard let image = postImage.image, let caption = captionTextField.text, let username = self.username else { return }

        uploadImage(image) { imageUrl in
            if let imageUrl = imageUrl {
                self.savePostData(imageUrl: imageUrl, caption: caption, username: username)
            } else {
                print("Error uploading image")
            }
        }
    }

    func savePostData(imageUrl: String, caption: String, username: String) {
        let db = Firestore.firestore()
        let postRef = db.collection("posts").document()
        let postData: [String: Any] = [
            "imageUrl": imageUrl,
            "caption": caption,
            "username": username,
            "timestamp": FieldValue.serverTimestamp()
        ]

        postRef.setData(postData) { error in
            if let error = error {
                print("Error saving post data: \(error.localizedDescription)")
            } else {
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Post Added", message: "Your post has been added successfully.", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alertController, animated: true, completion: {
                        self.captionTextField.text = nil
                        self.postImage.image = UIImage(systemName: "photo")
                    })
                }
            }
        }
    }

    func uploadImage(_ image: UIImage, completion: @escaping (String?) -> Void) {
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            completion(nil)
            return
        }

        let imageName = UUID().uuidString
        let storageRef = Storage.storage().reference().child("postsImages/\(imageName).jpg")

        storageRef.putData(imageData, metadata: nil) { (_, error) in
            if let error = error {
                print("Error uploading image: \(error.localizedDescription)")
                completion(nil)
            } else {
                storageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        print("Error getting download URL")
                        completion(nil)
                        return
                    }
                    completion(downloadURL.absoluteString)
                }
            }
        }
    }
}
