//import UIKit
//
//class EventDetailTableViewController: UITableViewController {
//
//    @IBOutlet weak var eventImage: UIImageView!
//    @IBOutlet weak var organizedByLabel: UILabel!
//    @IBOutlet weak var locationLabel: UILabel!
//    @IBOutlet weak var startingDateLabel: UILabel!
//    @IBOutlet weak var endingDateLabel: UILabel!
//    @IBOutlet weak var aboutEvent: UILabel!
//    @IBOutlet weak var eventLink: UILabel!
//
//    var event: EventsCell?
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        if let event = event {
//            eventImage.image = event.EventImage
//            organizedByLabel.text = event.EventName
//            locationLabel.text = event.EventLocation
//            startingDateLabel.text = event.StartEventDate
//            endingDateLabel.text = event.EndEventDate
//            aboutEvent.text = event.Description // Display the detailed description
//            eventLink.text = event.EventLink
//
//            self.title = event.EventName
//        }
//    }
//}
//import UIKit
//
//class EventDetailTableViewController: UITableViewController {
//
//    @IBOutlet weak var eventImage: UIImageView!
//    @IBOutlet weak var organizedByLabel: UILabel!
//    @IBOutlet weak var locationLabel: UILabel!
//    @IBOutlet weak var startingDateLabel: UILabel!
//    @IBOutlet weak var endingDateLabel: UILabel!
//    @IBOutlet weak var aboutEvent: UILabel!
//    @IBOutlet weak var eventLink: UILabel!
//
//    var event: EventsCell?
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        if let event = event {
//            eventImage.image = event.EventImage
//            organizedByLabel.text = event.EventName
//            locationLabel.text = event.EventLocation
//            startingDateLabel.text = event.StartEventDate
//            endingDateLabel.text = event.EndEventDate
//            aboutEvent.text = event.Description // Display the detailed description
//            eventLink.text = event.EventLink
//
//            // Add tap gesture recognizer to eventLink
//            let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(eventLinkTapped))
//            eventLink.isUserInteractionEnabled = true
//            eventLink.addGestureRecognizer(tapGestureRecognizer)
//
//            self.title = event.EventName
//        }
//    }
//
//    // Handle tap on the eventLink
//    @objc func eventLinkTapped() {
//        // Check if event contains a registrationLink
//        guard let registrationLink = event?.EventLink, let url = URL(string: registrationLink) else {
//            return
//        }
//
//        // Open the URL in a browser
//        UIApplication.shared.open(url, options: [:], completionHandler: nil)
//    }
//}

import UIKit

class EventDetailTableViewController: UITableViewController {

    @IBOutlet weak var eventImage: UIImageView!
    @IBOutlet weak var organizedByLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var startingDateLabel: UILabel!
    @IBOutlet weak var endingDateLabel: UILabel!
    @IBOutlet weak var aboutEvent: UILabel!
    @IBOutlet weak var eventLink: UILabel!

    var event: EventsCell?

    override func viewDidLoad() {
        super.viewDidLoad()

        if let event = event {
            eventImage.image = event.EventImage
            organizedByLabel.text = event.EventName
            locationLabel.text = event.EventLocation
            startingDateLabel.text = event.StartEventDate
            endingDateLabel.text = event.EndEventDate
            aboutEvent.text = event.Description // Display the detailed description
            eventLink.text = event.EventLink

            // Add tap gesture recognizer to eventLink
            let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(eventLinkTapped))
            eventLink.isUserInteractionEnabled = true
            eventLink.addGestureRecognizer(tapGestureRecognizer)

            self.title = event.EventName
        }
    }

    // Handle tap on the eventLink
    @objc func eventLinkTapped() {
        // Check if event contains a registrationLink
        guard let registrationLink = event?.EventLink, var urlComponents = URLComponents(string: registrationLink) else {
            return
        }

        // Check if the URL has a scheme, if not, add "http://" as the default scheme
        if urlComponents.scheme == nil {
            urlComponents.scheme = "http"
        }

        // Open the URL in a browser
        if let url = urlComponents.url {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}
