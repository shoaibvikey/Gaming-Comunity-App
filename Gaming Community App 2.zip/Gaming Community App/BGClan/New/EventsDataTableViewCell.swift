//
//  EventsDataTableViewCell.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 06/06/24.
//

import UIKit

class EventsDataTableViewCell: UITableViewCell {
    

    

        let fromLabel = UILabel()
        let fromCityLabel = UILabel()
        let toLabel = UILabel()
        let toCityLabel = UILabel()
        let dateLabel = UILabel()
        let idLabel = UILabel()
        let viewDetailsButton = UIButton(type: .system)
        
        override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
            super.init(style: style, reuseIdentifier: "descriptionCell")
            setupViews()
        }
        
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        private func setupViews() {
            fromLabel.text = "From"
            fromLabel.font = UIFont.boldSystemFont(ofSize: 14)
            
            toLabel.text = "To"
            toLabel.font = UIFont.boldSystemFont(ofSize: 14)
            
            dateLabel.font = UIFont.systemFont(ofSize: 14)
            idLabel.font = UIFont.systemFont(ofSize: 14)
            
            viewDetailsButton.setTitle("View details", for: .normal)
            
            let stackView = UIStackView(arrangedSubviews: [
                createStackView(with: fromLabel, and: fromCityLabel),
                createStackView(with: toLabel, and: toCityLabel),
                createStackView(with: UILabel(text: "Date"), and: dateLabel),
                createStackView(with: UILabel(text: "ID"), and: idLabel),
                viewDetailsButton
            ])
            
            stackView.axis = .vertical
            stackView.spacing = 8
            stackView.translatesAutoresizingMaskIntoConstraints = false
            
            contentView.addSubview(stackView)
            
            NSLayoutConstraint.activate([
                stackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
                stackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
                stackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
                stackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16)
            ])
        }
        
        private func createStackView(with label1: UILabel, and label2: UILabel) -> UIStackView {
            let stackView = UIStackView(arrangedSubviews: [label1, label2])
            stackView.axis = .horizontal
            stackView.distribution = .equalSpacing
            return stackView
        }
    }

    private extension UILabel {
        convenience init(text: String) {
            self.init()
            self.text = text
            self.font = UIFont.systemFont(ofSize: 14)
        }
    }

