//
//  NewViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 16/05/24.
//

import UIKit

class NewViewController: UIViewController {
    
    
    @IBOutlet weak var createPostOutlet: UIView!
    
    @IBOutlet weak var createEventOutlet: UIView!
    
    @IBOutlet weak var segmentButtonNewOutlet: UISegmentedControl!
    
    @IBOutlet weak var NavigationOutlet: UINavigationItem!
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "New"
        self .tabBarItem.image = UIImage(systemName: "plus")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NavigationOutlet.title = "Create Post"
        
    }
    
    
    @IBAction func newSegmentToggle(_ sender: Any) {
        switch segmentButtonNewOutlet.selectedSegmentIndex{
        case 0:
            self.view.bringSubviewToFront(createPostOutlet)
            NavigationOutlet.title = "Create Post"
        case 1:
            self.view.bringSubviewToFront(createEventOutlet)
            NavigationOutlet.title = "Create Event "
        default:
            break
        }
        
        
        
        
    }
}
