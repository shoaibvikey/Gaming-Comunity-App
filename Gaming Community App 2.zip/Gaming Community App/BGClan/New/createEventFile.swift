//
//  createEventFile.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 05/06/24.
//

import Foundation
//
//  createEventFile.swift
//  BGClan
//
//  Created by Batch-2 on 31/05/24.
//

import Foundation
import UIKit

class Event {
    var eventName: String
    var description: String
    var hostedBy: String
    var location: String
    var registrationLink: String
    var startingDate: String
    var endingDate: String
    var addMedia: UIImage?
    
    init(eventName: String, description: String, hostedBy: String, location: String, registrationLink: String, startingDate: String, endingDate: String, addMedia: UIImage?) {
        self.eventName = eventName
        self.description = description
        self.hostedBy = hostedBy
        self.location = location
        self.registrationLink = registrationLink
        self.startingDate = startingDate
        self.endingDate = endingDate
        self.addMedia = addMedia
    }
}
