//
//  createEventViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 22/05/24.
//

import UIKit

class createEventViewController: UIViewController {

    @IBOutlet weak var EventDescriptionTextFeildOutlet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
