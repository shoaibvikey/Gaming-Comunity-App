//
//  createPostViewController.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 22/05/24.
//

import UIKit

class createPostViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
 
}
