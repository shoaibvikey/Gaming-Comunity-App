//
//  CreateAccountViewController.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 01/06/24.
//

import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage


class CreateAccountViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var profilePictureImageView: UIImageView!
    @IBOutlet weak var fullNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
//    @IBOutlet weak var inGameRoleTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var eventOrganizerSwitch: UISwitch!
    @IBOutlet weak var createAccountButton: UIButton!
    @IBOutlet weak var usernameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupProfilePictureImageView()
        fullNameTextField.delegate = self
               emailTextField.delegate = self
               ageTextField.delegate = self
               phoneNumberTextField.delegate = self
               passwordTextField.delegate = self
               usernameTextField.delegate = self
           
    }
    
    @IBAction func createAccountButtonTapped(_ sender: Any) {
        // Validate the fields
                let error = validateFields()
                if error != nil {
                    // There's something wrong with the fields, show error message
                    showError(error!)
                } else {
                    // Create cleaned versions of the data
                    let fullName = fullNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    let username = usernameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    let phoneNumber = phoneNumberTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
//                    let inGameRole = inGameRoleTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    let eventOrganizer = eventOrganizerSwitch.isOn
                    let age=ageTextField.text
                    // Check if username is already taken
                    let db = Firestore.firestore()
                    let usersRef = db.collection("users")
                    usersRef.whereField("username", isEqualTo: username).getDocuments { (querySnapshot, error) in
                        if let error = error {
                            self.showError("Error checking username: \(error.localizedDescription)")
                            return
                        }
                        if querySnapshot?.isEmpty == false {
                            self.showError("Username is already taken. Please choose another one.")
                            return
                        } else {
                            // Username is available, create the user
                            Auth.auth().createUser(withEmail: email, password: password) { (result, err) in
                                // Check for errors
                                if err != nil {
                                    // There was an error creating the user
                                    self.showError("Error creating user: \(err!.localizedDescription)")
                                } else {
                                    // User was created successfully, now store the additional data
                                    db.collection("users").document(result!.user.uid).setData([
                                        "fullName": fullName,
                                        "username": username,
                                        "uid": result!.user.uid,
                                        "phoneNumber": phoneNumber,
//                                        "inGameRole": inGameRole,
                                        "eventOrganizer": eventOrganizer,
                                        "age": age
                                    ]) { (error) in
                                        if error != nil {
                                            // Show error message
                                            self.showError("Error saving user data: \(error!.localizedDescription)")
                                        }
                                    }
                                    // Upload profile picture
                                    self.uploadProfilePicture(result!.user.uid)
                                    // Transition to main screen
                                    UserDefaults.standard.set(true, forKey: "isLoggedIn")

                                            // Get the app delegate
                                            let appDelegate = UIApplication.shared.delegate as! AppDelegate

                                            // Load the Main storyboard
                                            let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                    let vc = mainStoryboard.instantiateInitialViewController()!
                                    //let navVC = UINavigationController()
                                    //navVC.pushViewController(vc, animated: true)
                                    

                                            // Set the initial view controller as the root view controller
                        //                    appDelegate.window?.rootViewController = initialViewController
                        //                    appDelegate.window?.makeKeyAndVisible()
                                    self.present(vc, animated: true)
//                                    self.transitionToMain()
                                }
                            }
                        }
                    }
                }
            }

            func validateFields() -> String? {
                if fullNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                   emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                   usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || // Validate username
                   ageTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                   phoneNumberTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
                   passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
                    return "Please fill in all fields."
                }
                
                // Check if the password is secure
                let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                if isPasswordValid(password) == false {
                    return "Please make sure your password is at least 8 characters, contains a special character and a number."
                }
                
                return nil
            }

            func isPasswordValid(_ password : String) -> Bool {
                let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$^+=!*()@%&]).{8,}$")
                return passwordTest.evaluate(with: password)
            }

            func showError(_ message: String) {
                let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                present(alert, animated: true, completion: nil)
            }

            func setupProfilePictureImageView() {
                profilePictureImageView.isUserInteractionEnabled = true
                let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(profilePictureTapped))
                profilePictureImageView.addGestureRecognizer(tapGestureRecognizer)
            }

            @objc func profilePictureTapped() {
                let imagePickerController = UIImagePickerController()
                imagePickerController.delegate = self
                imagePickerController.sourceType = .photoLibrary
                present(imagePickerController, animated: true, completion: nil)
            }

            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                if let selectedImage = info[.originalImage] as? UIImage {
                    profilePictureImageView.image = selectedImage
                }
                dismiss(animated: true, completion: nil)
            }

            func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
                dismiss(animated: true, completion: nil)
            }

            func uploadProfilePicture(_ uid: String) {
                guard let image = profilePictureImageView.image else { return }
                guard let imageData = image.jpegData(compressionQuality: 0.75) else { return }
                
                let storageRef = Storage.storage().reference().child("profilePictures/\(uid).jpg")
                storageRef.putData(imageData, metadata: nil) { (metadata, error) in
                    if let error = error {
                        print("Error uploading profile picture: \(error)")
                        return
                    }
                    
                    storageRef.downloadURL { (url, error) in
                        if let error = error {
                            print("Error getting download URL: \(error)")
                            return
                        }
                        
                        guard let url = url else { return }
                        
                        let db = Firestore.firestore()
                        db.collection("users").document(uid).updateData([
                            "profilePictureURL": url.absoluteString
                        ]) { error in
                            if let error = error {
                                print("Error updating profile picture URL: \(error)")
                            }
                        }
                    }
                }
            }
            
            func transitionToMain() {
                performSegue(withIdentifier: "accountCreated", sender: self)
            }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
        }
