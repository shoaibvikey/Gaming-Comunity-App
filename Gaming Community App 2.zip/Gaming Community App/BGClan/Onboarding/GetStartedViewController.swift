//
//  GetStartedViewController.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 01/06/24.
//

import UIKit

class GetStartedViewController: UIViewController {
    
    @IBOutlet weak var titleTextLabel: UILabel!
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var createAccountButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        //for the letter by letter effect
        titleTextLabel.text = ""
        var charIndex = 0.0
        let titleText = "CasterCom"
        for letter in titleText {
            Timer.scheduledTimer(withTimeInterval: 0.2 * charIndex, repeats: false) { (timer) in
                self.titleTextLabel.text?.append(letter)
            }
            charIndex += 1
        }
    }
    
    //unwindToGettingStarted
    @IBAction func signOutAndNavigateToGettingStarted(unsegue:UIStoryboardSegue){
        
    }
    
}

