//
//  LoginViewController.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 31/05/24.
//

//import UIKit
//import Firebase
//
//class LoginViewController: UIViewController {
//    
//    @IBOutlet weak var emailTextField: UITextField!
//    @IBOutlet weak var logInButton: UIButton!
//    @IBOutlet weak var passwordTextField: UITextField!
//    @IBOutlet weak var createAccountButton: UIButton!
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//    }
//    
//    @IBAction func logInButtonTapped(_ sender: Any) {
//        // Validate fields
//        let error = validateFields()
//        if let error = error {
//            showError(error)
//        } else {// Transition to the home screen
//            UserDefaults.standard.set(true, forKey: "isLoggedIn")
//
//                    // Get the app delegate
//                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
//
//                    // Load the Main storyboard
//                    let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            let vc = mainStoryboard.instantiateInitialViewController()!
//            //let navVC = UINavigationController()
//            //navVC.pushViewController(vc, animated: true)
//            
//
//                    // Set the initial view controller as the root view controller
////                    appDelegate.window?.rootViewController = initialViewController
////                    appDelegate.window?.makeKeyAndVisible()
//            present(vc, animated: true)
//        }
//    }
//    
//    
//    
//    
//    @IBAction func createAccountButtonTapped(_ sender: Any) {
//        performSegue(withIdentifier: "goToCreateAccount", sender: self)
//    }
//    func validateFields() -> String? {
//        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
//            return "Please fill in the email field."
//        }
//        if passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
//            return "Please fill in the password field."
//        }
//        return nil
//    }
//    
//    // Show error message
//    func showError(_ message: String) {
//        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//        present(alert, animated: true, completion: nil)
//    }
//    
//    //Going to home tab post successful login
//    //        func transitionToHome() {
//    //            performSegue(withIdentifier: "accountCreated", sender: self)
//    //        }
//    //    }
//    
//    
//}


//import UIKit
//import Firebase
//
//class LoginViewController: UIViewController {
//
//    @IBOutlet weak var emailTextField: UITextField!
//    @IBOutlet weak var passwordTextField: UITextField!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//    }
//
//    @IBAction func logInButtonTapped(_ sender: Any) {
//        guard let email = emailTextField.text, !email.isEmpty else {
//            showError("Please enter your email.")
//            return
//        }
//        
//        guard let password = passwordTextField.text, !password.isEmpty else {
//            showError("Please enter your password.")
//            return
//        }
//        
//        Auth.auth().signIn(withEmail: email, password: password) { [weak self] authResult, error in
//            guard let strongSelf = self else { return }
//            if let error = error {
//                strongSelf.showError("Login failed: \(error.localizedDescription)")
//            } else {
//                // Login successful
//                UserDefaults.standard.set(true, forKey: "isLoggedIn")
//                strongSelf.transitionToMain()
//            }
//        }
//    }
//
//    @IBAction func createAccountButtonTapped(_ sender: Any) {
//        performSegue(withIdentifier: "goToCreateAccount", sender: self)
//    }
//
//    func showError(_ message: String) {
//        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//        present(alert, animated: true, completion: nil)
//    }
//
//    func transitionToMain() {
//        performSegue(withIdentifier: "accountCreated", sender: self)
//    }
//}


//import UIKit
//import Firebase
//
//class LoginViewController: UIViewController {
//    
//    @IBOutlet weak var emailTextField: UITextField!
//    @IBOutlet weak var logInButton: UIButton!
//    @IBOutlet weak var passwordTextField: UITextField!
//    @IBOutlet weak var createAccountButton: UIButton!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//    }
//
//    @IBAction func logInButtonTapped(_ sender: Any) {
//        // Validate fields
//        let error = validateFields()
//        if let error = error {
//            showError(error)
//        } else {
//            Auth.auth().signIn(withEmail: emailTextField.text ?? "", password: passwordTextField.text ?? "") { (authResult, error) in
//                if let error = error {
//                    self.showError(error.localizedDescription)
//                } else {
//                    UserDefaults.standard.set(true, forKey: "isLoggedIn")
//                    let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                    if let vc = mainStoryboard.instantiateInitialViewController() {
//                        self.present(vc, animated: true, completion: nil)
//                    }
//                }
//            }
//        }
//    }
//
//    @IBAction func createAccountButtonTapped(_ sender: Any) {
//        performSegue(withIdentifier: "goToCreateAccount", sender: self)
//    }
//
//    func validateFields() -> String? {
//        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
//            return "Please fill in the email field."
//        }
//        if passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
//            return "Please fill in the password field."
//        }
//        return nil
//    }
//
//    func showError(_ message: String) {
//        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//        present(alert, animated: true, completion: nil)
//    }
//}

import UIKit
import Firebase
import FirebaseAuth

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var createAccountButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func logInButtonTapped(_ sender: Any) {
        // Validate fields
        let error = validateFields()
        if let error = error {
            showError(error)
        } else {
            Auth.auth().signIn(withEmail: emailTextField.text ?? "", password: passwordTextField.text ?? "") { (authResult, error) in
                if let error = error {
                    self.showError(error.localizedDescription)
                } else {
                    UserDefaults.standard.set(true, forKey: "isLoggedIn")
                    self.fetchUsernameAndSave()
                    let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
                    if let vc = mainStoryboard.instantiateInitialViewController() {
                        self.present(vc, animated: true, completion: nil)
                    }
                }
            }
        }
    }

    func fetchUsernameAndSave() {
        if let user = Auth.auth().currentUser {
            user.getIDTokenForcingRefresh(true) { (_, error) in
                if let error = error {
                    print("Error fetching username: \(error.localizedDescription)")
                }
                else {
                    let username = user.displayName ?? "Unknown User"
                    UserDefaults.standard.set(username, forKey: "username")
                    print("Username saved in UserDefaults: \(username)")
                }
            }
        }
    }

    @IBAction func createAccountButtonTapped(_ sender: Any) {
        performSegue(withIdentifier: "goToCreateAccount", sender: self)
    }

    func validateFields() -> String? {
        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            return "Please fill in the email field."
        }
        if passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            return "Please fill in the password field."
        }
        return nil
    }

    func showError(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

