//
//  OnboardingSlide.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 31/05/24.
//

import UIKit

struct OnboardingSlide {
    let title: String
    let description: String
    let image: UIImage
}
