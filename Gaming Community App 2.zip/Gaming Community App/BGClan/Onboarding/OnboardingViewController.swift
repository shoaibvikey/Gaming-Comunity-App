//
//  OnboardingViewController.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 31/05/24.
//

import UIKit

class OnboardingViewController: UIViewController {
    
    var currentPage = 0 {
        didSet{
            pageControl.currentPage = currentPage
            if currentPage == slides.count-1{
                nextButton.setTitle("Get Started", for: .normal)
            } else {
                nextButton.setTitle("Next", for: .normal)
            }
        }
    }
    var slides: [OnboardingSlide] = []
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var nextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        slides = [ OnboardingSlide(title: "Community", description: "Build a Community with fellow Gamers and Ace it together!!!", image: UIImage(imageLiteralResourceName: "GS1")),OnboardingSlide(title: "Event Updates", description:"Get Event updates straight from the Organizers.", image: UIImage(imageLiteralResourceName: "GS2")), OnboardingSlide(title: "It's all about Team", description: "Create a team or Join a team for playing together.", image: UIImage(imageLiteralResourceName: "GS3")) ]
    }
    
    
    @IBAction func nextButtonTapped(_ sender: Any) {
        if currentPage == slides.count - 1 {
            let controller = storyboard?.instantiateViewController(identifier: "GetStartedNavigationController") as! UINavigationController
            controller.modalPresentationStyle = .fullScreen
            present(controller, animated: true, completion: nil)
        } else {
            currentPage += 1
            let indexPath = IndexPath(item: currentPage, section: 0)
            collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true )
        }
    }
    
}

extension OnboardingViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int { return slides.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OnboardingCollectionViewCell.identifier, for: indexPath) as! OnboardingCollectionViewCell
        cell.setup(slides[indexPath.row])
        return cell
    }
    //to set the image height and width according to the collection view frame size
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    //to get the page controller moving
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let width = scrollView.frame.width
        currentPage = Int(scrollView.contentOffset.x / width)
        pageControl.currentPage = currentPage
    }
}
