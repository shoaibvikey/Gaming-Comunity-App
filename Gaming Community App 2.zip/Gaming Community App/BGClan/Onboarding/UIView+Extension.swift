//
//  UIView+Extension.swift
//  BGClan
//
//  Created by Vineet Chaudhary on 31/05/24.
//

import UIKit

extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        get { return self.cornerRadius }
        set {
            self.layer.cornerRadius = newValue
        }
    }
    
}
