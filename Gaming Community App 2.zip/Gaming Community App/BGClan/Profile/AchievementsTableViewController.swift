//import UIKit
//import Firebase
//import FirebaseFirestore
//import FirebaseStorage
//
//class AchievementsTableViewController: UITableViewController {
//    
//    var achievements: [Achievements] = [] // Initialize it with the global achievements array
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Assuming "achievementCell" is the identifier you set in the storyboard or XIB for your cell
//        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "achievementCell")
//        
//        navigationItem.rightBarButtonItem = editButtonItem
//        addLongPressGesture()
//        
//        // Initialize the local achievements array with global data
//        achievements = globalAchievements
//    }
//    
//    // Add long press gesture to table view
//    private func addLongPressGesture() {
//        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
//        tableView.addGestureRecognizer(longPressGesture)
//    }
//    
//    @objc private func handleLongPress(gesture: UILongPressGestureRecognizer) {
//        let point = gesture.location(in: tableView)
//        if let indexPath = tableView.indexPathForRow(at: point) {
//            if gesture.state == .began {
//                // Toggle editing mode
//                setEditing(!isEditing, animated: true)
//            }
//        }
//    }
//    
//    // MARK: - Table view data source
//    
//    override func numberOfSections(in tableView: UITableView) -> Int {
//        return 1
//    }
//    
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return achievements.count
//    }
//    
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "achievementCell", for: indexPath)
//        
//        let achievement = achievements[indexPath.row]
//        
//        // Clear previous content
//        cell.contentView.subviews.forEach { $0.removeFromSuperview() }
//        
//        // Configure image view
//        let imageView = UIImageView()
//        imageView.translatesAutoresizingMaskIntoConstraints = false
//        imageView.image = achievement.eventPoster
//        imageView.contentMode = .scaleAspectFit
//        cell.contentView.addSubview(imageView)
//        
//        NSLayoutConstraint.activate([
//            imageView.leadingAnchor.constraint(equalTo: cell.contentView.leadingAnchor, constant: 10),
//            imageView.centerYAnchor.constraint(equalTo: cell.contentView.centerYAnchor),
//            imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor), // 1:1 aspect ratio
//            imageView.heightAnchor.constraint(equalToConstant: 50) // Fixed height
//        ])
//        
//        // Configure event name label
//        let eventNameLabel = UILabel()
//        eventNameLabel.translatesAutoresizingMaskIntoConstraints = false
//        eventNameLabel.text = achievement.eventName
//        eventNameLabel.font = UIFont.systemFont(ofSize: 14)
//        cell.contentView.addSubview(eventNameLabel)
//        
//        NSLayoutConstraint.activate([
//            eventNameLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 10),
//            eventNameLabel.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: -10),
//            eventNameLabel.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10)
//        ])
//        
//        // Configure event rank label
//        let eventRankLabel = UILabel()
//        eventRankLabel.translatesAutoresizingMaskIntoConstraints = false
//        eventRankLabel.text = achievement.eventRank
//        eventRankLabel.font = UIFont.systemFont(ofSize: 12)
//        cell.contentView.addSubview(eventRankLabel)
//        
//        NSLayoutConstraint.activate([
//            eventRankLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 10),
//            eventRankLabel.trailingAnchor.constraint(equalTo: cell.contentView.trailingAnchor, constant: -10),
//            eventRankLabel.topAnchor.constraint(equalTo: eventNameLabel.bottomAnchor, constant: 5),
//            eventRankLabel.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10)
//        ])
//        
//        return cell
//    }
//    
//    // Enable editing mode
//    override func setEditing(_ editing: Bool, animated: Bool) {
//        super.setEditing(editing, animated: animated)
//        tableView.setEditing(editing, animated: animated)
//    }
//    
//    // Commit editing style for row
//    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            achievements.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
//        }
//    }
//    
//    @IBAction func unwindToAchievements(unwindSegue: UIStoryboardSegue) {
//        if unwindSegue.identifier == "saveAchievement" {
//            guard let addVC = unwindSegue.source as? AddAchievemnetsTableViewController else {
//                return }
//                guard let image = gamingEventImage.image,
//                      let name = gamingEventName.text,
//                      let rank = gamingEventRank.text else {
//                    print("Missing information")
//                    return
//                }
//                achievement = Achievements(eventName: name, eventPoster: image, eventRank: rank)
//                saveAchievementToFirebase(achievement: achievement!)
//                
//                
//                
//                return
//            
//            guard let newAchievement = addVC.achievement else { return }
//            achievements.append(newAchievement)
//            tableView.reloadData()
//        } else if unwindSegue.identifier == "cancelAchievement" {
//            print("Cancel")
//        }
//    }
//    
//    // Save achievement to Firebase
//    func saveAchievementToFirebase(achievement: Achievements) {
//        print("Starting to save achievement to Firebase")
//        uploadImageToStorage(image: achievement.eventPoster) { url in
//            guard let imageUrl = url else {
//                print("Failed to upload image")
//                return
//            }
//            print("Image uploaded successfully with URL: \(imageUrl)")
//            self.fetchUsername { username in
//                guard let username = username else {
//                    print("Failed to fetch username")
//                    return
//                }
//                print("Username fetched successfully: \(username)")
//                self.saveDataToFirestore(eventName: achievement.eventName, eventRank: achievement.eventRank, imageUrl: imageUrl, username: username)
//            }
//        }
//    }
//
//    // Upload image to Firebase Storage
//    func uploadImageToStorage(image: UIImage, completion: @escaping (String?) -> Void) {
//        print("Starting image upload")
//        guard let imageData = image.jpegData(compressionQuality: 0.75) else {
//            print("Failed to get image data")
//            completion(nil)
//            return
//        }
//
//        let storageRef = Storage.storage().reference().child("eventImages/\(UUID().uuidString).jpg")
//        storageRef.putData(imageData, metadata: nil) { metadata, error in
//            if let error = error {
//                print("Error uploading image: \(error.localizedDescription)")
//                completion(nil)
//                return
//            }
//
//            storageRef.downloadURL { url, error in
//                if let error = error {
//                    print("Error getting download URL: \(error.localizedDescription)")
//                    completion(nil)
//                    return
//                }
//
//                completion(url?.absoluteString)
//            }
//        }
//    }
//
//    // Fetch username from Firestore
//    func fetchUsername(completion: @escaping (String?) -> Void) {
//        print("Fetching username from Firestore")
//        guard let currentUser = Auth.auth().currentUser else {
//            print("No user is logged in")
//            completion(nil)
//            return
//        }
//
//        let userId = currentUser.uid
//        let db = Firestore.firestore()
//        let userRef = db.collection("users").document(userId)
//        userRef.getDocument { document, error in
//            if let error = error {
//                print("Error fetching user data: \(error.localizedDescription)")
//                completion(nil)
//                return
//            }
//
//            guard let document = document, document.exists else {
//                print("User document does not exist")
//                completion(nil)
//                return
//            }
//
//            let username = document.data()?["username"] as? String
//            completion(username)
//        }
//    }
//
//    // Save data to Firestore
//    func saveDataToFirestore(eventName: String, eventRank: String, imageUrl: String, username: String) {
//        print("Saving data to Firestore")
//        let db = Firestore.firestore()
//        db.collection("achievements").addDocument(data: [
//            "eventName": eventName,
//            "eventRank": eventRank,
//            "eventPosterURL": imageUrl,
//            "username": username,
//            "userId": Auth.auth().currentUser?.uid ?? "Unknown"
//        ]) { error in
//            if let error = error {
//                print("Error adding document: \(error.localizedDescription)")
//            } else {
//                print("Document added successfully")
//            }
//        }
//    }
//}
//
