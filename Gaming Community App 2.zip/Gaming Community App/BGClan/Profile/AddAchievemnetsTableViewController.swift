//
//  AddAchievemnetsTableViewController.swift
//  BGClan
//
//  Created by Batch-2 on 29/05/24.


import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage
import FirebaseFirestore

class AddAchievemnetsTableViewController: UITableViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // Creating outlets for my adding achievements.
    
    
    //    This is declare to get new data store in it then push into Achievement structure through it
    var achievement:Achievements?=nil
    
    @IBOutlet weak var gamingEventImage: UIImageView!
    @IBOutlet weak var gamingEventName: UITextView!
    @IBOutlet weak var gamingEventRank: UITextView!
    @IBOutlet weak var saveAchievementsButton: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Add tap gesture recognizer to the UIImageView
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        gamingEventImage.isUserInteractionEnabled = true
        gamingEventImage.addGestureRecognizer(tapGesture)
        
        gamingEventName.layer.borderColor = UIColor.lightGray.cgColor
        gamingEventName.layer.borderWidth = 1.0
        gamingEventName.layer.cornerRadius = 5.0
        
        gamingEventRank
            .layer.borderColor = UIColor.lightGray.cgColor
        gamingEventRank.layer.borderWidth = 1.0
        gamingEventRank.layer.cornerRadius = 5.0
        
        
        
        
        
    }
    @objc func imageTapped() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
            guard let image = gamingEventImage.image,
                  let name = gamingEventName.text,
                  let rank = gamingEventRank.text else {
                print("Missing information")
                return
            }
            achievement = Achievements(eventName: name, eventPoster: image, eventRank: rank)
            saveAchievementToFirebase(achievement: achievement!)
        }

        // Save achievement to Firebase
        func saveAchievementToFirebase(achievement: Achievements) {
            print("Starting to save achievement to Firebase")
            uploadImageToStorage(image: achievement.eventPoster) { url in
                guard let imageUrl = url else {
                    print("Failed to upload image")
                    return
                }
                print("Image uploaded successfully with URL: \(imageUrl)")
                self.fetchUsername { username in
                    guard let username = username else {
                        print("Failed to fetch username")
                        return
                    }
                    print("Username fetched successfully: \(username)")
                    self.saveDataToFirestore(eventName: achievement.eventName, eventRank: achievement.eventRank, imageUrl: imageUrl, username: username)
                }
            }
        }

        // Upload image to Firebase Storage
        func uploadImageToStorage(image: UIImage, completion: @escaping (String?) -> Void) {
            print("Starting image upload")
            guard let imageData = image.jpegData(compressionQuality: 0.75) else {
                print("Failed to get image data")
                completion(nil)
                return
            }

            let storageRef = Storage.storage().reference().child("eventImages/\(UUID().uuidString).jpg")
            storageRef.putData(imageData, metadata: nil) { metadata, error in
                if let error = error {
                    print("Error uploading image: \(error.localizedDescription)")
                    completion(nil)
                    return
                }

                storageRef.downloadURL { url, error in
                    if let error = error {
                        print("Error getting download URL: \(error.localizedDescription)")
                        completion(nil)
                        return
                    }

                    completion(url?.absoluteString)
                }
            }
        }

        // Fetch username from Firestore
        func fetchUsername(completion: @escaping (String?) -> Void) {
            print("Fetching username from Firestore")
            guard let currentUser = Auth.auth().currentUser else {
                print("No user is logged in")
                completion(nil)
                return
            }

            let userId = currentUser.uid
            let db = Firestore.firestore()
            let userRef = db.collection("users").document(userId)
            userRef.getDocument { document, error in
                if let error = error {
                    print("Error fetching user data: \(error.localizedDescription)")
                    completion(nil)
                    return
                }

                guard let document = document, document.exists else {
                    print("User document does not exist")
                    completion(nil)
                    return
                }

                let username = document.data()?["username"] as? String
                completion(username)
            }
        }

        // Save data to Firestore
        func saveDataToFirestore(eventName: String, eventRank: String, imageUrl: String, username: String) {
            print("Saving data to Firestore")
            let db = Firestore.firestore()
            db.collection("achievements").addDocument(data: [
                "eventName": eventName,
                "eventRank": eventRank,
                "eventPosterURL": imageUrl,
                "username": username,
                "userId": Auth.auth().currentUser?.uid ?? "Unknown"
            ]) { error in
                if let error = error {
                    print("Error adding document: \(error.localizedDescription)")
                } else {
                    print("Document added successfully")
                }
            }
        }
    }


