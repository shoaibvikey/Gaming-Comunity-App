//import UIKit
//import AVFoundation
//import Foundation
//
//class EditAccountTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//    
//    @IBOutlet weak var imageView: UIImageView!
//    @IBOutlet weak var deviceTextField: UITextField!
//    @IBOutlet weak var roleTextField: UITextField!
//    @IBOutlet weak var fullNameTextField: UITextField!
//    @IBOutlet weak var phoneNumberTextField: UITextField!
//    @IBOutlet weak var bioTextField: UITextField!
//    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//        setupImageViewTapGesture()
//        
//    }
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        DataManager.shared.loadData() 
//    }
//    func setupImageViewTapGesture() {
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
//        imageView.isUserInteractionEnabled = true
//        imageView.addGestureRecognizer(tapGesture)
//    }
//    
//    @objc func imageTapped() {
//        let actionSheet = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
//        
//        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
//            self.presentImagePicker(sourceType: .camera)
//        }))
//        
//        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { _ in
//            self.presentImagePicker(sourceType: .photoLibrary)
//        }))
//        
//        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//        
//        present(actionSheet, animated: true, completion: nil)
//    }
//    
//    func presentImagePicker(sourceType: UIImagePickerController.SourceType) {
//        let status = AVCaptureDevice.authorizationStatus(for: .video)
//        
//        if sourceType == .camera && status == .denied {
//            let alert = UIAlertController(title: "Camera Access Denied", message: "Please allow camera access in settings to use the camera.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//            return
//        }
//        
//        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = sourceType
//            imagePicker.allowsEditing = false
//            present(imagePicker, animated: true, completion: nil)
//        } else {
//            let alert = UIAlertController(title: "Source Unavailable", message: "The selected source is not available on this device.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//        }
//    }
//    
//    // UIImagePickerControllerDelegate method
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
//            imageView.image = selectedImage
//        }
//        dismiss(animated: true, completion: nil)
//    }
//    
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        dismiss(animated: true, completion: nil)
//    }
//    
//    @IBAction func doneButtonTapped(_ sender: UIBarButtonItem) {
//        // Assigning the values only if they are non-empty
//        if let fullName = fullNameTextField.text, !fullName.isEmpty {
//            DataManager.shared.fullName = fullName
//        }
//        if let role = roleTextField.text, !role.isEmpty {
//            DataManager.shared.teamRole = role
//        }
//        if let device = deviceTextField.text, !device.isEmpty {
//            DataManager.shared.deviceName = device
//        }
//        if let bio = bioTextField.text, !bio.isEmpty {
//            DataManager.shared.bio = bio
//        }
//        if let phoneNumber = phoneNumberTextField.text, !phoneNumber.isEmpty {
//            DataManager.shared.phoneNumber = phoneNumber
//        }
//        if let profilePicture = imageView.image {
//            DataManager.shared.profilePicture = profilePicture
//        }
//        
//        // Printing values for debugging
//        print("Full Name: \(DataManager.shared.fullName ?? "nil")")
//        print("Role: \(DataManager.shared.teamRole ?? "nil")")
//        print("Bio: \(DataManager.shared.bio ?? "nil")")
//        print("Device Name: \(DataManager.shared.deviceName ?? "nil")")
//        print("Phone Number: \(DataManager.shared.phoneNumber ?? "nil")")
//        
//        // Posting notification to update UI
//        NotificationCenter.default.post(name: .fullNameUpdate, object: nil)
//        
//        // Dismissing the current view controller
//        dismiss(animated: true, completion: nil)
//    }
//}
//import UIKit
//import AVFoundation
//import Foundation
//
//class EditAccountTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//    
//    @IBOutlet weak var imageView: UIImageView!
//    @IBOutlet weak var deviceTextField: UITextField!
//    @IBOutlet weak var roleTextField: UITextField!
//    @IBOutlet weak var fullNameTextField: UITextField!
//    @IBOutlet weak var phoneNumberTextField: UITextField!
//    @IBOutlet weak var bioTextField: UITextField!
//    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//        setupImageViewTapGesture()
//    }
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        DataController.shared.loadUserData() // Load user data when the view loads
//    }
//    
//    func setupImageViewTapGesture() {
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
//        imageView.isUserInteractionEnabled = true
//        imageView.addGestureRecognizer(tapGesture)
//    }
//    
//    @objc func imageTapped() {
//        let actionSheet = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
//        
//        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
//            self.presentImagePicker(sourceType: .camera)
//        }))
//        
//        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { _ in
//            self.presentImagePicker(sourceType: .photoLibrary)
//        }))
//        
//        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//        
//        present(actionSheet, animated: true, completion: nil)
//    }
//    
//    func presentImagePicker(sourceType: UIImagePickerController.SourceType) {
//        let status = AVCaptureDevice.authorizationStatus(for: .video)
//        
//        if sourceType == .camera && status == .denied {
//            let alert = UIAlertController(title: "Camera Access Denied", message: "Please allow camera access in settings to use the camera.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//            return
//        }
//        
//        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = sourceType
//            imagePicker.allowsEditing = false
//            present(imagePicker, animated: true, completion: nil)
//        } else {
//            let alert = UIAlertController(title: "Source Unavailable", message: "The selected source is not available on this device.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//        }
//    }
//    
//    // UIImagePickerControllerDelegate method
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
//            imageView.image = selectedImage
//        }
//        dismiss(animated: true, completion: nil)
//    }
//    
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        dismiss(animated: true, completion: nil)
//    }
//    @IBAction func doneButtonTapped(_ sender: UIBarButtonItem) {
//        var profileUpdated = false
//        
//        if let fullName = fullNameTextField.text, !fullName.isEmpty {
//            if fullName != DataController.shared.getFullName() {
//                DataController.shared.setFullName(fullName)
//                profileUpdated = true
//            }
//        }
//        
//        if let teamRole = roleTextField.text, !teamRole.isEmpty {
//            if teamRole != DataController.shared.getTeamRole() {
//                DataController.shared.setTeamRole(teamRole)
//                profileUpdated = true
//            }
//        }
//        
//        if let device = deviceTextField.text, !device.isEmpty {
//            if device != DataController.shared.getDeviceName() {
//                DataController.shared.setDeviceName(device)
//                profileUpdated = true
//            }
//        }
//        
//        if let bio = bioTextField.text, !bio.isEmpty {
//            if bio != DataController.shared.getBio() {
//                DataController.shared.setBio(bio)
//                profileUpdated = true
//            }
//        }
//        
//        if let phoneNumber = phoneNumberTextField.text, !phoneNumber.isEmpty {
//            if phoneNumber != DataController.shared.getPhoneNumber() {
//                DataController.shared.setPhoneNumber(phoneNumber)
//                profileUpdated = true
//            }
//        }
//        
//        if let profilePicture = imageView.image {
//            if profilePicture != DataController.shared.getProfilePicture() {
//                DataController.shared.setProfilePicture(profilePicture)
//                profileUpdated = true
//            }
//        }
//        
//        //        if profileUpdated {
//        //            NotificationCenter.default.post(name: .profileUpdated, object: nil)
//        //            print("Profile Updated")
//        //        } else {
//        //            print("No changes in profile")
//        //        }
//        //
//        //        dismiss(animated: true, completion: nil)
//        //
//        //
//        //    }
//        if profileUpdated {
//            NotificationCenter.default.post(name: .profileUpdated, object: nil)
//            print("Profile Updated")
//            
//            let alert = UIAlertController(title: "Success", message: "Data saved successfully.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
//                // Clear text fields
//                self.fullNameTextField.text = ""
//                self.roleTextField.text = ""
//                self.deviceTextField.text = ""
//                self.bioTextField.text = ""
//                self.phoneNumberTextField.text = ""
//                self.imageView.image = UIImage(named: "photo")
//                
//                // Dismiss the view controller
//                self.dismiss(animated: true, completion: nil)
//            }))
//            present(alert, animated: true, completion: nil)
//        } else {
//            print("No changes in profile")
//            
//            // Show alert for no changes
//            let alert = UIAlertController(title: "No Changes", message: "No changes were made to the profile.", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//            present(alert, animated: true, completion: nil)
//            
//            // Dismiss the view controller
//            dismiss(animated: true, completion: nil)
//        }
//    }
//}

import UIKit
import AVFoundation
import Foundation
import Firebase
import FirebaseFirestore
import FirebaseStorage

class EditAccountTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var deviceTextField: UITextField!
    @IBOutlet weak var roleTextField: UITextField!
    @IBOutlet weak var fullNameTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var bioTextField: UITextField!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupImageViewTapGesture()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUserData() 
        imageView.layer.cornerRadius = imageView.frame.size.width / 2
            imageView.clipsToBounds = true
        
        
        // Load user data when the view loads
    }
    
    func setupImageViewTapGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped))
        imageView.isUserInteractionEnabled = true
        imageView.addGestureRecognizer(tapGesture)
    }
    
    @objc func imageTapped() {
        let actionSheet = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.presentImagePicker(sourceType: .camera)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { _ in
            self.presentImagePicker(sourceType: .photoLibrary)
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        present(actionSheet, animated: true, completion: nil)
    }
    
    func presentImagePicker(sourceType: UIImagePickerController.SourceType) {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        
        if sourceType == .camera && status == .denied {
            let alert = UIAlertController(title: "Camera Access Denied", message: "Please allow camera access in settings to use the camera.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            return
        }
        
        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = sourceType
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "Source Unavailable", message: "The selected source is not available on this device.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
    
    // UIImagePickerControllerDelegate method
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imageView.image = selectedImage
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func fetchUserData() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()
        
        db.collection("users").document(userID).getDocument { (document, error) in
            if let document = document, document.exists {
                let data = document.data()
                self.fullNameTextField.text = data?["fullName"] as? String
                self.roleTextField.text = data?["role"] as? String
                self.deviceTextField.text = data?["device"] as? String
                self.phoneNumberTextField.text = data?["phoneNumber"] as? String
                self.bioTextField.text = data?["bio"] as? String
            } else {
                print("Document does not exist")
            }
        }
        
        let storageRef = Storage.storage().reference()
        let profilePictureRef = storageRef.child("profilePictures/\(userID).jpg")
        profilePictureRef.downloadURL { url, error in
            if let error = error {
                print("Error getting profile picture URL: \(error.localizedDescription)")
                return
            }
            guard let url = url else { return }
            self.loadProfilePicture(url: url)
        }
    }
    
    func loadProfilePicture(url: URL) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error loading profile picture: \(error.localizedDescription)")
                return
            }
            guard let data = data, let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                self.imageView.image = image
            }
        }
        task.resume()
    }
    
    @IBAction func doneButtonTapped(_ sender: UIBarButtonItem) {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()
        let storageRef = Storage.storage().reference()
        let profilePictureRef = storageRef.child("profilePictures/\(userID).jpg")
        
        var profileUpdated = false
        
        var userData: [String: Any] = [:]
        
        if let fullName = fullNameTextField.text, !fullName.isEmpty {
            userData["fullName"] = fullName
            profileUpdated = true
        }
        
        if let teamRole = roleTextField.text, !teamRole.isEmpty {
            userData["role"] = teamRole
            profileUpdated = true
        }
        
        if let device = deviceTextField.text, !device.isEmpty {
            userData["device"] = device
            profileUpdated = true
        }
        
        if let bio = bioTextField.text, !bio.isEmpty {
            userData["bio"] = bio
            profileUpdated = true
        }
        
        if let phoneNumber = phoneNumberTextField.text, !phoneNumber.isEmpty {
            userData["phoneNumber"] = phoneNumber
            profileUpdated = true
        }
        
        if let profilePicture = imageView.image, let imageData = profilePicture.jpegData(compressionQuality: 0.8) {
            profileUpdated = true
            profilePictureRef.putData(imageData, metadata: nil) { metadata, error in
                if let error = error {
                    print("Error uploading profile picture: \(error.localizedDescription)")
                    return
                }
                profilePictureRef.downloadURL { url, error in
                    if let error = error {
                        print("Error getting profile picture URL: \(error.localizedDescription)")
                        return
                    }
                    guard let url = url else { return }
                    userData["profilePictureURL"] = url.absoluteString
                    
                    // Save user data to Firestore
                    db.collection("users").document(userID).setData(userData, merge: true) { error in
                        if let error = error {
                            print("Error updating user data: \(error.localizedDescription)")
                        } else {
                            print("User data successfully updated")
                            NotificationCenter.default.post(name: .profileUpdated, object: nil)
                            
                            let alert = UIAlertController(title: "Success", message: "Data saved successfully.", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                                self.clearFields()
//                                self.dismiss(animated: true, completion: nil)
                            }))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
            }
        } else {
            // Save user data to Firestore without updating profile picture
            if profileUpdated {
                db.collection("users").document(userID).setData(userData, merge: true) { error in
                    if let error = error {
                        print("Error updating user data: \(error.localizedDescription)")
                    } else {
                        print("User data successfully updated")
                        NotificationCenter.default.post(name: .profileUpdated, object: nil)
                        
                        let alert = UIAlertController(title: "Success", message: "Data saved successfully.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            self.clearFields()
                            self.dismiss(animated: true, completion: nil)
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            } else {
                print("No changes in profile")
                
                let alert = UIAlertController(title: "No Changes", message: "No changes were made to the profile.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                present(alert, animated: true, completion: nil)
                
                dismiss(animated: true, completion: nil)
            }
        }
    }
    
    func clearFields() {
        fullNameTextField.text = ""
        roleTextField.text = ""
        deviceTextField.text = ""
        bioTextField.text = ""
        phoneNumberTextField.text = ""
        imageView.image = UIImage(named: "photo")
    }
   
}

//extension Notification.Name {
//    static let profileUpdated = Notification.Name("profileUpdated")
//}
