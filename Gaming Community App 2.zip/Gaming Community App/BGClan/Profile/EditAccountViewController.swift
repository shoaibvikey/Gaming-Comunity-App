//
//  EditAccountViewController.swift
//  BGClan
//
//  Created by Batch-2 on 27/05/24.
//

import UIKit

class EditAccountViewController: UIViewController {

    
    
    
    
    @IBOutlet weak var fullNameTextField: UITextField!
  
    @IBOutlet weak var phoneNumberTextField: UITextField!
    
    @IBOutlet weak var bioTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
