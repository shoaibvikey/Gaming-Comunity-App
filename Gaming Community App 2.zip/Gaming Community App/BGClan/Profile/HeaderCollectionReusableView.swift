//
//  HeaderCollectionReusableView.swift
//  BGClan
//
//  Created by Divyanshu rai on 12/06/24.
//

import UIKit

class HeaderCollectionReusableView: UICollectionReusableView {
    //    outlets
   
    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var fullName: UILabel!
    
    @IBOutlet weak var userName: UILabel!
    
    
    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var deviceLabel: UILabel!
    @IBOutlet weak var roleLabel: UILabel!
    @IBOutlet weak var followButton: UIButton!
    
    
    @IBOutlet weak var BioLabel: UILabel!
    
    // Function to configure the header with user data
    func configure(with userData: UserData?, profilePicture: UIImage?) {
            guard let userData = userData else {
                return
            }
            BioLabel.text = userData.fullName
            deviceLabel.text = userData.device
            roleLabel.text = userData.inGameRole
            userName.text = userData.username
//            teamLabel.text = userData.team
            profileImage.image = profilePicture
        fullName.text = userData.fullName
        }
    
 
 }
