//
//  postsCollectionViewCell.swift
//  BGClan
//
//  Created by Batch-2 on 28/05/24.
//

import UIKit

class postsCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var postsImages: UIImageView!
   
    
    
}
