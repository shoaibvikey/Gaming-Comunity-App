////
////  PostDetailTableViewController.swift
////  BGClan
////
////  Created by Vineet Chaudhary on 06/06/24.


import UIKit
import FirebaseFirestore
import FirebaseStorage

class PostDetailTableViewController: UITableViewController {
    @IBOutlet weak var postImage: UIImageView!
    
    
    @IBOutlet weak var profilePhoto: UIImageView!
    
    @IBOutlet weak var likeButton: UIButton!
    
    @IBOutlet weak var userName: UILabel!
    
    @IBOutlet weak var commentsButton: UIButton!
    @IBOutlet weak var captionLabel: UILabel!
    
    
    var postsOnHome: [PostModel] = []
    var username: String?
    var post:PostModel?
    var profilePicture: UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource=self
        tableView.delegate=self
        displayPostDetails()
    }
    
    func displayPostDetails() {
        if let post = post {
            postImage.image = post.image // Correct assignment
            userName.text = post.username
            captionLabel.text = post.caption
            profilePhoto.image = profilePicture // Assuming profilePicture is already downloaded
        }
    }
    }

