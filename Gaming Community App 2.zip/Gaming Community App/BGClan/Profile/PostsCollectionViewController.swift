//import UIKit
//
//class PostsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
//    
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Profile"
//        self.tabBarItem.image = UIImage(systemName: "person")
//    }
    var tsetingdata=["111","111","111","111","111","111","111","111","111","111","111","111","111","111","111","111","111","111","ach1"]
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//    }
//    //    override func numberOfSections(in collectionView: UICollectionView) -> Int {
//    //        1
//    //    }
//    
//    
//    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        tsetingdata.count
//    }
//    
//    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "header", for: indexPath) as! HeaderCollectionReusableView
//        
//        
//        header.BioLabel.text="auaua"
//        header.deviceLabel.text="device"
//        header.roleLabel.text="role"
//        header.userName.text="useranme"
//        header.teamLabel.text="team"
//        
//        return header
//    }
//    
//    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! postsCollectionViewCell
//        cell.postsImages.image=UIImage(named: tsetingdata[indexPath.row])
//        return cell
//    }
//    
//    
//
//    
//   
//    // UICollectionViewDelegateFlowLayout methods
////    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
////        print("help")
////     return    CGSize(width: collectionView.frame.size.width / 3, height: collectionView.frame.size.height/7-3)
////       
////    }
////
////    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
////        return  3// Adjust this value as needed for the spacing between rows
////    }
////
////    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
////        return 0// Adjust this value as needed for the spacing between items in the same row
////    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//            let width = collectionView.frame.size.width  / 3 - 6 // Subtracting 6 for the interitem spacing (3 pixels on each side of each cell)
//            let height = collectionView.frame.size.height / 7 - 3 // Subtracting 3 for the line spacing
//            
//            return CGSize(width: width, height: height)
//        }
//
//        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//            return 3 // Adjust this value as needed for the spacing between rows
//        }
//
//        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//            return 1 // Adjust this value as needed for the spacing between items in the same row
//        }
//
//}
 

//
//import UIKit
//import Firebase
//import FirebaseStorage
//import FirebaseFirestore
//
//class PostsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
//
//    // Add variables to store user data
//    var userData: UserData?
//    var profilePicture: UIImage?
//    
//    // Add a reference to Firebase Firestore and Storage
//    let db = Firestore.firestore()
//    let storage = Storage.storage()
//
//    required init?(coder: NSCoder) {
//         super.init(coder: coder)
//         self.tabBarItem.title = "Profile"
//         self.tabBarItem.image = UIImage(systemName: "person")
//     }
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Fetch user data and profile picture
//        fetchUserData()
//    }
//
//    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return 12
//    }
//
//    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "header", for: indexPath) as! HeaderCollectionReusableView
//
//        // Update UI with user data (if available)
//        updateUI(header)
//
//        return header
//    }
//
//    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! postsCollectionViewCell
//        cell.postsImages.image = UIImage(named: tsetingdata[indexPath.row])
//        return cell
//    }
//
//    // MARK: - Firebase Integration
//
//    func fetchUserData() {
//        // Get the currently authenticated user
//        guard let currentUser = Auth.auth().currentUser else {
//            print("No authenticated user found")
//            return
//        }
//
//        let uid = currentUser.uid
//
//        // Fetch user data based on UID
//        db.collection("users").document(uid).addSnapshotListener { documentSnapshot, error in
//            if let error = error {
//                print("Error fetching user data: \(error.localizedDescription)")
//                return
//            }
//            
//            guard let document = documentSnapshot, document.exists else {
//                print("No document found for UID: \(uid)")
//                return
//            }
//            
//            let data = document.data()
//            print("User document data: \(String(describing: data))")
//
//            // Ensure the document exists and contains required fields
//            guard let fullName = data?["fullName"] as? String,
//                  let inGameRole = data?["userInGameRole"] as? String,
//                  let bio = data?["bio"] as? String,
//                  let profilePictureURL = data?["profilePictureURL"] as? String else {
//                      print("User data is incomplete or malformed: \(String(describing: data))")
//                      return
//                  }
//
//            // Parse user data
//            self.userData = UserData(username: currentUser.displayName ?? "Unknown User",
//                                     fullName: fullName,
//                                     inGameRole: inGameRole,
//                                     profilePictureURL: profilePictureURL,
//                                     bio: bio)
//
//            // Fetch profile picture using the URL
//            self.fetchProfilePicture(url: profilePictureURL)
//        }
//    }
//
//    func fetchProfilePicture(url: String) {
//        // Fetch profile picture from the URL
//        let storageRef = Storage.storage().reference(forURL: url)
//        
//        storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
//            if let error = error {
//                print("Error downloading profile picture: \(error.localizedDescription)")
//            } else {
//                if let data = data {
//                    self.profilePicture = UIImage(data: data)
//                    // Update UI with profile picture
//                    print("Profile picture fetched successfully")
//                    self.configureHeaderView()
//                }
//            }
//        }
//    }
//
//    func updateUI(_ header: HeaderCollectionReusableView?) {
//        guard let userData = userData else {
//            return
//        }
//
//        // Update UI elements with fetched data
//        if let header = header {
//            header.BioLabel.text = userData.bio
//            header.roleLabel.text = userData.inGameRole
//            header.userName.text = userData.username
//            // Set profile picture
//            header.profileImage.image = profilePicture
//        }
//    }
//
//    func configureHeaderView() {
//        if let headerView = collectionView.visibleSupplementaryViews(ofKind: UICollectionView.elementKindSectionHeader).first as? HeaderCollectionReusableView {
//            headerView.configure(with: userData, profilePicture: profilePicture)
//        }
//    }
//}

//by me

//import UIKit
//import Firebase
//import FirebaseStorage
//import FirebaseFirestore
//
//
//class PostsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
//    var post:[PostModel]=[]
//    var userData: UserData?
//    var profilePicture: UIImage?
//    var username: String? {
//        didSet {
//            if let username = username {
//                UserDefaults.standard.set(username, forKey: "username")
//                fetchUserDetails()
//                fetchUserPosts(username: username)
//            }
//        }
//    }
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Profile"
//        self.tabBarItem.image = UIImage(systemName: "person")
//    }
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        fetchCurrentUsername()
//    }
//
//    func fetchCurrentUsername() {
//        if let userId = Auth.auth().currentUser?.uid {
//            fetchUsernameForLoggedUser(userId: userId)
//        } else {
//            print("No user is logged in")
//        }
//    }
//
//    func fetchUsernameForLoggedUser(userId: String) {
//        let db = Firestore.firestore()
//        let userRef = db.collection("users").document(userId)
//        userRef.getDocument { document, error in
//            if let error = error {
//                print("Error fetching user data: \(error.localizedDescription)")
//            } else {
//                if let document = document, let userData = document.data(), let fetchedUsername = userData["username"] as? String {
//                    self.username = fetchedUsername
//                } else {
//                    print("Username not found for userId: \(userId)")
//                }
//            }
//        }
//    }
//
//    func fetchUserDetails() {
//        guard let username = username else {
//            print("Username not set")
//            return
//        }
//        print("Fetching details for username: \(username)")
//
//        let db = Firestore.firestore()
//        let usersRef = db.collection("users")
//
//        usersRef.whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching user details: \(error.localizedDescription)")
//                return
//            }
//
//            guard let documents = snapshot?.documents, let document = documents.first else {
//                print("User not found")
//                return
//            }
//
//            let data = document.data()
//            print("User data: \(data)")
//
//            self.userData = UserData(
//                username: data["username"] as? String ?? "",
//                fullName: data["fullName"] as? String ?? "",
//                inGameRole: data["userInGameRole"] as? String ?? "",
//                device: data["device"] as? String ?? "",
//                profilePictureURL: data["profilePictureURL"] as? String ?? ""
//            )
//
//            self.fetchProfilePicture(urlString: self.userData?.profilePictureURL)
//        }
//    }
//
//    func fetchProfilePicture(urlString: String?) {
//        guard let urlString = urlString else {
//            print("Invalid profile picture URL")
//            return
//        }
//
//        let storageRef = Storage.storage().reference(forURL: urlString)
//        storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
//            if let error = error {
//                print("Error fetching profile picture: \(error.localizedDescription)")
//                return
//            }
//
//            if let data = data {
//                self.profilePicture = UIImage(data: data)
//                self.collectionView.reloadData()
//            }
//        }
//    }
//
//    func fetchUserPosts(username: String) {
//        let db = Firestore.firestore()
//        let postsRef = db.collection("posts")
//
//        postsRef.whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching posts: \(error.localizedDescription)")
//                return
//            }
//
//            guard let documents = snapshot?.documents else {
//                print("No documents found")
//                return
//            }
//
//            var posts = [PostModel]()
//
//            for document in documents {
//                let data = document.data()
//                let post = PostModel(
//                    caption: data["caption"] as? String ?? "",
//                    contentPath: data["contentPath"] as? String ?? "",
//                    postingTime: data["postingTime"] as? String ?? "",
//                    likesCount: data["likesCount"] as? Int ?? 0,
//                    commentsCount: data["commentsCount"] as? Int ?? 0,
//                    username: data["username"] as? String ?? "",
//                    profileImageUrl: data["profilePicture"] as? String
//                )
//                posts.append(post)
//            }
////            added by divyanshu
//            self.post = posts
//
//// Print the contents of post array for debugging
//        print("Fetched \(self.post.count) posts: \(self.post)")
//
//        // Reload collection view data on the main thread
//        DispatchQueue.main.async {
//            self.collectionView.reloadData()
//    }
//        }
//    }
//
//    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return post.count // No posts to display for now
//    }
//
//    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "header", for: indexPath) as! HeaderCollectionReusableView
//
//        if let userData = userData {
//            header.configure(with: userData, profilePicture: profilePicture)
//        }
//
//        return header
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let width = collectionView.frame.size.width / 3 - 6 // Subtracting 6 for the interitem spacing (3 pixels on each side of each cell)
//        let height = collectionView.frame.size.height / 7 - 3 // Subtracting 3 for the line spacing
//        return CGSize(width: width, height: height)
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        return 3 // Adjust this value as needed for the spacing between rows
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//        return 1 // Adjust this value as needed for the spacing between items in the same row
//    }
//    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! postsCollectionViewCell
//
//        // Assuming postsCollectionViewCell has an imageView named postsImages
//        if indexPath.row < post.count {
//            let postItem = post[indexPath.row]
//            // Configure cell with post data
//            cell.postsImages.image = UIImage(named: postItem.contentPath) // Example, adjust as per your PostModel structure
//        }
//
//        return cell
//    }
//
//}



//******************************LAST WORKING**************************************
//import UIKit
//import Firebase
//import FirebaseFirestore
//import FirebaseStorage
//
//class PostsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
//
//    var post: [PostModel] = []
//    var userData: UserData?
//    var profilePicture: UIImage?
//    var username: String?
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//        self.tabBarItem.title = "Profile"
//        self.tabBarItem.image = UIImage(systemName: "person")
//    }
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        fetchCurrentUsername()
//    }
//
//    func fetchCurrentUsername() {
//        if let userId = Auth.auth().currentUser?.uid {
//            fetchUsernameForLoggedUser(userId: userId)
//        } else {
//            print("No user is logged in")
//        }
//    }
//
//    func fetchUsernameForLoggedUser(userId: String) {
//        let db = Firestore.firestore()
//        let userRef = db.collection("users").document(userId)
//        userRef.getDocument { document, error in
//            if let error = error {
//                print("Error fetching user data: \(error.localizedDescription)")
//            } else {
//                if let document = document, let userData = document.data(), let fetchedUsername = userData["username"] as? String {
//                    self.username = fetchedUsername
//                    self.fetchUserDetails() // Fetch user details after getting username
//                    self.fetchUserPosts(username: fetchedUsername) // Fetch posts after getting username
//                } else {
//                    print("Username not found for userId: \(userId)")
//                }
//            }
//        }
//    }
//
//    func fetchUserDetails() {
//        guard let username = username else {
//            print("Username not set")
//            return
//        }
//
//        let db = Firestore.firestore()
//        let usersRef = db.collection("users")
//
//        usersRef.whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching user details: \(error.localizedDescription)")
//                return
//            }
//
//            guard let documents = snapshot?.documents, let document = documents.first else {
//                print("User not found for username: \(username)")
//                return
//            }
//
//            let data = document.data()
//            print("User data: \(data)")
//
//            // Parse user data into UserData model
//            self.userData = UserData(
//                username: data["username"] as? String ?? "",
//                fullName: data["fullName"] as? String ?? "",
//                inGameRole: data["userInGameRole"] as? String ?? "",
//                device: data["device"] as? String ?? "",
//                profilePictureURL: data["profilePictureURL"] as? String ?? ""
//            )
//
//            // Fetch profile picture using the URL
//            self.fetchProfilePicture(urlString: self.userData?.profilePictureURL)
//        }
//    }
//
//    func fetchProfilePicture(urlString: String?) {
//        guard let urlString = urlString else {
//            print("Invalid profile picture URL")
//            return
//        }
//
//        let storageRef = Storage.storage().reference(forURL: urlString)
//        storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
//            if let error = error {
//                print("Error fetching profile picture: \(error.localizedDescription)")
//                return
//            }
//
//            if let data = data {
//                self.profilePicture = UIImage(data: data)
//                self.collectionView.reloadData() // Reload collection view after fetching profile picture
//            }
//        }
//    }
//
//    func fetchUserPosts(username: String) {
//        let db = Firestore.firestore()
//        let postsRef = db.collection("posts")
//
//        postsRef.whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
//            if let error = error {
//                print("Error fetching posts: \(error.localizedDescription)")
//                return
//            }
//
//            guard let documents = snapshot?.documents else {
//                print("No posts found for username: \(username)")
//                return
//            }
//
//            var posts = [PostModel]()
//
//            for document in documents {
//                let data = document.data()
//                let post = PostModel(
//                    caption: data["caption"] as? String ?? "",
//                    contentPath: data["contentPath"] as? String ?? "",
//                    postingTime: data["postingTime"] as? String ?? "",
//                    likesCount: data["likesCount"] as? Int ?? 0,
//                    commentsCount: data["commentsCount"] as? Int ?? 0,
//                    username: data["username"] as? String ?? "",
//                    profileImageUrl: data["profilePicture"] as? String // Assuming this is how profile picture URL is stored in posts
//                )
//                posts.append(post)
//            }
//
//            // Update posts array
//            self.post = posts
//
//            // Print fetched posts for debugging
//            print("Fetched \(self.post.count) posts: \(self.post)")
//
//            // Reload collection view data on the main thread
//            DispatchQueue.main.async {
//                self.collectionView.reloadData()
//            }
//        }
//    }
//
//    // MARK: - UICollectionViewDataSource
//
//    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return post.count
//    }
//
//    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! postsCollectionViewCell
//
//        let postItem = post[indexPath.row]
//        cell.postsImages.image = UIImage(named: postItem.profilePicture ?? "ach1") // Adjust as per your PostModel structure
//
//        return cell
//    }
//
//    // MARK: - UICollectionViewDelegateFlowLayout
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let width = collectionView.frame.size.width / 3 - 6 // Adjusted for spacing
//        let height = collectionView.frame.size.height / 7 - 3 // Adjusted for spacing
//        return CGSize(width: width, height: height)
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        return 3 // Adjust as needed
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//        return 1 // Adjust as needed
//    }
//
//    // MARK: - UICollectionViewDelegate
//
//    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "header", for: indexPath) as! HeaderCollectionReusableView
//
//        if let userData = userData {
//            header.configure(with: userData, profilePicture: profilePicture)
//        }
//
//        return header
//    }
//}




import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class PostsCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    var post: [PostModel] = []
    var userData: UserData?
    var profilePicture: UIImage?
    var username: String?

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "Profile"
        self.tabBarItem.image = UIImage(systemName: "person")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        fetchCurrentUsername()
    }

    func fetchCurrentUsername() {
        if let userId = Auth.auth().currentUser?.uid {
            fetchUsernameForLoggedUser(userId: userId)
        } else {
            print("No user is logged in")
        }
    }

    func fetchUsernameForLoggedUser(userId: String) {
        let db = Firestore.firestore()
        let userRef = db.collection("users").document(userId)
        userRef.getDocument { document, error in
            if let error = error {
                print("Error fetching user data: \(error.localizedDescription)")
            } else {
                if let document = document, let userData = document.data(), let fetchedUsername = userData["username"] as? String {
                    self.username = fetchedUsername
                    self.fetchUserDetails() // Fetch user details after getting username
                    self.fetchUserPosts(username: fetchedUsername) // Fetch posts after getting username
                } else {
                    print("Username not found for userId: \(userId)")
                }
            }
        }
    }

    func fetchUserDetails() {
        guard let username = username else {
            print("Username not set")
            return
        }

        let db = Firestore.firestore()
        let usersRef = db.collection("users")

        usersRef.whereField("username", isEqualTo: username).getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching user details: \(error.localizedDescription)")
                return
            }

            guard let documents = snapshot?.documents, let document = documents.first else {
                print("User not found for username: \(username)")
                return
            }

            let data = document.data()
            print("User data: \(data)")

            // Parse user data into UserData model
            self.userData = UserData(
                username: data["username"] as? String ?? "",
                fullName: data["fullName"] as? String ?? "",
                inGameRole: data["userInGameRole"] as? String ?? "",
                device: data["device"] as? String ?? "",
                profilePictureURL: data["profilePictureURL"] as? String ?? ""
            )

            // Fetch profile picture using the URL
            self.fetchProfilePicture(urlString: self.userData?.profilePictureURL)
        }
    }

    func fetchProfilePicture(urlString: String?) {
        guard let urlString = urlString else {
            print("Invalid profile picture URL")
            return
        }

        let storageRef = Storage.storage().reference(forURL: urlString)
        storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
            if let error = error {
                print("Error fetching profile picture: \(error.localizedDescription)")
                return
            }

            if let data = data {
                self.profilePicture = UIImage(data: data)
                self.collectionView.reloadData() // Reload collection view after fetching profile picture
            }
        }
    }

    func fetchUserPosts(username: String) {
        let db = Firestore.firestore()
        let postsRef = db.collection("posts")

        postsRef.whereField("username", isEqualTo: username).addSnapshotListener { (snapshot, error) in
            if let error = error {
                print("Error fetching posts: \(error.localizedDescription)")
                return
            }

            guard let documents = snapshot?.documents else {
                print("No posts found for username: \(username)")
                return
            }

            var posts = [PostModel]()

            let dispatchGroup = DispatchGroup()
            
            for document in documents {
                let data = document.data()
                let post = PostModel(
                    caption: data["caption"] as? String ?? "",
                    contentPath: data["imageUrl"] as? String ?? "",
                    postingTime: data["postingTime"] as? String ?? "",
                    likesCount: data["likesCount"] as? Int ?? 0,
                    commentsCount: data["commentsCount"] as? Int ?? 0,
                    username: data["username"] as? String ?? "",
                    profileImageUrl: data["profilePicture"] as? String
//                    image: nil
                )
                posts.append(post)
            }

            self.post = posts

            for (index, post) in self.post.enumerated() {
                guard !post.contentPath.isEmpty else { continue }
                dispatchGroup.enter()
                let storageRef = Storage.storage().reference(forURL: post.contentPath)
                storageRef.getData(maxSize: 100 * 1024 * 1024) { data, error in
                    if let error = error {
                        print("Error fetching image: \(error.localizedDescription)")
                    } else if let data = data {
                        self.post[index].image = UIImage(data: data)
                    }
                    dispatchGroup.leave()
                }
            }

            dispatchGroup.notify(queue: .main) {
                self.collectionView.reloadData()
            }
        }
    }


    // MARK: - UICollectionViewDataSource

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return post.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! postsCollectionViewCell
        
        let postItem = post[indexPath.row]
        if let image = postItem.image {
            cell.postsImages.image = image
        } else {
            cell.postsImages.image = UIImage(named: "placeholderImage") // Use a placeholder image
        }

        return cell
    }

    // MARK: - UICollectionViewDelegateFlowLayout

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.size.width / 3 - 6 // Adjusted for spacing
        let height = collectionView.frame.size.height / 7 - 3 // Adjusted for spacing
        return CGSize(width: width, height: height)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 3 // Adjust as needed
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1 // Adjust as needed
    }

    // MARK: - UICollectionViewDelegate

    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "header", for: indexPath) as! HeaderCollectionReusableView

        if let userData = userData {
            header.configure(with: userData, profilePicture: profilePicture)
        }

        return header
    }
    
    
//    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//            performSegue(withIdentifier: "showPostDetail", sender: indexPath)
//        }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            performSegue(withIdentifier: "showPostDetail", sender: indexPath)
        }

        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "showPostDetail",
               let destinationVC = segue.destination as? PostDetailTableViewController,
               let indexPath = sender as? IndexPath {
                let selectedPost = post[indexPath.row]
                destinationVC.post = selectedPost
                destinationVC.profilePicture = profilePicture
            }
        }

}
