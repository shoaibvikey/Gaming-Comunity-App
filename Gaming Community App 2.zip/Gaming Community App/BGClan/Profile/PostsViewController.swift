////
////  PostsVViewController.swift
////  BGClan
////
////  Created by Batch-2 on 26/05/24.
////
//
//import UIKit
//
//class PostsViewController: UIViewController ,UICollectionViewDataSource,UICollectionViewDelegate{
//    
//
//
//    @IBOutlet weak var postsCollectionView: UICollectionView!
//    
//    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        return 1
//    }
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return postList.count
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell=postsCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! postsCollectionViewCell
//        cell.postsImages.image=UIImage(named: postList[indexPath.row])
//        return cell
//    }
//    
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        postsCollectionView.dataSource=self
//        postsCollectionView.delegate=self
//        // Do any additional setup after loading the view.
//    }
//    
//
//    /*
//    // MARK: - Navigation
//
//    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // Get the new view controller using segue.destination.
//        // Pass the selected object to the new view controller.
//    }
//    */
//
//}
