import UIKit
import Firebase
import FirebaseFirestore
import FirebaseStorage

class ProfileTableViewController: UITableViewController {

    @IBOutlet weak var userNameLabel: UILabel!
   
    @IBOutlet weak var profilePictureImageView: UIImageView!
    @IBOutlet weak var teamNameLabel: UILabel!
    @IBOutlet weak var teamRoleLabel: UILabel!
    @IBOutlet weak var deviceNameLabel: UILabel!
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var bioLabel: UILabel!
//    @IBOutlet var postsAndAchievements: UISegmentedControl!
    
    @IBOutlet var postsTableView: UIView!
   
    
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        self.tabBarItem.title = "Profile"
        self.tabBarItem.image = UIImage(systemName: "person")
    }

    var textContent: String?

    override func viewDidLoad() {
        super.viewDidLoad()
//        teamNameLabel.text = textContent
//        postsAndAchievementsSegemtedControl(postsAndAchievements)
       
        NotificationCenter.default.addObserver(self, selector: #selector(updateProfile(_:)), name: .profileUpdated, object: nil)
        fetchUserData()
        profilePictureImageView.layer.cornerRadius = profilePictureImageView.frame.size.width / 2
                profilePictureImageView.clipsToBounds = true
//        navigationItem.title=userNameLabel.text
    }
    @IBAction func showPostDetail(_ sender: Any) {
        performSegue(withIdentifier: "showPostDetail", sender: self)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    func fetchUserData() {
        // Replace "userID" with the actual user ID
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let db = Firestore.firestore()

        // Fetch username and full name from Firestore
        db.collection("users").document(userID).getDocument { (document, error) in
            if let document = document, document.exists {
                let data = document.data()
                self.fullNameLabel.text = data?["fullName"] as? String
                self.userNameLabel.text = data?["username"] as? String
                self.teamRoleLabel.text = data?["role"] as? String
                self.deviceNameLabel.text = data?["device"] as? String
                self.bioLabel.text = data?["bio"] as? String
            } else {
                print("Document does not exist")
            }
        }

        // Fetch profile picture URL from Firebase Storage
        let storageRef = Storage.storage().reference()
        let profilePictureRef = storageRef.child("profilePictures/\(userID).jpg")
        profilePictureRef.downloadURL { url, error in
            if let error = error {
                print("Error getting profile picture URL: \(error.localizedDescription)")
                return
            }
            guard let url = url else { return }
            self.loadProfilePicture(url: url)
        }
    }

    func loadProfilePicture(url: URL) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("Error loading profile picture: \(error.localizedDescription)")
                return
            }
            guard let data = data, let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                self.profilePictureImageView.image = image
            }
        }
        task.resume()
    }

    @objc func updateProfile(_ notification: Notification) {
        fetchUserData()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        if segue.identifier == "showPostDetail" {
            if let postDetailVC = segue.destination as? PostDetailTableViewController {
                postDetailVC.username = userNameLabel.text
            }
        }
        
    }
    
}

extension Notification.Name {
    static let profileUpdated = Notification.Name("profileUpdated")
}
