//
//  SettingsDataModel.swift
//  CasterCom
//
//  Created by Shoaib Akhtar on 01/06/24.
//

import Foundation
import UIKit

struct PrivacyandPolicies {
    var heading: String
    var content: String
}

let privacyandPolicies: [PrivacyandPolicies] = [
    PrivacyandPolicies(heading: "Privacy Policy", content: ""),
    
    PrivacyandPolicies(heading: "1. Introduction", content: """
    Welcome to [CasterCom] ("we", "our", "us"). We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application [CasterCom] (the "App"). Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the App.
    """),
    PrivacyandPolicies(heading: "2. Information We Collect", content: """
    We may collect and store the following types of information:
    
    2.1 Personal Information
    - Identifiers: Name, email address, phone number, and other similar contact data.
    - Account Information: Username, password, and other security information used for authentication and account access.
    
    2.2 Usage Data
    - Device Information: IP address, device type, operating system version, and unique device identifiers.
    - App Usage Data: Access times, pages viewed, clicks, and other usage information.
    
    2.3 Location Data
    - We may collect and store information about your location if you permit us to do so. We use this data to provide features of our service, to improve and customize our services.
    
    2.4 Cookies and Tracking Technologies
    - We use cookies and similar tracking technologies to track activity on our App and hold certain information.
    """),
    PrivacyandPolicies(heading: "3. How We Use Your Information", content: """
    We use the information we collect in the following ways:
    
    - To Provide and Maintain our Service: To operate, maintain, and provide you with the features and functionality of the App.
    - To Improve Our Service: To understand and analyze how you use our App, to develop new products, services, features, and functionality.
    - To Communicate With You: To send you updates, marketing, and promotional materials, and other information that may be of interest to you.
    - To Manage Your Account: To manage your registration, authentication, and account settings.
    - To Ensure Security and Prevent Fraud: To protect the safety, security, and integrity of our App, services, and users.
    """),
    PrivacyandPolicies(heading: "4. Sharing Your Information", content: """
    We may share your information in the following situations:
    
    - With Service Providers: We may share your information with third-party vendors, service providers, contractors, or agents who perform services on our behalf.
    - For Business Transfers: We may share or transfer your information in connection with, or during negotiations of, any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.
    - With Affiliates: We may share your information with our affiliates, in which case we will require those affiliates to honor this Privacy Policy.
    - With Your Consent: We may disclose your personal information for any other purpose with your consent.
    """),
    PrivacyandPolicies(heading: "5. Data Security", content: """
    We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.
    """),
    PrivacyandPolicies(heading: "6. Your Data Protection Rights", content: """
    Depending on your location, you may have the following rights regarding your personal information:
    
    - Access: You have the right to request copies of your personal data.
    - Rectification: You have the right to request that we correct any information you believe is inaccurate or incomplete.
    - Erasure: You have the right to request that we erase your personal data, under certain conditions.
    - Restrict Processing: You have the right to request that we restrict the processing of your personal data, under certain conditions.
    - Data Portability: You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.
    """),
    PrivacyandPolicies(heading: "7. Children's Privacy", content: """
    Our App does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. If we become aware that we have collected personal information from children under age 13 without verification of parental consent, we take steps to remove that information from our servers.
    """),
    PrivacyandPolicies(heading: "8. Changes to This Privacy Policy", content: """
    We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
    """),
    PrivacyandPolicies(heading: "9. Contact Us", content: """
    If you have any questions about this Privacy Policy, please contact us:
    
    - By email: [Your Email Address]
    - By visiting this page on our website: [Your Website URL]
    - By phone number: [Your Phone Number]
    - By mail: [Your Physical Address]
    """)
]



//
//  SettingsDataModel.swift
//  CasterCom
//
//  Created by Shoaib Akhtar on 01/06/24.
//


struct TermsAndConditions {
    var heading: String
    var content: String
}

let termsAndConditions: [TermsAndConditions] = [
    TermsAndConditions(heading: "Terms and Conditions", content: ""),
    
    TermsAndConditions(heading: "1. Introduction", content: """
    Welcome to CasterCom ("we", "our", "us"). These Terms and Conditions ("Terms", "Terms and Conditions") govern your use of our mobile application CasterCom (the "App"). By accessing or using the App, you agree to be bound by these Terms. If you do not agree with these Terms, please do not use the App.
    """),
    TermsAndConditions(heading: "2. Use of the App", content: """
    2.1 Eligibility
    You must be at least 13 years old to use our App. By using the App, you represent and warrant that you have the legal capacity to enter into a binding agreement.

    2.2 User Account
    You may be required to create an account to use certain features of the App. You agree to provide accurate and complete information when creating your account and to keep this information up to date. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.

    2.3 Prohibited Activities
    You agree not to use the App for any unlawful purpose or in any way that could harm or impair the App or its users. Prohibited activities include, but are not limited to, using the App to:
    - Violate any local, state, national, or international law or regulation.
    - Infringe the rights of any third party, including intellectual property, privacy, or contractual rights.
    - Transmit any viruses, malware, or other harmful code.
    - Engage in any conduct that is fraudulent, misleading, or deceptive.
    """),
    TermsAndConditions(heading: "3. Intellectual Property", content: """
    The App and its original content, features, and functionality are and will remain the exclusive property of CasterCom and its licensors. The App is protected by copyright, trademark, and other laws of both the United States and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of CasterCom.
    """),
    TermsAndConditions(heading: "4. Termination", content: """
    We may terminate or suspend your account and bar access to the App immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms. If you wish to terminate your account, you may simply discontinue using the App.
    """),
    TermsAndConditions(heading: "5. Limitation of Liability", content: """
    In no event shall CasterCom, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the App; (ii) any conduct or content of any third party on the App; (iii) any content obtained from the App; and (iv) unauthorized access, use, or alteration of your transmissions or content, whether based on warranty, contract, tort (including negligence), or any other legal theory, whether or not we have been informed of the possibility of such damage.
    """),
    TermsAndConditions(heading: "6. Governing Law", content: """
    These Terms shall be governed and construed in accordance with the laws of [Your State/Country], without regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our App, and supersede and replace any prior agreements we might have had between us regarding the App.
    """),
    TermsAndConditions(heading: "7. Changes to Terms", content: """
    We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion. By continuing to access or use our App after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, you are no longer authorized to use the App.
    """),
    TermsAndConditions(heading: "8. Contact Us", content: """
    If you have any questions about these Terms, please contact us:

    - By email: [Your Email Address]
    - By visiting this page on our website: [Your Website URL]
    - By phone number: [Your Phone Number]
    - By mail: [Your Physical Address]
    """)
]


//
//  SettingsDataModel.swift
//  CasterCom
//
//  Created by Shoaib Akhtar on 01/06/24.
//

import Foundation
import UIKit

struct FAQ {
    var question: String
    var answer: String
}

let faqs: [FAQ] = [
    FAQ(question: "What is CasterCom?", answer: "CasterCom is a mobile application designed to [brief description of your app’s purpose and features]. It allows users to [key functionalities of your app]."),
    FAQ(question: "How do I create an account?", answer: """
    To create an account:
    1. Download CasterCom from the App Store.
    2. Open the app and tap on "Sign Up".
    3. Enter your details such as name, email address, and password.
    4. Follow the on-screen instructions to complete the registration process.
    """),
    FAQ(question: "How do I reset my password?", answer: """
    If you forgot your password:
    1. Open the app and tap on "Forgot Password?" on the login screen.
    2. Enter your registered email address.
    3. Follow the instructions sent to your email to reset your password.
    """),
    FAQ(question: "How can I update my profile information?", answer: """
    To update your profile:
    1. Open the app and log in to your account.
    2. Go to the "Profile" section from the main menu.
    3. Tap on "Edit Profile" and update your information.
    4. Save the changes.
    """),
    FAQ(question: "Is my data safe with CasterCom?", answer: "Yes, we take your privacy and data security seriously. We use industry-standard encryption and security measures to protect your data. For more details, please refer to our Privacy Policy."),
    FAQ(question: "How do I contact customer support?", answer: """
    You can contact our customer support team by:
    - Email: [Your Support Email Address]
    - Phone: [Your Support Phone Number]
    - In-App Support: Go to the "Help" section in the app and tap on "Contact Support".
    """),
    FAQ(question: "What should I do if I encounter a bug or issue?", answer: """
    If you encounter any bugs or issues:
    1. Go to the "Help" section in the app.
    2. Tap on "Report a Problem".
    3. Provide details about the issue and submit the report.
    Our support team will get back to you as soon as possible.
    """),
    FAQ(question: "Can I delete my account?", answer: """
    Yes, you can delete your account by:
    1. Logging into your account.
    2. Going to the "Settings" section.
    3. Tapping on "Delete Account".
    Please note that deleting your account is permanent and cannot be undone.
    """),
    FAQ(question: "How do I manage notifications?", answer: """
    To manage your notifications:
    1. Go to the "Settings" section in the app.
    2. Tap on "Notifications".
    3. Toggle the switches to enable or disable notifications as per your preference.
    """),
    FAQ(question: "Are there any subscription fees?", answer: """
    CasterCom offers [free/basic features] and [premium features/ subscriptions]. For detailed information on subscription plans and fees, please visit the "Subscription" section in the app or on our website.
    """),
    FAQ(question: "Can I use CasterCom offline?", answer: "Some features of CasterCom may be available offline, but for full functionality, an internet connection is required. Please check specific feature requirements within the app."),
    FAQ(question: "How do I update the app?", answer: """
    To update CasterCom:
    1. Open the App Store.
    2. Go to "Updates".
    3. If an update for CasterCom is available, tap on "Update".
    We recommend keeping your app updated to the latest version for the best experience.
    """),
    FAQ(question: "How do I join a clan/group?", answer: """
    To join a clan/group:
    1. Go to the "Clans" section in the app.
    2. Browse or search for a clan/group you are interested in.
    3. Tap on "Join" and follow the instructions to become a member.
    """),
    FAQ(question: "Can I create my own clan/group?", answer: """
    Yes, to create your own clan/group:
    1. Go to the "Clans" section in the app.
    2. Tap on "Create Clan".
    3. Enter the required details and follow the instructions to set up your clan/group.
    """),
    FAQ(question: "What if I need more help?", answer: "If you need further assistance, please visit the \"Help\" section in the app or contact our support team directly.")
]


struct AboutUsSection {
    var title: String
    var content: String
}

let aboutUsSections: [AboutUsSection] = [
    AboutUsSection(title: "Welcome to CasterCom!", content: "CasterCom is a revolutionary mobile application designed to provide a comprehensive community event timeline and help users find teammates for various activities. Our mission is to facilitate connections, foster inclusivity, and enhance the gaming experience for all users."),
    AboutUsSection(title: "Our Story", content: "Founded in [Year], CasterCom was created with the vision of simplifying the process of discovering gaming events and connecting with like-minded gamers. Since then, we have grown into a dedicated team of professionals passionate about creating a vibrant gaming community."),
    AboutUsSection(title: "Our Mission", content: "Our mission is to empower gamers worldwide by providing them with a platform where they can easily discover upcoming gaming events, connect with other gamers, and build lasting friendships and teams. We strive to make gaming more accessible, enjoyable, and rewarding for everyone."),
    AboutUsSection(title: "Our Values", content: """
    At CasterCom, we believe in:
    - Community: Building a strong, inclusive community where gamers from all backgrounds feel welcome and valued.
    - Innovation: Continuously improving our platform with cutting-edge technology and user feedback to meet the evolving needs of gamers.
    - Integrity: Maintaining transparency, honesty, and trustworthiness in all our interactions with users and partners.
    - Excellence: Delivering a top-quality user experience that exceeds expectations and sets new standards in the gaming industry.
    """),
    AboutUsSection(title: "What We Offer", content: """
    CasterCom offers a range of features designed to enhance your gaming experience:
    - Community Event Timeline: Explore a comprehensive timeline of gaming events, including tournaments, meetups, conventions, and more, all in one place.
    - Teammate Finder: Easily connect with other gamers to form teams for competitive gaming, cooperative play, or casual sessions.
    - Social Features: Engage with fellow gamers, share your gaming experiences, and stay updated with the latest news and announcements.
    - Personalized Experience: Customize your profile and preferences to match your gaming interests, skill level, and schedule.
    """),
    AboutUsSection(title: "About the Team", content: """
    Our team is composed of passionate individuals with diverse backgrounds in technology, gaming, and community building. Each member is dedicated to making CasterCom the ultimate destination for gamers worldwide.

    
    """),
]
