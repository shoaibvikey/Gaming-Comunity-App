//
//  SettingsTableViewController.swift
//  BGClan
//
//  Created by Batch-2 on 30/05/24.
//

//import UIKit
//
//class SettingsTableViewController: UITableViewController {
//
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//    }
//    
//        func showAlert(){
//            let alert = UIAlertController(title: "Sign Out", message: "Are you sure you want to Sign Out?", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: {action in print("Sign Out")}))
//            alert.addAction(UIAlertAction(title: "No", style: .default, handler: {action in print(" ")}))
//            
//            
//            present(alert,animated: true,completion: nil)
//            
//        }
//    
//    
//    
//    
//    
//    @IBAction func signOutButton(_ sender: Any) {
//   showAlert()
//        print("sign Out")
//        
//    }
//   
//    
//    
//    
//    
//
//    
//    
//}


import UIKit

class SettingsTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func showAlert() {
        let alert = UIAlertController(title: "Sign Out", message: "Are you sure you want to Sign Out?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: { [weak self] action in
            self?.signOutAndNavigateToGettingStarted()
           //self?.performSegue(withIdentifier: "gettingStartedViewControlle", sender: self)
        }))
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: nil))
        
        present(alert, animated: true, completion: nil)
    }
    
    func signOutAndNavigateToGettingStarted() {
        
        
        if let appDel = UIApplication.shared.delegate as? AppDelegate,
           let window = appDel.window {
            //            let storyboard = UIStoryboard(name: "Onboarding", bundle: nil)
            //            let vc = storyboard.instantiateViewController(withIdentifier: "gettingStartedViewController")
            //            window.rootViewController = vc
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
            performSegue(withIdentifier: "unwindToGetStarted", sender: self)
            
        }
    }
        
        @IBAction func signOutButton(_ sender: Any) {
            showAlert()
            
        }
        
    
}
