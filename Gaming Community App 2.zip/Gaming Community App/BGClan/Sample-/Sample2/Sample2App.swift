//
//  Sample2App.swift
//  Sample2
//
//  Created by Vineet Chaudhary on 14/05/24.
//

import SwiftUI

@main
struct Sample2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    struct video{
        var title : String
    }
    struct apple{
        var name:String
        var id:Int
    }
}
