//
//  apple.swift
//  Sample2
//
//  Created by Batch-2 on 14/05/24.
//

import Foundation
struct Hello{
    var description:String
   
}
func he(message:String)->String{
    return message
}
