//
//  CommentTableViewCell.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 07/06/24.
//

import UIKit

class CommentTableViewCell: UITableViewCell {

    @IBOutlet weak var userProfileImg: UIImageView!
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var commentLbl: UILabel!
    @IBOutlet weak var commentCellView: UIView!
    
    override func awakeFromNib() {
            super.awakeFromNib()
            commentCellView.layer.cornerRadius = 10
            commentCellView.layer.masksToBounds = true
        }

        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
        }
    
}
