//
//  EventsTilesCell.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 23/05/24.
//

import UIKit

class PostLayoutTilesCell: UITableViewCell {
    
    @IBOutlet weak var PostCaptionOutlet: UILabel!
    @IBOutlet weak var PostLikesCountOutlet: UILabel!
    @IBOutlet weak var PostImageOutlet: UIImageView!
    @IBOutlet weak var LikeButtonPressed: UIButton!
    @IBOutlet weak var CommentButtonPressed: UIButton!
    @IBOutlet weak var UsernameOutlet: UILabel!
    @IBOutlet weak var ProfilePhotoOutlet: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func CommentButtonPressed(_ sender: UIButton) {
        if let viewController = self.getParentViewController() {
                viewController.performSegue(withIdentifier: "postToCommentSegue", sender: self)
            }
        }
    
    @IBAction func LikeBtnPressed(_ sender: Any) {
        if LikeButtonPressed.isSelected {
            // If already liked, reset the like count to zero
            PostLikesCountOutlet.text = "0"
            LikeButtonPressed.isSelected = false
            LikeButtonPressed.setImage(UIImage(systemName: "heart"), for: .normal)  // SF Symbol for empty heart
        } else {
            // If not already liked, increase the like count by 1
            if let currentLikes = Int(PostLikesCountOutlet.text ?? "0") {
                let newLikes = currentLikes + 1
                PostLikesCountOutlet.text = "\(newLikes)"
                LikeButtonPressed.isSelected = true
                LikeButtonPressed.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            }
        }
    }
    
}
extension UIView {
    func getParentViewController() -> UIViewController? {
        var responder: UIResponder? = self
        while let nextResponder = responder?.next {
            if let viewController = nextResponder as? UIViewController {
                return viewController
            }
            responder = nextResponder
        }
        return nil
    }
}



