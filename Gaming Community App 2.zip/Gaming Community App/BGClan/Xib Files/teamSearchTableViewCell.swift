//
//  teamSearchTableViewCell.swift
//  BGClan
//
//  Created by Shoaib Akhtar on 30/05/24.
//

import UIKit

class teamSearchTableViewCell: UITableViewCell {

    @IBOutlet weak var teamLogoOutlet: UIImageView!
    @IBOutlet weak var teamNameOutlet: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
